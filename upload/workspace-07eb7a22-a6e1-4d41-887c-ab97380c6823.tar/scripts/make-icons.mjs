// ساخت آیکون‌های PNG افزونه و وب‌سایت از لوگوی SVG
import sharp from 'sharp';
import { mkdirSync, readFileSync } from 'fs';

const svg = readFileSync('/home/z/my-project/public/ext-icons/logo.svg');

const targets = [
  ['/home/z/my-project/extension/icons/icon16.png', 16],
  ['/home/z/my-project/extension/icons/icon32.png', 32],
  ['/home/z/my-project/extension/icons/icon48.png', 48],
  ['/home/z/my-project/extension/icons/icon128.png', 128],
  ['/home/z/my-project/public/ext-icons/logo-512.png', 512],
  ['/home/z/my-project/src/app/icon.png', 256],
];

mkdirSync('/home/z/my-project/extension/icons', { recursive: true });

for (const [out, size] of targets) {
  await sharp(svg, { density: 400 })
    .resize(size, size, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toFile(out);
  console.log('ok', out, size + 'px');
}
