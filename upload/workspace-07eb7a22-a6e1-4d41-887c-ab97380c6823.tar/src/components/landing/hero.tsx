"use client"

import * as React from "react"
import { motion } from "framer-motion"
import {
  Download,
  Highlighter,
  Lock,
  MousePointerClick,
  Palette,
  PenLine,
  ShieldCheck,
  Sparkles,
  StickyNote,
  Trash2,
  UserX,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { DOWNLOAD_URL } from "./constants"

// پنج رنگ افزونه — هماهنگ با HL.COLORS در extension/shared/constants.js
const HLX_COLORS = [
  { key: "yellow", label: "زرد", dot: "#f5b800" },
  { key: "green", label: "سبز", dot: "#58b85c" },
  { key: "teal", label: "فیروزه‌ای", dot: "#35b3ae" },
  { key: "pink", label: "صورتی", dot: "#e5679b" },
  { key: "purple", label: "بنفش", dot: "#a478e8" },
] as const

const STATS = [
  { icon: ShieldCheck, text: "۱۰۰٪ ذخیره‌سازی محلی" },
  { icon: Palette, text: "۵ رنگ + یادداشت" },
  { icon: UserX, text: "بدون نیاز به ثبت‌نام" },
] as const

// تبدیل بایت به کیلوبایت با ارقام فارسی
function formatKb(bytes: number): string {
  return new Intl.NumberFormat("fa-IR").format(Math.max(1, Math.round(bytes / 1024)))
}

// ماکاپ CSS مرورگر — شبیه رابط واقعی افزونه
function BrowserMockup() {
  return (
    <motion.div
      className="relative mx-auto w-full max-w-lg"
      animate={{ y: [0, -10, 0] }}
      transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
    >
      {/* هاله‌ی گرم پشت قاب */}
      <div
        aria-hidden="true"
        className="absolute -inset-8 rounded-[2.5rem] bg-gradient-to-l from-amber-200/70 via-orange-100/50 to-amber-50/40 blur-2xl dark:from-amber-500/15 dark:via-orange-500/10 dark:to-transparent"
      />

      {/* قاب پنجره‌ی مرورگر */}
      <div className="relative overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-2xl shadow-neutral-900/10 dark:border-neutral-700/70 dark:bg-neutral-900 dark:shadow-black/50">
        {/* نوار بالایی + نوار آدرس */}
        <div className="flex items-center gap-2 border-b border-neutral-200 bg-neutral-100 px-3 py-2.5 dark:border-neutral-700/70 dark:bg-neutral-800">
          <div className="flex items-center gap-1.5" aria-hidden="true">
            <span className="size-2.5 rounded-full bg-red-400" />
            <span className="size-2.5 rounded-full bg-amber-400" />
            <span className="size-2.5 rounded-full bg-green-400" />
          </div>
          <div
            dir="ltr"
            className="flex min-w-0 flex-1 items-center gap-1.5 rounded-full border border-neutral-200 bg-white px-3 py-1 text-[11px] text-neutral-500 dark:border-neutral-700 dark:bg-neutral-900 dark:text-neutral-400"
          >
            <Lock className="size-3 shrink-0 text-green-600 dark:text-green-400" />
            <span className="truncate font-mono">blog.example.com/article</span>
          </div>
          {/* آیکون افزونه در نوار مرورگر */}
          <span className="flex size-6 shrink-0 items-center justify-center rounded-md bg-amber-500 text-white">
            <Highlighter className="size-3.5" />
          </span>
        </div>

        {/* بدنه‌ی مقاله‌ی ساختگی */}
        <div className="relative p-5 pb-20 sm:p-7 sm:pb-20">
          <div className="mb-2 flex items-center justify-between text-[10px] text-neutral-400 dark:text-neutral-500">
            <span className="rounded bg-neutral-100 px-1.5 py-0.5 dark:bg-neutral-800">۸ دقیقه مطالعه</span>
            <span>مقاله‌ی نمونه</span>
          </div>
          <h3 className="mb-3 text-base font-bold text-neutral-800 dark:text-neutral-100">
            خواندن فعال چیست؟
          </h3>
          <p className="text-[13px] leading-8 text-neutral-600 dark:text-neutral-300 sm:text-sm">
            خواندن فعال یعنی گفت‌وگو با متن؛ مغز شما سؤال می‌پرسد و{" "}
            {/* هایلایت دارای یادداشت — خط زیرین نشانگر یادداشت است (مثل افزونه) */}
            <span className="hl-mock border-b-2 border-amber-700/50 bg-amber-200 dark:border-amber-400/60 dark:bg-amber-400/30">
              مهم‌ترین جملات را نشانه‌گذاری می‌کند
            </span>{" "}
            تا بعداً سریع به آن‌ها برگردید. خواننده‌ی فعال{" "}
            <span className="relative inline-block">
              <span className="hl-mock bg-green-200 dark:bg-green-400/30">
                تا چهل درصد بیشتر جزئیات را به یاد می‌آورد
              </span>
              {/* تولبار شناور افزونه — بالای هایلایت */}
              <span className="absolute -top-9 right-0 z-10 flex items-center gap-1.5 rounded-full border border-neutral-200 bg-white px-2 py-1.5 shadow-lg dark:border-neutral-700 dark:bg-neutral-800">
                {HLX_COLORS.map((c) => (
                  <Tooltip key={c.key}>
                    <TooltipTrigger asChild>
                      <span
                        className="size-3 cursor-pointer rounded-full transition-transform hover:scale-125"
                        style={{ backgroundColor: c.dot }}
                      />
                    </TooltipTrigger>
                    <TooltipContent>{c.label}</TooltipContent>
                  </Tooltip>
                ))}
                <span className="mx-0.5 h-3.5 w-px bg-neutral-200 dark:bg-neutral-700" aria-hidden="true" />
                <StickyNote className="size-3.5 text-amber-600 dark:text-amber-400" />
                <Trash2 className="size-3.5 text-neutral-400" />
              </span>
            </span>{" "}
            و یادداشت‌هایش را دقیقاً کنار همان متن نگه می‌دارد.
          </p>
          <p className="mt-3 text-[13px] leading-8 text-neutral-400 dark:text-neutral-500">
            در دنیای دیجیتال، ابزار خوب ابزاری است که به شما تعلق داشته باشد؛ داده‌ی شما روی دستگاه خودتان بماند و هر لحظه قابل انتقال باشد.
          </p>

          {/* پاپ‌اور یادداشت */}
          <div className="absolute bottom-4 left-3 max-w-[15rem] rounded-xl border border-amber-200 bg-amber-50/95 p-3 shadow-xl shadow-amber-900/10 dark:border-amber-500/30 dark:bg-neutral-800/95 dark:shadow-black/30 sm:left-6">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-700 dark:text-amber-400">
              <PenLine className="size-3.5" />
              یادداشت
            </div>
            <p className="mt-1 text-[11px] leading-5 text-neutral-600 dark:text-neutral-300">
              ایده‌ی کلیدی: خواندن یعنی گفت‌وگو با نویسنده
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

// بخش hero — معرفی + ماکاپ مرورگر
export function Hero() {
  // حجم فایل zip از API (خطا بی‌صدا نادیده گرفته می‌شود)
  const [sizeLabel, setSizeLabel] = React.useState<string>("— KB")

  React.useEffect(() => {
    let cancelled = false
    fetch("/api/extension/info")
      .then((res) => (res.ok ? res.json() : null))
      .then((data: { sizeBytes: number | null } | null) => {
        if (cancelled || !data?.sizeBytes) return
        setSizeLabel(`${formatKb(data.sizeBytes)} KB`)
      })
      .catch(() => {
        /* خطا عمداً بی‌صدا — حالت «— KB» باقی می‌ماند */
      })
    return () => {
      cancelled = true
    }
  }, [])

  return (
    <section className="relative overflow-hidden">
      {/* تزیین پس‌زمینه */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-24 -top-24 size-96 rounded-full bg-amber-100/70 blur-3xl dark:bg-amber-500/10" />
        <div className="absolute -right-24 top-48 size-80 rounded-full bg-orange-100/60 blur-3xl dark:bg-orange-500/10" />
      </div>

      <div className="mx-auto w-full max-w-6xl px-4 py-14 sm:px-6 sm:py-24">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-10">
          {/* متن معرفی */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="text-center lg:text-start"
          >
            <Badge
              variant="outline"
              className="gap-1.5 border-amber-300/70 bg-amber-50 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-400"
            >
              <Sparkles className="size-3.5" />
              نسخه ۱.۰.۰ — رایگان و متن‌باز
            </Badge>

            <h1 className="mt-5 text-3xl font-extrabold leading-[1.35] tracking-tight sm:text-4xl lg:text-[2.75rem] lg:leading-[1.3]">
              هایلایت کن، یادداشت بنداز،
              <span className="relative mt-1 inline-block">
                <span className="relative z-10">مالک داده‌هات باش.</span>
                <span
                  aria-hidden="true"
                  className="absolute inset-x-0 bottom-1 z-0 h-3 rounded-full bg-amber-300/80 dark:bg-amber-500/30 sm:bottom-1.5 sm:h-4"
                />
              </span>
            </h1>

            <p className="mt-5 max-w-xl text-base leading-8 text-muted-foreground sm:text-lg sm:leading-9">
              وب هایلایتر یک افزونه‌ی کروم سبک و رایگانه که مقالات وب رو مثل یک کتاب واقعی هایلایت
              می‌کنه؛ روی هر هایلایت یادداشت می‌نویسی و همه‌چیز فقط روی سیستم خودت ذخیره می‌شه —
              بدون سرور، بدون اشتراک، بدون محدودیت.
            </p>

            <div className="mt-8 flex flex-col items-center gap-3 sm:flex-row sm:justify-center lg:justify-start">
              <Button asChild size="lg">
                <a href={DOWNLOAD_URL} download>
                  <Download />
                  دانلود افزونه (.zip)
                </a>
              </Button>
              <Button asChild size="lg" variant="outline">
                <a href="#demo">
                  <MousePointerClick />
                  امتحان دموی زنده
                </a>
              </Button>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">حجم فایل: {sizeLabel}</p>

            {/* سه stat کوچک */}
            <div className="mt-10 flex flex-wrap items-center justify-center gap-x-6 gap-y-4 lg:justify-start">
              {STATS.map((stat, i) => (
                <React.Fragment key={stat.text}>
                  {i > 0 && <span aria-hidden="true" className="hidden h-8 w-px bg-border sm:block" />}
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground/80">
                    <stat.icon className="size-5 text-amber-600 dark:text-amber-400" />
                    {stat.text}
                  </div>
                </React.Fragment>
              ))}
            </div>
          </motion.div>

          {/* ماکاپ مرورگر */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
          >
            <BrowserMockup />
          </motion.div>
        </div>
      </div>
    </section>
  )
}
