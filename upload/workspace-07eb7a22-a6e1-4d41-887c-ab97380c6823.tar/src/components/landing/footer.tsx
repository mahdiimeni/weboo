"use client"

import { Download, Highlighter } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { APP_NAME, DOWNLOAD_URL } from "./constants"

// فوتر چسبیده به پایین صفحه — با رعایت safe-area موبایل
export function Footer() {
  return (
    <footer className="mt-auto w-full border-t bg-amber-50/50 pb-[env(safe-area-inset-bottom)] dark:bg-amber-500/5">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-6">
        <div className="flex items-center gap-2.5">
          <span className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-amber-500 text-white">
            <Highlighter className="size-4" />
          </span>
          <span className="text-sm font-extrabold">{APP_NAME}</span>
          <Badge
            variant="outline"
            className="text-[10px] text-muted-foreground dark:border-amber-500/30"
          >
            نسخه ۱.۰.۰
          </Badge>
        </div>

        <p className="text-xs text-muted-foreground">ساخته‌شده با ❤ برای خوانندگان وب</p>

        <a
          href={DOWNLOAD_URL}
          download
          className="flex items-center gap-1.5 text-sm font-medium text-amber-700 transition-colors hover:text-amber-800 hover:underline dark:text-amber-400 dark:hover:text-amber-300"
        >
          <Download className="size-4" />
          دانلود افزونه
        </a>
      </div>
    </footer>
  )
}
