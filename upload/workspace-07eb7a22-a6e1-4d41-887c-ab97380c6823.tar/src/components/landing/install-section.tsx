"use client"

import { Download, Pin, TriangleAlert } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { FadeIn, LandingSection, SectionHeading } from "./section"
import { DOWNLOAD_URL } from "./constants"

// چیپ کد mono با جهت ltr
function CodeChip({ children }: { children: React.ReactNode }) {
  return (
    <span
      dir="ltr"
      className="inline-flex items-center rounded-md border bg-muted/60 px-2 py-1 font-mono text-xs text-foreground/85"
    >
      {children}
    </span>
  )
}

const STEPS = [
  {
    num: "۱",
    title: "دانلود و استخراج",
    body: (
      <>
        فایل zip افزونه را دانلود و محتوایش را در یک پوشه extract کنید.
      </>
    ),
    extra: "download" as const,
  },
  {
    num: "۲",
    title: "باز کردن chrome://extensions",
    body: (
      <>
        در نوار آدرس کروم تایپ کنید: <CodeChip>chrome://extensions</CodeChip>
      </>
    ),
  },
  {
    num: "۳",
    title: "فعال‌سازی Developer Mode",
    body: <>کلید Developer mode را در گوشه‌ی صفحه فعال کنید.</>,
  },
  {
    num: "۴",
    title: "Load unpacked",
    body: (
      <>
        روی <CodeChip>Load unpacked</CodeChip> کلیک و پوشه‌ی extract شده را انتخاب کنید. تمام!
      </>
    ),
  },
]

// بخش نصب — چهار گام ساده
export function InstallSection() {
  return (
    <LandingSection id="install" className="border-y bg-amber-50/60 dark:bg-amber-500/5">
      <SectionHeading
        eyebrow="نصب"
        title="چهار گام تا هایلایت‌کردن اولین مقاله"
        description="افزونه از فروشگاه نصب نمی‌شود؛ با Load unpacked در کمتر از یک دقیقه فعالش کنید."
      />

      <FadeIn>
        <div className="grid gap-4 sm:grid-cols-2">
          {STEPS.map((step) => (
            <Card key={step.num} className="transition-colors hover:border-amber-300/70 dark:hover:border-amber-500/30">
              <CardContent className="flex items-start gap-4 p-5">
                {/* شماره‌ی بزرگ کهربایی */}
                <span
                  aria-hidden="true"
                  className="text-4xl font-black leading-none text-amber-500 dark:text-amber-400"
                >
                  {step.num}
                </span>
                <div className="min-w-0 flex-1">
                  <h3 className="font-bold">{step.title}</h3>
                  <p className="mt-1.5 text-sm leading-7 text-muted-foreground">{step.body}</p>
                  {step.extra === "download" && (
                    <Button asChild variant="outline" size="sm" className="mt-3">
                      <a href={DOWNLOAD_URL} download>
                        <Download />
                        دانلود مجدد فایل zip
                      </a>
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </FadeIn>

      {/* نکته + هشدار */}
      <FadeIn delay={0.1}>
        <div className="mt-6 grid gap-4">
          <div className="flex items-start gap-3 rounded-xl border bg-muted/30 p-4">
            <Pin className="mt-0.5 size-5 shrink-0 text-amber-600 dark:text-amber-400" />
            <p className="text-sm leading-7 text-muted-foreground">
              پیشنهاد می‌کنیم آیکون افزونه را در نوار ابزار pin کنید تا سریع در دسترس باشد.
            </p>
          </div>
          <div className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4">
            <TriangleAlert className="mt-0.5 size-5 shrink-0 text-destructive" />
            <p className="flex flex-wrap items-center gap-1.5 text-sm leading-7 text-muted-foreground">
              <Badge variant="destructive">هشدار</Badge>
              <span>
                برای صفحات file:// باید در صفحه‌ی افزونه‌ها گزینه‌ی Allow access to file URLs را
                فعال کنید.
              </span>
            </p>
          </div>
        </div>
      </FadeIn>
    </LandingSection>
  )
}
