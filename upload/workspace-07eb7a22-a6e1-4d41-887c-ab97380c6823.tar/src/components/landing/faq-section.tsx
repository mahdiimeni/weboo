"use client"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent } from "@/components/ui/card"
import { FadeIn, LandingSection, SectionHeading } from "./section"

// پرسش‌های پرتکرار
const FAQS = [
  {
    q: "افزونه رایگان است؟",
    a: "بله، کاملاً رایگان. بدون اشتراک، بدون محدودیت تعداد هایلایت و بدون نسخه‌ی premium.",
  },
  {
    q: "داده‌های من کجا ذخیره می‌شود؟",
    a: "فقط در حافظه‌ی محلی مرورگر خودتان (chrome.storage.local). هیچ داده‌ای به سرور ارسال نمی‌شود؛ برای اطمینان می‌توانید تب Network را هنگام استفاده باز کنید.",
  },
  {
    q: "اگر صفحه تغییر کند هایلایت‌ها می‌پرند؟",
    a: "نه. هر هایلایت با سه لایه (XPath، متن دقیق و تطبیق هوشمند متن) ذخیره می‌شود؛ اگر ساختار DOM عوض شود، موتور متنی آن را پیدا و انکُرش را ترمیم می‌کند.",
  },
  {
    q: "با حساب گوگل سینک می‌شود؟",
    a: "خیر — عمداً. برای انتقال داده‌ها بین دستگاه‌ها از فایل بک‌آپ JSON استفاده کنید (مثلاً در Dropbox یا USB).",
  },
  {
    q: "PDF و داخل iframe ها را پشتیبانی می‌کند؟",
    a: "در نسخه‌ی فعلی خیر؛ هایلایت فقط روی متن HTML اصلی صفحه (فریم بالا) کار می‌کند.",
  },
  {
    q: "روی کدام مرورگرها کار می‌کند؟",
    a: "کروم و همه‌ی مرورگرهای کرومیومی مثل Edge و Brave و Arc.",
  },
  {
    q: "فارسی و RTL را خوب پشتیبانی می‌کند؟",
    a: "بله؛ کل رابط افزونه فارسی و RTL است و هایلایت روی متن‌های فارسی، عربی، انگلیسی و ترکیبی درست کار می‌کند.",
  },
] as const

// بخش سوالات متداول
export function FaqSection() {
  return (
    <LandingSection id="faq">
      <SectionHeading
        eyebrow="سوالات"
        title="سوالات پرتکرار"
        description="هر چیزی که لازم است قبل از نصب بدانید."
      />

      <FadeIn>
        <Card className="mx-auto max-w-3xl">
          <CardContent className="p-2 sm:p-4">
            {/* لیست طولانی با اسکرول‌بار سفارشی */}
            <div className="custom-scrollbar max-h-96 overflow-y-auto pe-1">
              <Accordion type="single" collapsible className="w-full">
                {FAQS.map((faq, i) => (
                  <AccordionItem key={i} value={`faq-${i}`}>
                    <AccordionTrigger className="text-right text-sm sm:text-base">
                      {faq.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-sm leading-8 text-muted-foreground">
                      {faq.a}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </CardContent>
        </Card>
      </FadeIn>
    </LandingSection>
  )
}
