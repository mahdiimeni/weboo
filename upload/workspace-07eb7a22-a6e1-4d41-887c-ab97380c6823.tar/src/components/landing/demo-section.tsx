"use client"

import * as React from "react"
import Script from "next/script"
import { Check, Info, RotateCw, Trash2 } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FadeIn, LandingSection, SectionHeading } from "./section"

// ⚠️ قرارداد DOM با /demo/demo.js — این محتوا را تغییر ندهید
const DEMO_HTML = `<p>خواندن فعال یعنی چیزی فراتر از عبور چشم از روی کلمات. وقتی یک متن را با قلم رنگی در دست می‌خوانیم، مغز ما وارد حالت گفت‌وگو با نویسنده می‌شود؛ زیر می‌برد، سؤال می‌پرسد و مهم‌ترین جملات را نشانه‌گذاری می‌کند. پژوهش‌ها نشان می‌دهند خواننده‌ای که متن را هایلایت می‌کند، تا چهل درصد بیشتر از جزئیات مقاله در ذهنش می‌ماند.</p>
<p>اما مشکل همیشگی خوانندگان دیجیتال همین‌جاست: ابزارهای هایلایت وب یا سرویس پولی هستند، یا داده‌های شما را روی سرور خودشان نگه می‌دارند. شما مقاله‌ای را مطالعه می‌کنید، یادداشت می‌نویسید و بعد از مدتی می‌فهمید برای دسترسی به یادداشت‌های خودتان باید اشتراک ماهانه بخرید. این دقیقاً همان وابستگی‌ای است که باید شکسته شود.</p>
<p>وب هایلایتر برای همین ساخته شده: متن را انتخاب کنید، رنگ بزنید، روی هایلایت یادداشت بنویسید و خیالتان راحت باشد که همه‌چیز فقط و فقط روی دستگاه خودتان ذخیره می‌شود؛ بدون حساب کاربری، بدون سرور و بدون هیچ اشتراکی — و هر زمان که بخواهید، با یک کلیک از همه یادداشت‌هایتان خروجی پشتیبان بگیرید.</p>`

// مقاله‌ی دمو — کاملاً ایستا (بدون state/props) تا اسکریپت vanilla بتواند DOM را دستکاری کند
const DemoArticle = React.memo(function DemoArticle() {
  return (
    <div
      id="hl-demo-article"
      className="text-lg leading-9 text-foreground/90 space-y-5"
      dangerouslySetInnerHTML={{ __html: DEMO_HTML }}
    />
  )
})

// راهنمای سه‌مرحله‌ای استفاده از دمو
const GUIDE_STEPS = [
  "متنی را در مقاله‌ی زیر انتخاب کنید",
  "از نوار شناور یک رنگ بزنید",
  "روی هایلایت کلیک و یادداشت بنویسید — خط زیرین یعنی یادداشت دارد",
] as const

const GUIDE_NUMBERS = ["۱", "۲", "۳"] as const

// قابلیت‌هایی که در همین دمو قابل تست‌اند
const TESTABLE = [
  "هایلایت ۵ رنگ",
  "یادداشت روی هایلایت",
  "خط زیرین برای یادداشت‌دارها",
  "حذف هایلایت",
  "بازیابی بعد از «رفرش»",
  "بک‌آپ",
] as const

// بخش دموی زنده — منطق در /demo/demo.js قرار دارد
export function DemoSection() {
  return (
    <LandingSection id="demo" className="border-y bg-amber-50/60 dark:bg-amber-500/5">
      <SectionHeading
        eyebrow="دموی زنده"
        title="بدون نصب امتحان کن — همین‌جا"
        description="همان تجربه‌ی افزونه، اینجا در مرورگر شما: انتخاب متن، هایلایت رنگی، یادداشت و بازیابی."
      />

      <FadeIn>
        <Card className="border-amber-200/70 shadow-lg shadow-amber-900/5 dark:border-amber-500/20">
          <CardContent className="p-4 sm:p-8">
            {/* راهنمای ۳ مرحله‌ای */}
            <ol className="grid gap-3 sm:grid-cols-3">
              {GUIDE_STEPS.map((step, i) => (
                <li key={step} className="flex items-start gap-3 rounded-xl border bg-muted/30 p-3.5">
                  <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500 text-sm font-bold text-amber-950">
                    {GUIDE_NUMBERS[i]}
                  </span>
                  <span className="text-sm leading-6">{step}</span>
                </li>
              ))}
            </ol>

            {/* ⚠️ قرارداد DOM با demo.js — ساختار را تغییر ندهید */}
            <div id="hl-demo-root" className="mt-6">
              <DemoArticle />
              <div className="demo-controls mt-6 flex flex-wrap items-center gap-2 border-t pt-4">
                <Button variant="outline" size="sm" id="hl-demo-reload">
                  <RotateCw />
                  بازخوانی هایلایت‌ها
                </Button>
                <Button variant="outline" size="sm" id="hl-demo-clear">
                  <Trash2 />
                  پاک‌کردن دمو
                </Button>
                <span id="hl-demo-status" className="ms-auto text-xs text-muted-foreground">
                  —
                </span>
              </div>
              <Script src="/demo/demo.js" strategy="afterInteractive" />
            </div>

            <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Info className="size-3.5 shrink-0 text-amber-600 dark:text-amber-400" />
              داده‌های دمو فقط در localStorage مرورگرِ خودتان ذخیره می‌شود.
            </p>

            {/* قابلیت‌های قابل تست */}
            <div className="mt-4 rounded-xl border border-amber-200/70 bg-amber-50/70 p-4 dark:border-amber-500/20 dark:bg-amber-500/5">
              <div className="text-xs font-bold text-amber-700 dark:text-amber-400">
                قابلیت‌های قابل تست
              </div>
              <ul className="mt-2.5 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {TESTABLE.map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm text-foreground/85">
                    <Check className="size-4 shrink-0 text-green-600 dark:text-green-400" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      </FadeIn>
    </LandingSection>
  )
}
