"use client"

import * as React from "react"
import { ArrowLeft, Code2, Database, Info, LayoutDashboard, Zap } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { FadeIn, LandingSection, SectionHeading } from "./section"

// اجزای معماری افزونه
const MODULES = [
  { icon: Code2, title: "Content Script", desc: "انکُرینگ + UI شناور در Shadow DOM" },
  { icon: Zap, title: "Service Worker", desc: "منوی راست‌کلیک، میان‌بر، badge شمارش" },
  { icon: Database, title: "Storage", desc: "chrome.storage.local پارتیشن‌بندی per-host" },
  { icon: LayoutDashboard, title: "Dashboard & Popup", desc: "مدیریت و تنظیمات" },
] as const

// پایپ‌لاین ذخیره و بازیابی هایلایت
const PIPELINE = [
  "انتخاب متن",
  "ذخیره‌ی انکُر سه‌لایه (XPath + quote + prefix/suffix)",
  "ذخیره‌ی محلی",
  "بازیابی خودکار + خودترمیمی انکُر",
] as const

// بخش معماری — برای مخاطب فنی
export function ArchitectureSection() {
  return (
    <LandingSection id="architecture" className="border-y bg-amber-50/60 dark:bg-amber-500/5">
      <SectionHeading
        eyebrow="معماری"
        title="زیر کاپوت چه خبر است؟"
        description="برای مخاطب فنی: یک معماری MV3 تمیز با انکُرینگ سه‌لایه و بدون هیچ وابستگی خارجی."
      />

      {/* چهار ماژول */}
      <FadeIn>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {MODULES.map((mod) => (
            <Card key={mod.title} className="transition-colors hover:border-amber-300/70 dark:hover:border-amber-500/30">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
                    <mod.icon className="size-5" />
                  </span>
                  <h3 dir="ltr" className="text-sm font-bold">{mod.title}</h3>
                </div>
                <p className="mt-3 text-sm leading-7 text-muted-foreground">{mod.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </FadeIn>

      {/* پایپ‌لاین بصری (RTL: جریان از راست به چپ) */}
      <FadeIn delay={0.1}>
        <div className="mt-10 rounded-2xl border bg-card p-4 sm:p-6">
          <div className="mb-4 text-center text-xs font-bold text-muted-foreground">
            چرخه‌ی زندگی یک هایلایت
          </div>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {PIPELINE.map((step, i) => (
              <React.Fragment key={step}>
                {i > 0 && <ArrowLeft aria-hidden="true" className="size-4 shrink-0 text-amber-500" />}
                <span className="rounded-lg border bg-muted/40 px-3.5 py-2 text-xs font-medium leading-6 sm:text-sm">
                  {step}
                </span>
              </React.Fragment>
            ))}
          </div>
          <p className="mx-auto mt-5 flex max-w-2xl items-start justify-center gap-2 text-center text-sm leading-7 text-muted-foreground">
            <Info className="mt-1.5 size-4 shrink-0 text-amber-600 dark:text-amber-400" />
            هایلایت‌ها به‌ترتیب زمان ساخت بازیابی می‌شوند تا هایلایت‌های روی‌هم‌افتاده (overlap)
            درست بازسازی شوند.
          </p>
        </div>
      </FadeIn>
    </LandingSection>
  )
}
