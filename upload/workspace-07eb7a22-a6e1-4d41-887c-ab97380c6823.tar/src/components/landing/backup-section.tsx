"use client"

import { Download, ShieldCheck, Upload } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { FadeIn, LandingSection, SectionHeading } from "./section"

// کارت‌های بک‌آپ با آیکون کهربایی
function IconBox({ icon: Icon }: { icon: typeof Download }) {
  return (
    <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400">
      <Icon className="size-5" />
    </span>
  )
}

// بخش بک‌آپ و داده‌ها
export function BackupSection() {
  return (
    <LandingSection id="backup">
      <SectionHeading
        eyebrow="بک‌آپ و داده‌ها"
        title="داده‌های شما، در کنترل شما"
        description="بدون سرور یعنی بدون وابستگی — با یک فایل JSON همه‌چیز را هر جا که بخواهید ببرید."
      />

      <FadeIn>
        <div className="grid gap-4 sm:grid-cols-2">
          <Card className="transition-colors hover:border-amber-300/70 dark:hover:border-amber-500/30">
            <CardContent className="flex items-start gap-4 p-5">
              <IconBox icon={Download} />
              <div>
                <h3 className="font-bold">خروجی پشتیبان</h3>
                <p className="mt-1.5 text-sm leading-7 text-muted-foreground">
                  از داخل داشبورد یا پاپ‌آپ افزونه با یک کلیک فایل JSON کامل از همه‌ی هایلایت‌ها،
                  یادداشت‌ها و تنظیمات بگیرید. اسم فایل شامل تاریخ است.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="transition-colors hover:border-amber-300/70 dark:hover:border-amber-500/30">
            <CardContent className="flex items-start gap-4 p-5">
              <IconBox icon={Upload} />
              <div>
                <h3 className="font-bold">بازیابی/منتقل‌کردن</h3>
                <p className="mt-1.5 text-sm leading-7 text-muted-foreground">
                  فایل بک‌آپ را در هر مرورگر/دستگاه دیگری import کنید — با حالت ادغام (merge) یا
                  جایگزینی کامل (replace).
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </FadeIn>

      {/* کارت پهن حریم خصوصی */}
      <FadeIn delay={0.1}>
        <Card className="mt-4 border-amber-200/70 bg-amber-50/60 dark:border-amber-500/25 dark:bg-amber-500/5">
          <CardContent className="p-5 sm:p-6">
            <div className="flex items-start gap-4">
              <IconBox icon={ShieldCheck} />
              <div className="min-w-0 flex-1">
                <h3 className="font-bold">حریم خصوصی</h3>
                <Separator className="my-3" />
                <p className="text-sm leading-7 text-muted-foreground">
                  طراحی افزونه عمداً بدون سرور است؛ هیچ درخواست شبکه‌ای برای داده‌های شما وجود
                  ندارد و تنها مجوزها <span dir="ltr" className="font-mono text-xs">storage</span> و{" "}
                  <span dir="ltr" className="font-mono text-xs">activeTab</span> هستند.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </FadeIn>
    </LandingSection>
  )
}
