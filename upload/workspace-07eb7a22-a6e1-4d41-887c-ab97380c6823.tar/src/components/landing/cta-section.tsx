"use client"

import { Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { FadeIn, LandingSection } from "./section"
import { DOWNLOAD_URL } from "./constants"

// CTA نهایی — کارت کهربایی بزرگ
export function CtaSection() {
  return (
    <LandingSection id="download-cta">
      <FadeIn>
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-amber-400 via-amber-500 to-orange-500 px-6 py-12 text-center shadow-xl shadow-amber-500/20 sm:px-12 sm:py-16">
          {/* دایره‌های تزیینی */}
          <div aria-hidden="true" className="pointer-events-none absolute -right-16 -top-16 size-48 rounded-full bg-white/15" />
          <div aria-hidden="true" className="pointer-events-none absolute -bottom-20 -left-10 size-56 rounded-full bg-orange-600/25" />

          <h2 className="relative text-2xl font-extrabold text-amber-950 sm:text-3xl">
            از همین امروز، بدون اشتراک بخوانید.
          </h2>
          <p className="relative mx-auto mt-3 max-w-xl text-sm leading-8 text-amber-900/90 sm:text-base">
            یک بار نصب می‌کنید، برای همیشه رایگان می‌خوانید — و یادداشت‌هایتان همیشه مال خودتان
            می‌ماند.
          </p>

          <div className="relative mt-8 flex justify-center">
            <Button
              asChild
              size="lg"
              className="bg-white text-amber-800 shadow-lg hover:bg-amber-50"
            >
              <a href={DOWNLOAD_URL} download>
                <Download />
                دانلود افزونه (.zip)
              </a>
            </Button>
          </div>

          <p className="relative mt-4 text-xs text-amber-900/70">
            نسخه ۱.۰.۰ · رایگان و متن‌باز · بدون اشتراک
          </p>
        </div>
      </FadeIn>
    </LandingSection>
  )
}
