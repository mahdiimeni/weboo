"use client"

import * as React from "react"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

// ظاهرشدن نرم بخش‌ها هنگام اسکرول
export function FadeIn({
  children,
  className,
  delay = 0,
}: {
  children: React.ReactNode
  className?: string
  delay?: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.55, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  )
}

// پوشش استاندارد بخش با container و فاصله‌ی عمودی
export function LandingSection({
  id,
  className,
  children,
}: {
  id: string
  className?: string
  children: React.ReactNode
}) {
  return (
    <section id={id} className={cn("scroll-mt-20", className)}>
      <div className="mx-auto w-full max-w-6xl px-4 py-14 sm:px-6 sm:py-20">{children}</div>
    </section>
  )
}

// سرتیتر بخش‌ها (eyebrow کهربایی + عنوان + توضیح)
export function SectionHeading({
  eyebrow,
  title,
  description,
  className,
}: {
  eyebrow: string
  title: string
  description?: string
  className?: string
}) {
  return (
    <FadeIn className={cn("mx-auto mb-8 max-w-2xl text-center sm:mb-12", className)}>
      <span className="text-sm font-bold text-amber-600 dark:text-amber-400">{eyebrow}</span>
      <h2 className="mt-2 text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl">
        {title}
      </h2>
      {description ? (
        <p className="mt-3 leading-7 text-muted-foreground">{description}</p>
      ) : null}
    </FadeIn>
  )
}
