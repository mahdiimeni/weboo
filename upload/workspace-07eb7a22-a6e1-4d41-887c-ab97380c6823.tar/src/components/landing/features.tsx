"use client"

import * as React from "react"
import {
  Check,
  DatabaseBackup,
  LayoutDashboard,
  Palette,
  RefreshCw,
  ShieldCheck,
  StickyNote,
  X,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { cn } from "@/lib/utils"
import { FadeIn, LandingSection, SectionHeading } from "./section"

// شش ویژگی اصلی
const FEATURES = [
  {
    icon: Palette,
    title: "هایلایت پنج‌رنگ",
    desc: "متن را انتخاب کن و با یک کلیک هایلایت کن؛ پنج رنگ قابل تنظیم برای دسته‌بندی موضوعی.",
  },
  {
    icon: StickyNote,
    title: "یادداشت روی هر هایلایت",
    desc: "روی هر هایلایت کلیک کن تا یادداشتش را ببینی؛ هایلایت‌های دارای یادداشت با خط زیرین متمایز می‌شوند تا در یک نگاه پیدایشان کنی.",
  },
  {
    icon: ShieldCheck,
    title: "ذخیره‌سازی ۱۰۰٪ محلی",
    desc: "همه‌ی داده‌ها فقط در حافظه‌ی مرورگر خودت (chrome.storage.local) — هیچ داده‌ای به هیچ سروری نمی‌رود.",
  },
  {
    icon: DatabaseBackup,
    title: "بک‌آپ و بازیابی یک‌کلیکی",
    desc: "خروجی JSON کامل با یک کلیک؛ بازیابی با حالت ادغام یا جایگزینی کامل.",
  },
  {
    icon: RefreshCw,
    title: "ماندگاری هوشمند هایلایت‌ها",
    desc: "انکُرینگ سه‌لایه (XPath + متن + تطبیق هوشمند) — حتی اگر ساختار صفحه عوض بشه، هایلایت‌ها برمی‌گردن.",
  },
  {
    icon: LayoutDashboard,
    title: "مدیریت متمرکز",
    desc: "داشبورد کامل با جست‌وجو، فیلتر رنگ/یادداشت، گروه‌بندی per-صفحه و آمار.",
  },
] as const

// قابلیت‌های فرعی (chips)
const CHIPS = [
  "منوی راست‌کلیک",
  "میان‌بر Alt+Shift+H",
  "بدون تبلیغ",
  "کارکرد آفلاین",
  "پشتیبانی فارسی/RTL",
] as const

// ردیف‌های مقایسه با سرویس‌های اشتراکی
const COMPARISON_ROWS = [
  { label: "قیمت", ours: "رایگان و متن‌باز، برای همیشه", theirs: "اشتراک ماهانه/سالانه" },
  { label: "محل ذخیره داده‌ها", ours: "فقط روی دستگاه شما", theirs: "سرور سرویس‌دهنده" },
  { label: "نیاز به حساب کاربری", ours: "خیر — بدون ثبت‌نام", theirs: "بله، اجباری" },
  { label: "خروجی گرفتن از داده‌ها", ours: "فایل JSON با یک کلیک", theirs: "قفل‌شده در پلتفرم" },
  { label: "محدودیت هایلایت", ours: "نامحدود", theirs: "محدود در پلن رایگان" },
] as const

// کارت مقایسه — با سوییچ نمایش ستون سرویس‌های اشتراکی
function ComparisonCard() {
  const [compare, setCompare] = React.useState(false)

  return (
    <Card className="mt-10">
      <CardContent className="p-4 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-bold">مقایسه سریع</h3>
            <p className="mt-1 text-xs text-muted-foreground">
              وب هایلایتر در مقابل سرویس‌های هایلایت اشتراکی
            </p>
          </div>
          <div className="flex items-center gap-2.5">
            <Label htmlFor="compare-switch" className="cursor-pointer text-xs text-muted-foreground">
              مقایسه با سرویس‌های اشتراکی
            </Label>
            <Switch id="compare-switch" checked={compare} onCheckedChange={setCompare} />
          </div>
        </div>

        {/* سربرگ ستون‌ها (فقط دسکتاپ) */}
        <div
          className={cn(
            "mt-5 hidden gap-2 px-3 text-xs font-bold sm:grid",
            compare ? "sm:grid-cols-[1.1fr_1fr_1fr]" : "sm:grid-cols-[1.1fr_1fr]"
          )}
        >
          <span className="text-muted-foreground">ویژگی</span>
          <span className="text-amber-600 dark:text-amber-400">وب هایلایتر</span>
          {compare && <span className="text-muted-foreground">سرویس‌های اشتراکی</span>}
        </div>

        <div className="mt-2 space-y-2.5">
          {COMPARISON_ROWS.map((row) => (
            <div
              key={row.label}
              className={cn(
                "grid gap-2 rounded-xl border bg-muted/30 p-3 text-sm sm:grid-cols-[1.1fr_1fr]",
                compare && "sm:grid-cols-[1.1fr_1fr_1fr]"
              )}
            >
              <span className="font-medium text-foreground/90">{row.label}</span>
              <span className="flex items-center gap-1.5 text-foreground/85">
                <Check className="size-4 shrink-0 text-green-600 dark:text-green-400" />
                {row.ours}
              </span>
              {compare && (
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <X className="size-4 shrink-0 text-destructive/70" />
                  {row.theirs}
                </span>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

// بخش ویژگی‌ها
export function FeaturesSection() {
  return (
    <LandingSection id="features">
      <SectionHeading
        eyebrow="ویژگی‌ها"
        title="هر چیزی که یک خواننده‌ی وب نیاز دارد"
        description="سبک، سریع و بدون هیچ قید و بندی — همه‌ی داده‌ها از شما، برای شما."
      />

      <FadeIn>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((feature) => (
            <Card
              key={feature.title}
              className="group transition-all hover:-translate-y-1 hover:border-amber-300/70 hover:shadow-lg hover:shadow-amber-900/5 dark:hover:border-amber-500/30"
            >
              <CardContent className="p-5">
                <span className="flex size-11 items-center justify-center rounded-xl bg-amber-100 text-amber-600 transition-colors group-hover:bg-amber-500 group-hover:text-white dark:bg-amber-500/15 dark:text-amber-400">
                  <feature.icon className="size-5" />
                </span>
                <h3 className="mt-4 font-bold">{feature.title}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{feature.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </FadeIn>

      {/* chips قابلیت‌های فرعی */}
      <FadeIn delay={0.1}>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
          {CHIPS.map((chip) => (
            <Badge
              key={chip}
              variant="outline"
              className="border-amber-200/80 bg-amber-50/60 text-amber-800 dark:border-amber-500/25 dark:bg-amber-500/10 dark:text-amber-300"
            >
              {chip}
            </Badge>
          ))}
        </div>
      </FadeIn>

      {/* مقایسه با سوییچ */}
      <FadeIn delay={0.15}>
        <ComparisonCard />
      </FadeIn>
    </LandingSection>
  )
}
