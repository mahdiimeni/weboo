"use client"

import * as React from "react"
import { useTheme } from "next-themes"
import { Download, Highlighter, Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import { APP_NAME, DOWNLOAD_URL } from "./constants"

const NAV_ITEMS = [
  { href: "#features", label: "ویژگی‌ها" },
  { href: "#demo", label: "دمو" },
  { href: "#install", label: "نصب" },
  { href: "#backup", label: "بک‌آپ" },
  { href: "#architecture", label: "معماری" },
  { href: "#faq", label: "سوالات" },
] as const

// هدر چسبان با بلور — موبایل: لوگو + دکمه‌ی دانلود
export function Header() {
  const { resolvedTheme, setTheme } = useTheme()

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-2 px-4 sm:px-6">
        {/* لوگو */}
        <a href="#" className="flex min-w-0 items-center gap-2.5" aria-label={`${APP_NAME} — بازگشت به بالای صفحه`}>
          <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-amber-500 text-white shadow-md shadow-amber-500/30">
            <Highlighter className="size-5" />
          </span>
          <span className="truncate text-base font-extrabold">{APP_NAME}</span>
        </a>

        {/* منو — فقط دسکتاپ */}
        <nav aria-label="منوی اصلی" className="hidden items-center gap-1 lg:flex">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
            >
              {item.label}
            </a>
          ))}
        </nav>

        {/* اکشن‌ها: تم + دانلود */}
        <div className="flex shrink-0 items-center gap-1.5">
          <Button
            variant="ghost"
            size="icon"
            aria-label="تغییر حالت روشن/تاریک"
            onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
          >
            {/* آیکون‌ها با CSS جابه‌جا می‌شوند تا mismatch پیش نیاید */}
            <Sun className="size-5 dark:hidden" />
            <Moon className="hidden size-5 dark:block" />
          </Button>
          <Button asChild size="sm">
            <a href={DOWNLOAD_URL} download>
              <Download />
              دانلود افزونه
            </a>
          </Button>
        </div>
      </div>
    </header>
  )
}
