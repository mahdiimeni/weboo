// ثابت‌های مشترک لندینگ‌پیج
export const APP_NAME = "وب هایلایتر"
export const APP_VERSION = "1.0.2"
export const DOWNLOAD_URL = "/downloads/highlighter-extension-v1.0.2.zip"
