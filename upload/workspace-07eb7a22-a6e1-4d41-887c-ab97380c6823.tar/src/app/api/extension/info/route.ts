import { NextResponse } from "next/server"
import { stat } from "fs/promises"
import path from "path"
import { APP_VERSION, DOWNLOAD_URL } from "@/components/landing/constants"

export const dynamic = "force-dynamic"

// اطلاعات افزونه + حجم واقعی فایل zip (اگر وجود داشته باشد)
// نسخه و نام فایل از منبع واحد constants.ts می‌آیند تا همیشه هماهنگ بمانند.
export async function GET() {
  const fileName = path.basename(DOWNLOAD_URL)
  let sizeBytes: number | null = null
  try {
    const s = await stat(path.join(process.cwd(), "public", "downloads", fileName))
    sizeBytes = s.size
  } catch {}
  return NextResponse.json({
    ok: true,
    app: "web-highlighter",
    version: APP_VERSION,
    fileName,
    downloadUrl: `/downloads/${fileName}`,
    sizeBytes,
  })
}
