"use client"

import { Header } from "@/components/landing/header"
import { Hero } from "@/components/landing/hero"
import { DemoSection } from "@/components/landing/demo-section"
import { FeaturesSection } from "@/components/landing/features"
import { InstallSection } from "@/components/landing/install-section"
import { BackupSection } from "@/components/landing/backup-section"
import { ArchitectureSection } from "@/components/landing/architecture-section"
import { FaqSection } from "@/components/landing/faq-section"
import { CtaSection } from "@/components/landing/cta-section"
import { Footer } from "@/components/landing/footer"

// لندینگ‌پیج «وب هایلایتر» — RTL فارسی با دموی زنده
export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">
        <Hero />
        <DemoSection />
        <FeaturesSection />
        <InstallSection />
        <BackupSection />
        <ArchitectureSection />
        <FaqSection />
        <CtaSection />
      </main>
      {/* فوتر چسبیده به پایین (mt-auto) */}
      <Footer />
    </div>
  )
}
