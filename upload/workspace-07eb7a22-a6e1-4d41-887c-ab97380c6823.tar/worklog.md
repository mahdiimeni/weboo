# Worklog — پروژه «وب هایلایتر» (Chrome Extension + Landing Page)

## نمای کلی پروژه
هدف: افزونه‌ی گوگل کروم (Manifest V3) برای هایلایت مقالات وب + یادداشت روی هر هایلایت + ذخیره‌سازی ۱۰۰٪ محلی (chrome.storage.local) + بک‌آپ/بازیابی JSON. به‌علاوه یک لندینگ‌پیج فارسی (RTL) در `/` با دموی زنده‌ی تعاملی.

## معماری کلی

```
┌────────────────────── Chrome Extension (MV3) ──────────────────────┐
│                                                                    │
│  Content Script (در هر صفحه)                                       │
│  ├── textindex.js  → موتور انکُرینگ متنی (اینکس کاراکتری + تطبیق fuzzy) │
│  ├── domwrap.js    → wrap/unwrap دامنه‌ها با <mark>، انکُر XPath       │
│  ├── ui.js         → نوار ابزار شناور + پاپ‌اور یادداشت (Shadow DOM)   │
│  ├── store.js      → لایه ذخیره‌سازی روی chrome.storage.local         │
│  └── content.js    → هماهنگی: ایجاد/بازیابی/حذف هایلایت، پیام‌رسانی     │
│                                                                    │
│  Service Worker  → منوی راست‌کلیک، میان‌بر Alt+Shift+H، badge شمارش    │
│  Popup           → خلاصه‌ی صفحه‌ی فعلی + سوئیچ فعال/غیرفعال سایت        │
│  Dashboard       → مدیریت کامل: جست‌وجو/فیلتر، بک‌آپ/بازیابی، تنظیمات   │
└────────────────────────────────────────────────────────────────────┘
                              │
                 بک‌آپ JSON (Export/Import) ← → کاربر
```

### استراتژی انکُرینگ (قلب معماری)
هر هایلایت با ۳ لایه‌ی بازیابی ذخیره می‌شود تا با تغییر DOM صفحه هم پیدا شود:
1. **Fast path**: XPath نسبی به body برای start/end container + offset
2. **Text quote**: متن دقیق + ۳۲ کاراکتر prefix/suffix + آفست کاراکتری در متنِ سند
3. **Fuzzy fallback**: جست‌وجوی متن نرمال‌شده (فاصله‌ها) + امتیازدهی prefix/suffix + نزدیکی آفست

اگر fast path شکست بخورد → fallback متنی → «خودترمیمی»: انکُر و آفست جدید ذخیره می‌شود.
هایلایت‌ها به‌ترتیب createdAt بازیابی می‌شوند تا هایلایت‌های تو در تو (overlap) درست بازسازی شوند.
هایلایت یتیم (پیدا نشد) با تایمر + MutationObserver چندبار retry می‌شود.

### ساختار داده (Record)
```js
{
  id: 'hlx_...',        // شناسه یکتا
  host, site,           // مثلاً 'en.wikipedia.org'، 'https://en.wikipedia.org'
  url, urlNorm,         // آدرس نرمال‌شده (بدون hash/utm، پارامترهای مرتب‌شده)
  title,                // عنوان صفحه
  text, prefix, suffix, // متن هایلایت + بافت اطراف
  start, end,           // آفست کاراکتری در متن سند
  anchor: { start, startOffset, end, endOffset }, // XPath
  color,                // yellow|green|teal|pink|purple
  note,                 // یادداشت (متن خالی = بدون یادداشت)
  createdAt, updatedAt
}
```

### پارتیشن‌بندی ذخیره‌سازی
- `hlx:settings` → تنظیمات {defaultColor, showToolbar, showBadge, disabledHosts[]}
- `hlx:d:<host>` → Map<id, Record> (خواندن سریع فقط داده‌های همان سایت)

### نکات فنی مهم
- MV3، مجوزها: storage, unlimitedStorage, contextMenus, activeTab
- فایل‌های shared به‌صورت classic script روی `globalThis.HL` (بدون import/export) تا هم در content script، هم صفحات افزونه و هم import در SW کار کنند
- UI داخل Shadow DOM با z-index ماکس → صفر تداخل با استایل صفحات
- همه‌ی متن‌های کاربر با textContent رندر می‌شوند (ضد XSS از محتوای صفحات)
- بازیابی هایلایت‌ها فقط در فریم اصلی (all_frames: false)

---

Task ID: 1
Agent: main (Z.ai Code)
Task: بررسی محیط + طراحی پلن و معماری پروژه

Work Log:
- بررسی package.json، ساختار src، dev.log و eslint.config.mjs
- تأیید اجرای dev server روی پورت 3000 (کد 200)
- تأیین ابزارهای موجود: sharp (نساختن آیکون SVG→PNG)، zip
- طراحی معماری سه‌لایه‌ی انکُرینگ (XPath + Quote + Fuzzy) و پارتیشن‌بندی storage

Stage Summary:
- پروژه: افزونه MV3 + لندینگ‌پیج فارسی در /
- تسک‌ها: ۲ (هسته‌ی افزونه، توسط main) → ۲-a (لندینگ‌پیج، ساب‌ایجنت) + ۲-b (popup/dashboard/SW، ساب‌ایجنت) → ۳ (آیکون/دمو/zip) → ۴ (راستی‌آزمایی مرورگر)

---
Task ID: 2
Agent: main (Z.ai Code)
Task: توسعه‌ی هسته‌ی افزونه (shared core + content script + manifest)

Work Log:
- ایجاد extension/manifest.json (MV3، permissions: storage/unlimitedStorage/contextMenus/activeTab، commands: Alt+Shift+H)
- extension/shared/constants.js — HL namespace، MSG types، COLORS(5)، DEFAULT_SETTINGS
- extension/shared/utils.js — normalizeUrl (حذف hash/utm + sort params)، newId، debounce، escapeHtml، fmtDate(fa-IR)، downloadText
- extension/shared/textindex.js — موتور انکُرینگ: buildTextIndex (TreeWalker + binary search locate)، normInfo (نقشه نرمال‌سازی فاصله‌ها)، findRange (offsets→exact→norm + scoring با prefix/suffix/proximity)
- extension/shared/domwrap.js — xpathOf/evalXPath (نسبی به body)، serializeRange/resolveAnchor، markRange (splitText+wrap با mark)، unwrap/setColor/flash
- extension/shared/ui.js — FloatingToolbar + NotePopover + Toast داخل Shadow DOM (z-index 2147483646، dir=rtl، dark-mode با media query)
- extension/shared/store.js — chrome.storage.local با پارتیشن hlx:d:<host> + hlx:settings، export/import (merge|replace + sanitizeRecord)
- extension/content/content.js — بوت، بازیابی ۳لایه + خودترمیمی انکُر، retry یتیم‌ها (timer+MutationObserver)، نوار ابزار selection، پاپ‌اور کلیک روی mark، هش #hlx-goto-، sync زنده storage، reportCount به SW
- extension/content/mark-style.css — استایل mark.hlx-marker با ۵ رنگ + dark mode + flash

=== قرارداد API برای بقیه‌ی ماژول‌ها (globalThis.HL) ===
HL.APP_NAME='وب هایلایتر'  HL.VERSION='1.0.0'  HL.APP_ID='web-highlighter'
HL.MSG={COUNT_REPORT:'hlx:count-report', GET_COUNT:'hlx:get-count', GOTO:'hlx:goto', HIGHLIGHT_SELECTION:'hlx:highlight-selection'}
HL.COLORS={yellow:{label:'زرد',dot:'#f5b800'},green:{label:'سبز',dot:'#58b85c'},teal:{label:'فیروزه‌ای',dot:'#35b3ae'},pink:{label:'صورتی',dot:'#e5679b'},purple:{label:'بنفش',dot:'#a478e8'}}
HL.COLOR_KEYS=['yellow','green','teal','pink','purple']
HL.DEFAULT_SETTINGS={defaultColor:'yellow',showToolbar:true,showBadge:true,disabledHosts:[]}
HL.GOTO_HASH_PREFIX='hlx-goto-'
HL.util.{normalizeUrl(href)->{url,norm,site,host}, newId(), debounce(fn,ms), escapeHtml(s), fmtDate(ts), fmtDateTime(ts), excerpt(s,n), cssEscape(s), downloadText(filename,text), backupFileName()}
HL.store.{getSettings(), setSettings(patch), getForUrl(urlNorm,host)->Map, getAllRecords()->Map, hostsWithData(), save(rec), saveMany(recs), remove(id,hostHint), removeMany(ids,hostHint), removeForUrl(urlNorm,host), clearAll(), exportData()->backupObj, importData(backup,mode)->{added,updated,skipped,removed}, onSettingsChanged(cb), onRecordsChanged(cb), getBytesInUse()}
backupObj={app:'web-highlighter',name,format:1,version,exportedAt,settings,highlights:{id:rec},meta:{count}}
Record schema: {id,host,site,url,urlNorm,title,text,prefix,suffix,start,end,anchor:{start,startOffset,end,endOffset},color,note,createdAt,updatedAt}

Stage Summary:
- هسته‌ی انکُرینگ + storage + UI شناور + content script کامل و آماده‌اند
- بقیه: popup/dashboard/service-worker (تسک 2-b) و لندینگ‌پیج (تسک 2-a) و آیکون/دمو/zip (تسک 3)

---
Task ID: 2-a
Agent: landing-developer (Z.ai Code)
Task: ساخت لندینگ‌پیج فارسی (RTL) برای افزونه‌ی کروم «وب هایلایتر» در / + API روت اطلاعات افزونه

Work Log:
- src/app/globals.css — بازنویسی متغیرهای primary/ring/accent/secondary به پالت کهربایی (amber-500 روشن / amber-400 تاریک) + گرم‌کردن دارک‌مود (neutral گرم)، فونت Vazirmatn/Tahoma روی body، html{scroll-behavior:smooth}، اسکرول‌بار سفارشی .custom-scrollbar (amber) برای لیست‌های بلند، کلاس .hl-mock برای هایلایت‌های ماکاپ
- src/app/layout.tsx — `<html lang="fa" dir="rtl" suppressHydrationWarning>`، metadata فارسی، تگ link فونت Vazirmatn از Google Fonts در head (بدون next/font طبق قرارداد)، حذف Geist/next-font، ThemeProvider (next-themes، attribute=class، default=system، enableSystem، disableTransitionOnChange) + Toaster
- src/components/theme-provider.tsx — پوشش کلاینت next-themes
- src/app/api/extension/info/route.ts — دقیقاً طبق قرارداد: dynamic=force-dynamic، stat فایل public/downloads/highlighter-extension-v1.0.0.zip، پاسخ {ok,app,version,fileName,downloadUrl,sizeBytes}
- src/components/landing/constants.ts — APP_NAME/APP_VERSION/DOWNLOAD_URL
- src/components/landing/section.tsx — FadeIn (framer-motion whileInView fade-in-up)، LandingSection (container + scroll-mt-20)، SectionHeading
- src/components/landing/header.tsx — sticky + backdrop-blur، لوگوی amber با آیکون Highlighter، منو (features/demo/install/backup/architecture/faq) فقط lg، دکمه‌ی دانلود همیشه + toggle تم (آیکون Sun/Moon با CSS dark: → بدون hydration mismatch)
- src/components/landing/hero.tsx — Badge نسخه، H1 با مارکر کهربایی، زیرعنوان دقیق طبق بریف، دکمه‌های دانلود (.zip) + دموی زنده، fetch('/api/extension/info') client-side برای نمایش حجم فایل (null → «— KB»، ارقام فارسی)، ۳ stat با جداکننده؛ ماکاپ CSS مرورگر (قاب + نوار آدرس ltr blog.example.com/article + آیکون افزونه در نوار) با مقاله‌ی ساختگی + هایلایت زرد/سبز + تولبار شناور ۵ دات رنگی (دقیقاً رنگ‌های HL.COLORS + Tooltip نام رنگ‌ها + آیکون یادداشت/حذف) + پاپ‌اور یادداشت «ایده‌ی کلیدی: خواندن یعنی گفت‌وگو با نویسنده» + انیمیشن float ملایم ۶ ثانیه‌ای
- src/components/landing/demo-section.tsx — قرارداد DOM دقیقاً رعایت شد: #hl-demo-root > #hl-demo-article (dangerouslySetInnerHTML با DEMO_HTML ثابتِ دست‌نخورده + className="text-lg leading-9 text-foreground/90 space-y-5") + .demo-controls با #hl-demo-reload / #hl-demo-clear / #hl-demo-status + `<Script src="/demo/demo.js" strategy="afterInteractive" />`؛ DemoArticle با React.memo و بدون هیچ state/props تا DOM توسط vanilla JS دستکاری شود بدون re-render؛ راهنمای ۳ مرحله‌ای، یادداشت localStorage، باکس «قابلیت‌های قابل تست» با ۵ آیتم چک‌دار
- src/components/landing/features.tsx — ۶ کارت (Palette/StickyNote/ShieldCheck/DatabaseBackup/RefreshCw/LayoutDashboard) + ۵ chip + کارت «مقایسه سریع» با Switch (نمایش/پنهان‌کردن ستون سرویس‌های اشتراکی — ۵ ردیف Check/X)
- src/components/landing/install-section.tsx — ۴ گام با شماره‌ی بزرگ amber، چیپ‌های dir="ltr" برای chrome://extensions و Load unpacked، دکمه‌ی دانلود مجدد در گام ۱، نکته‌ی pin + هشدار Badge destructive برای file://
- src/components/landing/backup-section.tsx — دو کارت خروجی پشتیبان/بازیابی + کارت پهن «حریم خصوصی» با Separator و مجوزهای storage/activeTab
- src/components/landing/architecture-section.tsx — ۴ باکس ماژول (Content Script/Service Worker/Storage/Dashboard & Popup) + پایپ‌لاین RTL با ArrowLeft (انتخاب متن → انکُر سه‌لایه → ذخیره‌ی محلی → بازیابی+خودترمیمی) + جمله‌ی ترتیب createdAt
- src/components/landing/faq-section.tsx — Accordion با ۷ سوال/پاسخ دقیق طبق بریف، داخل max-h-96 + custom-scrollbar
- src/components/landing/cta-section.tsx — کارت گرادیان amber/orange بزرگ «از همین امروز، بدون اشتراک بخوانید.» + دکمه دانلود سفید
- src/components/landing/footer.tsx — mt-auto (sticky bottom) + pb-[env(safe-area-inset-bottom)]، لوگو + نسخه ۱.۰.۰ + «ساخته‌شده با ❤ برای خوانندگان وب» + لینک دانلود
- src/app/page.tsx — صفحه‌ی کامل: div.min-h-screen.flex.flex-col > Header + main(flex-1 با ۸ بخش به‌ترتیب بریف) + Footer(mt-auto)

راستی‌آزمایی (agent-browser + curl):
- GET / 200؛ بدون خطای hydration/صفحه‌ی سفید؛ console تمیز (فقط DevTools/HMR)؛ خطای 404 برای /demo/demo.js طبق انتظار (تسک ۳ می‌سازدش)
- GET /api/extension/info 200 → sizeBytes:null (zip هنوز نیست) → hero نمایش «— KB»
- dir=rtl/lang=fa، فونت Vazirmatn اعمال‌شده، --primary کهربایی
- toggle دارک‌مود: html.dark + پس‌زمینه/کارت تاریک شد؛ فوتر: bottom=900=h دقیقاً viewport در انتهای صفحه؛ موبایل 375px: بدون overflow افقی؛ Accordion و Switch مقایسه کلیک‌شدنی و سالم
- اسکرین‌شات hero/کامل/موبایل/دارک با VLM بازبینی شد: بدون عنصر شکسته/همپوشانی، پالت بدون آبی

Lint: `bun run lint` → صفر خطا/هشدار در فایل‌های src (۵ خطای باقی‌مانده فقط در extension/shared/ui.js مربوط به تسک هسته‌ی افزونه است — طبق قانون دست‌نخورده). هشدار no-page-custom-font با disable فایل‌سراسری در layout حل شد (قاعده‌ی pages/ است).

تصمیم‌های مهم:
- متغیرهای shadcn (--primary/--ring/--accent) در globals.css به کهربایی تغییر کرد تا همه‌ی کامپوننت‌ها (Button/Badge/Switch…) خودکار amber باشند بدون hardcode
- آیکون‌های تم با کلاس dark:/hidden رندر می‌شوند (بدون mounted-state) → صفر hydration mismatch
- DEMO_HTML و ساختار #hl-demo-root بایت‌به‌بایت طبق قرارداد؛ DemoArticle ایستا (React.memo) تا demo.js (تسک ۳) DOM را آزادانه دستکاری کند
- رنگ‌های تولبار ماکاپ = رنگ‌های واقعی HL.COLORS (f5b800/58b85c/35b3ae/e5679b/a478e8)
- status دمو با ms-auto در انتهای سطر کنترل‌ها (کنار چپ در RTL)

Stage Summary:
- لندینگ‌پیج فارسی RTL کامل با ۱۰ بخش بریف‌شده + API اطلاعات افزونه آماده است؛ دموی زنده منتظر /demo/demo.js (تسک ۳) است — DOM contract رعایت‌شده و تست‌شده

---
Task ID: 2-b
Agent: sub-agent (developer)
Task: توسعه‌ی صفحات کروم افزونه — Popup + Dashboard + Service Worker

Work Log:
- خواندن worklog.md و قرارداد HL (constants/utils/store) + مرور content.js برای هم‌ترازی پیام‌ها (GOTO/GET_COUNT/HIGHLIGHT_SELECTION/COUNT_REPORT) و manifest.json (بدون تغییر)
- ساخت popup/popup.html|css|js — عرض ۳۷۰px / ارتفاع ۵۶۰px با اسکرول داخلی، ۵ حالت رندر (عادی/بدون-url/غیرقابل‌پشتیبانی/خالی):
  - هدر: لوگوی SVG ماژیک + badge نسخه از getManifest().version + دکمه‌ی داشبورد
  - کارت صفحه‌ی فعلی (title/host + chip هایلایت/یادداشت) با favicon-letter
  - سوئیچ «فعال در این سایت» (role=switch, aria-checked) روی settings.disabledHosts + پیام inline «اعمال شد ✓» + متن ریز رفرش
  - لیست حداکثر ۸ هایلایت (sorted updatedAt desc): دات رنگ از HL.COLORS[k].dot، متن ۸۰ کاراکتر (textContent)، آیکون StickyNote اگر note، fmtDateTime؛ کلیک → sendMessage(GOTO).then(close).catch(window.open(url + '#hlx-goto-' + id))
  - «خروجی پشتیبان» → exportData → downloadText(backupFileName) + توست داخلی
  - chrome.* همه با callback + try/catch + مصرف runtime.lastError (queryTabs/sendToTab/createTab)
- ساخت dashboard/dashboard.html|css|js (حدود ۸۵۰ خط JS، ۷۰۰ خط CSS):
  - هدر چسبان + دکمه‌های خروجی/بازیابی/تنظیمات + badge حجم داده (getBytesInUse → بایت/کیلوبایت/مگابایت فارسی)
  - ۴ کارت آمار (کل/یادداشت/صفحات یکتا urlNorm/سایت‌های یکتا host)
  - نوار فیلتر: جست‌وجوی debounce شده + chips رنگ ۵تایی چندانتخابی + toggle «فقط یادداشت‌دار» + select مرتب‌سازی (newest/oldest/page)
  - لیست گروه‌بندی بر اساس urlNorm با collapse در حافظه (Set) + favicon-letter + chips + «حذف همه‌ی این صفحه» دومرحله‌ای؛ آیتم: نوار رنگ 4px سمت راست (inset-inline-start) + متن ۲۰۰ + باکس سبز note با آیکون quote (۳۰۰) + تاریخ + دکمه‌های مشاهده/کپی/حذف (کپی با clipboard + fallback execCommand)
  - pagination ساده: نمایش ۵۰ آیتم + «بارگذاری بیشتر (+۵۰)» + «…n مورد دیگر» در گروه ناقص
  - Import: file input مخفی → FileReader → JSON.parse → اعتبارسنجی app==='web-highlighter' → مودال مرکزی (خلاصه: نام/تعداد/تاریخ خروجی/نسخه + radio merge/replace با warning قرمز) → importData → توست «n اضافه، m به‌روزرسانی، k رد شد» → reload کامل
  - Drawer تنظیمات سمت چپ (open/close + overlay + Esc): ۵ دات رنگ (role=radio، active با رینگ amber)، toggle های showToolbar/showBadge، chips سایت‌های غیرفعال با × + افزودن دامنه با sanitize/اعتبارسنجی
  - Danger zone قرمز با تایید سه‌مرحله‌ای: دکمه → «مطمئنی؟» → تایپ کلمه «حذف» → clearAll()؛ نکته: تنظیمات کاربر بعد از clearAll با setSettings(settings) بازیابی می‌شود (clearAll کلیدهای hlx:settings را هم پاک می‌کند)
  - همگام‌سازی زنده: onRecordsChanged(debounce(reload, 400)) + onSettingsChanged → رندر مجدد
- ساخت background/service-worker.js (module):
  - import های side-effect: constants.js، utils.js، store.js (آخری برای getSettings/onSettingsChanged لازم بود — export ندارند پس import مجاز)
  - contextMenus: id ثابت 'hlx-highlight-selection' با title «✨ هایلایت «%s»» در onInstalled + onStartup (try/catch + مصرف lastError برای id تکراری)
  - onClicked و commands('highlight-selection') → tabs.query({active,currentWindow}) → sendMessage(HIGHLIGHT_SELECTION)
  - onMessage: COUNT_REPORT از sender.tab → badge با cache تنظیمات (invalidated با onSettingsChanged/onRecordsChanged)، setBadgeBackgroundColor('#b45309')، showBadge=false → متن خالی؛ listener همیشه return false (بدون پاسخ)
  - tabs.onUpdated(complete) + onActivated → GET_COUNT با یک retry 1200ms (رِیس با document_idle)
  - بدون state سرکش؛ همه‌ی promise ها settle/.catch شده
- رفع: eslint.config.mjs → افزودن extension/** و mini-services/** به ignores (فایل‌های افزونه classic-script هستند و ربطی به lint اپ Next ندارند؛ خطای قبلی no-this-alias فقط از shared/ui.js تسک ۲ بود)
- راستی‌آزمایی: cross-check خودکار id های JS↔HTML (۲۴ popup / ۳۸ dashboard — همه موجود) + بازبینی چشمی syntax + bun run lint سبز + dev.log سالم (GET / 200)

Files Created:
- extension/popup/popup.html
- extension/popup/popup.css
- extension/popup/popup.js
- extension/dashboard/dashboard.html
- extension/dashboard/dashboard.css
- extension/dashboard/dashboard.js
- extension/background/service-worker.js
- تغییر جزئی: eslint.config.mjs (افزودن ignores)

Decisions / Notes:
- SW علاوه بر constants/utils، store.js را هم side-effect import می‌کند چون قرارداد badge نیازمند HL.store.getSettings است؛ فایل‌های shared بدون export هستند و import آن‌ها معتبر است
- بعد از danger-zone clearAll، تنظیمات کاربر دوباره setSettings می‌شود تا «حذف هایلایت‌ها» تنظیمات را پاک نکند
- بعد از تغییر فیلترها visibleLimit به ۵۰ برمی‌گردد؛ در reload زنده (تب دیگر) state فیلتر/collapse حفظ می‌شود
- «بارگذاری بیشتر» سطح-آیتم است: اگر مرز ۵۰ وسط گروه بیفتد، گروه ناقص با «…n مورد دیگر» رندر می‌شود
- :has() در CSS فقط enhancement است (radio های مودال بدون آن هم با accent-color انتخاب را نشان می‌دهند)؛ برای Chrome 102 ایمن
- goto در popup: در صورت reject (صفحه بدون content script مثل file:// بدون دسترسی) → window.open با هش + fallback chrome.tabs.create
- popup در صفحات غیر http/https/file (مثل chrome://) فقط پیام + دکمه‌ی داشبورد نشان می‌دهد (footer مخفی می‌شود طبق spec)

Issues Seen:
- خطای eslint قبلی (no-this-alias) از extension/shared/ui.js (تسک ۲) بود؛ چون فایل‌های افزونه خارج از اپ Next هستند با ignore حل شد (به کد هسته دست نزدم)
- در dev.log یک 404 برای /demo/demo.js دیده شد که مربوط به کار تسک ۲-a (لندینگ) است، نه این تسک

Stage Summary:
- هر ۷ فایل تسک ۲-b آماده‌اند؛ افزونه از نظر منطق کامل است (هسته ۲ + رابط‌ها ۲-b) و مانده: آیکون‌ها/zip (تسک ۳) و راستی‌آزمایی مرورگر (تسک ۴)
---
Task ID: 3
Agent: main (Z.ai Code)
Task: آیکون‌ها + اسکریپت دموی زنده + بسته‌بندی zip

Work Log:
- ساخت public/ext-icons/logo.svg (ماجیک روی پس‌زمینه‌ی گرادیان کهربایی) و رندر PNG با sharp (scripts/make-icons.mjs): icon16/32/48/128 برای افزونه + logo-512 + src/app/icon.png (favicon)
- نوشتن public/demo/demo.js: همان موتور هسته (textindex/domwrap/ui) با adapter برای localStorage، محدود به #hl-demo-article، seed سه هایلایت نمونه + selftest با ?hlx-selftest=1 + API تست (__hlDemo)
- کپی کتابخانه‌های مشترک به public/demo/lib/ (constants, utils, textindex, domwrap, ui, mark-style.css)
- بسته‌بندی zip: public/downloads/highlighter-extension-v1.0.0.zip (۶۲KB، محتوا در پوشه‌ی web-highlighter/ برای Load unpacked تمیز)
- افزودن public/demo/** و scripts/** به ignores اسکریپت eslint → bun run lint کاملاً سبز
- node --check روی هر ۱۰ فایل JS افزونه + اعتبارسنجی JSON مانیفست → همه OK
- بررسی قرارداد HL API بین popup/dashboard/SW و هسته → منطبق

Stage Summary:
- افزونه کامل و قابل نصب (zip + پوشه‌ی extension/)
- دموی زنده‌ی داخل سایت با همان کد هسته‌ی افزونه

---
Task ID: 4
Agent: main (Z.ai Code)
Task: راستی‌آزمایی end-to-end با Agent Browser

Work Log:
- GET / → 200؛ رندر کامل RTL فارسی، بدون خطای hydration؛ کنسول و errors کاملاً تمیز
- خودآزمایی (?hlx-selftest=1): «✅ خودآزمایی موفق — 2 هایلایت و 1 یادداشت پس از «رفرش» بازیابی شد» (دو بار: بار اول و بعد از reload واقعی)
- کلیک روی mark → پاپ‌اور باز شد با quote و یادداشت (note-box has) ✓
- ویرایش یادداشت + ذخیره → localStorage به‌روز شد ✓
- انتخاب متن + mouseup → نوار ابزار ۷ دکمه ظاهر شد ✓؛ کلیک رنگ teal → هایلایت جدید ساخته شد ✓
- دکمه‌ی «بازخوانی هایلایت‌ها» → unwrap کامل + بازیابی ۳/۳ ✓
- رفرش واقعی صفحه → دمو دوباره بوت و هایلایت‌ها برگشتند ✓
- تعویض تم دارک/لایت ✓؛ آکاردئون FAQ با کلیک واقعی باز شد ✓
- لینک دانلود zip → 200؛ /api/extension/info → JSON درست با sizeBytes=62030 ✓
- موبایل 390px: بدون overflow افقی؛ فوتر در پایین سند و sticksToBottom=true در انتهای صفحه ✓
- diff بین zip و پوشه‌ی extension → همگام ✓
- VLM روی اسکرین‌شات بخش دمو: هایلایت‌های رنگی مرئی، چیدمان تمیز، پالت کهربایی بدون آبی ✓

Stage Summary:
- کل مسیر طلایی (highlight → note → reload → restore → backup link) در مرورگر تأیید شد
- پروژه آماده‌ی تحویل است
---
Task ID: 5
Agent: main (Z.ai Code)
Task: خط زیرین هایلایت فقط برای هایلایت‌های دارای یادداشت (درخواست کاربر)

Work Log:
- تحلیل ریشه: underline در mark-style.css فقط در @media(prefers-color-scheme:dark) روی «همه‌ی» mark ها اعمال می‌شد (border-bottom رنگی)
- طراحی قرارداد جدید: خط زیرین = نشانگر «یادداشت دارد» → اتریبیوت data-hl-noted="1" روی المان mark (هم‌الگوی data-hl-color)
- domwrap.js: افزودن setNoted(id, hasNote) متقارن با setColor + خروجی HL.dom + مستندسازی هدر
- mark-style.css: بازنویسی — خط زیرین فقط با selector [data-hl-noted="1"]؛ در دارک از قانون پایه حذف شد (border-bottom:none) و در لایت قانون جدید هم‌رنگِ رنگ هایلایت اضافه شد (amber/green/teal/pink/purple در هر دو تم؛ ترتیب و specificity قواعد بررسی شد)
- content.js: helper hasNote(rec) + فراخوانی setNoted در applyRecord (بازیابی)، onSaveNote (افزودن/خالی‌کردن)، syncFromStorage (تغییر از تب دیگر/ایمپورت بک‌آپ — مقایسه‌ی presence نه متن خام)
- همگام‌سازی دمو: کپی domwrap.js و mark-style.css به public/demo/lib/ + demo.js (applyRecord، createFromRange برای seed، onSaveNote، __hlDemo.note) + تقویت selftest با شرط notedOk (m1 همه data-hl-noted دارند، m2 هیچ)
- لندینگ: hero mock کهربایی (جفت‌شده با پاپ‌اور یادداشت) border-b-2 گرفت؛ سبز بدون یادداشت نه؛ کپی features و GUIDE_STEPS و TESTABLE به‌روز
- نسخه 1.0.0→1.0.1: manifest، constants.js، popup.html، dashboard.html، landing constants.ts؛ API route بازنویسی شد تا APP_VERSION/DOWNLOAD_URL را از منبع واحد import کند (حذف hardcoded)؛ zip جدید v1.0.1 (62696 bytes، ساختار web-highlighter/) و حذف zip قدیمی
- راستی‌آزمایی: node --check همه‌ی ۱۰+ فایل JS سبز؛ JSON manifest معتبر؛ diff zip↔پوشه همگام؛ bun run lint سبز؛ dev.log سالم
- Agent Browser E2E: selftest جدید پاس (notedOk)؛ seed=۳ هایلایت/۲ noted؛ کلیک واقعی ماوس روی mark سبز→پاپ‌اور→تایپ یادداشت→ذخیره→data-hl-noted=1 + border-bottom:2px solid rgba(21,94,50,.45)؛ حذف یادداشت→اتریبیوت رفت و width=0؛ رفرش کامل→وضعیت پایدار؛ دارک: noted ها ۲px رنگی، بدون یادداشت ۰px؛ VLM روی اسکرین‌شات لایت و دارک تأیید بصری؛ کنسول/ارور خالی؛ موبایل 390px بدون overflow؛ فوتر درست (push طبیعی در صفحه‌ی بلند + atBottom در انتهای اسکرول)؛ /api/extension/info نسخه‌ی 1.0.1 با sizeBytes واقعی

Stage Summary:
- رفتار جدید: underline فقط برای هایلایت‌های دارای یادداشتِ غیرخالی؛ با خالی‌شدن/حذف یادداشت فوراً برمی‌گردد؛ در لایت و دارک و بعد از رفرش و بین تب‌ها هماهنگ است
- بسته‌ی v1.0.1 آماده و جایگزین v1.0.0 شد؛ API از منبع واحد نسخه می‌گیرد
- یادداشت: «solid» در computed style برای mark بدون یادداشت فقط از preflight تیلویند است (width=0 → نامرئی)
---
Task ID: 6
Agent: main (Z.ai Code)
Task: باگ «شبح نوار ابزار در گوشه بالا-چپ صفحه» — تحلیل ریشه + اصلاح

Work Log:
- بازتولید باگ با Agent Browser (لود خام، صفر تعامل): toolbar با computed display:flex و ۲۲۸×۴۴px در y=0 رندر شده (در صفحات RTL بیرون‌زده از چپ؛ در سایت‌های LTR دقیقاً گوشه بالا-چپ = گزارش کاربر) + پوسته‌ی خالی popover با display:block و ۳۲۸×۲px — هر دو مرئی و کلیک‌پذیر (pointer-events:auto)
- ریشه در کد: سازنده‌ی FloatingToolbar/NotePopover در ui.js عنصر را به shadow DOM اضافه می‌کنند و CSS فوراً آن را مرئی می‌کند (hlx-tb: display:flex؛ hlx-po: block پیش‌فرض)؛ سازنده هرگز dismiss() صدا نمی‌زند؛ top/left فقط در position() و آن فقط از present() (نیازمند متن انتخاب‌شده) → عنصر در static position (گوشه‌ی صفحه) می‌ماند؛ dismiss فقط به selectionchange/Escape وصل است → تا اولین کلیک کاربر شبح باقی می‌ماند
- پلن: invariant کتابخانه‌ای «ساخت = مخفی؛ نمایش فقط از طریق present()» — هم‌الگوی قرارداد inline-style موجود (present → 'flex'/'block'، dismiss → 'none')
- پیاده‌سازی در ui.js (سطح کتابخانه → همه‌ی مصرف‌کنندگان: content script افزونه + دموی سایت): el.style.display='none' در سازنده‌ی هر دو کامپوننت + مستندسازی invariant در هدر فایل
- نکته: override نهایی present برای popover (display:'block') از قبل وجود داشت و حالا هم برای اولین present لازم است — بدون تغییر ماند
- همگام‌سازی: کپی ui.js به public/demo/lib/ + node --check سبز
- نسخه 1.0.1→1.0.2 (manifest/constants/popup.html/dashboard.html/landing constants) + بازسازی zip v1.0.2 (62922 bytes) و حذف v1.0.1؛ API از منبع واحد نسخه می‌گیرد
- E2E: لود خام → هر دو display:none و 0px ✓؛ انتخاب متن → toolbar display:flex نزدیک selection (nearSelection=true) ✓؛ collapse → none ✓؛ کلیک روی mark → popover باز ✓؛ selftest پاس ✓؛ کنسول/ارور خالی ✓؛ VLM روی اسکرین‌شات لود خام: GHOST-TOOLBAR=no, STRAY-DIALOG=no ✓
- حین کار MultiEdit اول یک ادیت هم‌پوشان اشتباه نوشتم که اگر اعمال می‌شد listener های کلیک toolbar را حذف می‌کرد؛ خوشبختانه شکست خورد (old_str بعد از ادیت قبلی match نبود) — listener ها سالم ماندند و کامنت mousedown برگردانده شد

Stage Summary:
- شبح toolbar و پوسته popover در لود صفحات کامل حذف شد؛ رفتار نمایش فقط با انتخاب متن / کلیک روی هایلایت
- افزونه v1.0.2 و zip همگام؛ دموی سایت همان کتابخانه‌ی اصلاح‌شده را سرو می‌کند
- درس فرایندی: بعد از هر MultiEdit فایل را بازخوانی و صحت listener ها را چک کردم
