/**
 * وب هایلایتر — دموی زنده‌ی داخل وب‌سایت
 * همان موتور هسته‌ی افزونه (textindex + domwrap + ui) را روی مقاله‌ی دمو اجرا می‌کند،
 * اما به‌جای chrome.storage از localStorage استفاده می‌کند.
 * محدوده: فقط داخل #hl-demo-article
 *
 * قابلیت ویژه: با پارامتر ?hlx-selftest=1 یک خودآزمایی کامل
 * (هایلایت → یادداشت → پاک‌سازی DOM → بازیابی) اجرا و نتیجه را در
 * #hl-demo-status نمایش می‌دهد.
 */
(function () {
  'use strict';

  var LIBS = [
    '/demo/lib/constants.js',
    '/demo/lib/utils.js',
    '/demo/lib/textindex.js',
    '/demo/lib/domwrap.js',
    '/demo/lib/ui.js'
  ];

  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement('script');
      s.src = src;
      s.onload = function () { res(); };
      s.onerror = function () { rej(new Error('load fail: ' + src)); };
      document.head.appendChild(s);
    });
  }

  function injectStyle() {
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = '/demo/lib/mark-style.css';
    document.head.appendChild(l);
  }

  function boot() {
    if (window.__hlxDemoBooted) return;
    window.__hlxDemoBooted = true;

    var article = null;
    var tries = 0;
    var waitFor = function (cb) {
      article = document.getElementById('hl-demo-article');
      if (article) return cb();
      if (tries++ > 60) return; // ~12s
      setTimeout(function () { waitFor(cb); }, 200);
    };

    waitFor(function () {
      if (!article) return;
      injectStyle();
      initDemo();
    });
  }

  function initDemo() {
    var HL = globalThis.HL;
    var article = document.getElementById('hl-demo-article');
    var statusEl = document.getElementById('hl-demo-status');
    var LS_KEY = 'hlx:demo:v1';
    var DEMO_PAGE = { url: 'demo', norm: 'demo', site: 'demo', host: 'demo.local', title: 'دموی زنده — وب هایلایتر' };

    var state = {
      recs: new Map(),
      ti: null
    };

    /* ---------- ذخیره‌سازی محلی ---------- */

    function load() {
      try {
        var raw = localStorage.getItem(LS_KEY);
        var o = raw ? JSON.parse(raw) : {};
        state.recs = new Map(Object.entries(o.highlights || {}));
      } catch (e) {
        state.recs = new Map();
      }
    }

    function persist() {
      try {
        var highlights = {};
        state.recs.forEach(function (r, id) { highlights[id] = r; });
        localStorage.setItem(LS_KEY, JSON.stringify({ highlights: highlights }));
      } catch (e) { /* quota */ }
      renderStatus();
    }

    /* ---------- وضعیت ---------- */

    /* آیا این رکورد یادداشت غیرخالی دارد؟ (نشانگر خط زیرین) */
    function hasNote(rec) {
      return !!(rec && rec.note && String(rec.note).trim());
    }

    function noteCount() {
      var n = 0;
      state.recs.forEach(function (r) { if (r.note && r.note.trim()) n++; });
      return n;
    }

    function renderStatus(extra) {
      if (!statusEl) return;
      var base = state.recs.size + ' هایلایت · ' + noteCount() + ' یادداشت — ذخیره‌شده در localStorage مرورگر شما';
      statusEl.textContent = extra ? (extra + ' — ' + base) : base;
    }

    /* ---------- ایندکس و انکُرینگ ---------- */

    function freshIndex() {
      state.ti = HL.text.build(article);
      return state.ti;
    }

    function applyRecord(rec) {
      if (HL.dom.marksOf(rec.id).filter(inArticle).length) return true;
      var range = HL.dom.resolveAnchor(rec.anchor, rec.text);
      if (!range) {
        if (!state.ti) freshIndex();
        var located = HL.text.findRange(state.ti, rec);
        range = located && located.range;
        if (range && located) {
          rec.anchor = HL.dom.serializeRange(range);
          rec.start = located.start;
          rec.end = located.end;
        }
      }
      if (!range) return false;
      if (!article.contains(range.startContainer) || !article.contains(range.endContainer)) return false;
      var marks = HL.dom.markRange(range, rec.id, rec.color);
      if (marks.length) HL.dom.setNoted(rec.id, hasNote(rec)); // خط زیرین = نشانگر یادداشت
      state.ti = null;
      return marks.length > 0;
    }

    function inArticle(m) { return article.contains(m); }

    function applyAll() {
      freshIndex();
      var arr = Array.from(state.recs.values()).sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
      var ok = 0;
      for (var i = 0; i < arr.length; i++) {
        if (applyRecord(arr[i])) ok++;
      }
      return ok;
    }

    /* ---------- ساخت هایلایت ---------- */

    function createFromRange(range, text, color, note) {
      var ti = freshIndex();
      var offs = ti.offsetsOfRange(range);
      if (!offs) return null;
      var id = HL.util.newId();
      var now = Date.now();
      var rec = {
        id: id,
        host: DEMO_PAGE.host,
        site: DEMO_PAGE.site,
        url: DEMO_PAGE.url,
        urlNorm: DEMO_PAGE.norm,
        title: DEMO_PAGE.title,
        text: text,
        prefix: ti.text.slice(Math.max(0, offs.start - 32), offs.start),
        suffix: ti.text.slice(offs.end, offs.end + 32),
        start: offs.start,
        end: offs.end,
        anchor: HL.dom.serializeRange(range),
        color: color,
        note: note || '',
        createdAt: now,
        updatedAt: now
      };
      var marks = HL.dom.markRange(range, id, color);
      if (!marks.length) return null;
      if (note && String(note).trim()) HL.dom.setNoted(id, true);
      state.ti = null;
      state.recs.set(id, rec);
      persist();
      return rec;
    }

    function createFromQuote(quote, color, note) {
      var ti = freshIndex();
      var located = HL.text.findRange(ti, { text: quote });
      if (!located) return null;
      return createFromRange(located.range, located.range.toString(), color, note);
    }

    /* ---------- UI ---------- */

    var popoverOpen = false;
    var popover = new HL.ui.NotePopover({
      onColorChange: function (id, color) {
        var rec = state.recs.get(id);
        if (!rec) return;
        rec.color = color;
        rec.updatedAt = Date.now();
        HL.dom.setColor(id, color);
        persist();
      },
      onSaveNote: function (id, note) {
        var rec = state.recs.get(id);
        if (!rec) return;
        rec.note = note;
        rec.updatedAt = Date.now();
        HL.dom.setNoted(id, hasNote(rec)); // افزودن/برداشتن خط زیرین
        persist();
      },
      onDelete: function (id) {
        HL.dom.unwrap(id);
        state.recs.delete(id);
        persist();
        HL.ui.Toast.show('هایلایت حذف شد.');
      },
      onCopy: function (id) {
        var rec = state.recs.get(id);
        if (!rec) return;
        var t = rec.text + (rec.note ? '\n\n📝 یادداشت: ' + rec.note : '');
        if (navigator.clipboard) navigator.clipboard.writeText(t).catch(function () {});
        HL.ui.Toast.show('کپی شد ✓');
      }
    });
    popover.h.onClose = function () { popoverOpen = false; };

    var toolbar = new HL.ui.FloatingToolbar({
      onColor: function (color, ctx) {
        toolbar.dismiss();
        createFromRange(ctx.range, ctx.text, color, '');
      },
      onNote: function (ctx) {
        toolbar.dismiss();
        var rec = createFromRange(ctx.range, ctx.text, 'yellow', '');
        if (rec) openPopover(rec.id, true);
      },
      onCopy: function (ctx) {
        if (ctx && ctx.text && navigator.clipboard) navigator.clipboard.writeText(ctx.text).catch(function () {});
        HL.ui.Toast.show('کپی شد ✓');
      }
    });

    function openPopover(id, editNow) {
      var rec = state.recs.get(id);
      if (!rec) return;
      var marks = HL.dom.marksOf(id).filter(inArticle);
      if (!marks.length) return;
      toolbar.dismiss();
      popover.present({
        id: id,
        mark: marks[0],
        color: rec.color,
        note: rec.note || '',
        quote: rec.text,
        createdAt: rec.createdAt,
        editNow: !!editNow
      });
      popoverOpen = true;
    }

    /* ---------- انتخاب متن (فقط داخل مقاله‌ی دمو) ---------- */

    function demoSelectionCtx() {
      var sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return null;
      var range = sel.getRangeAt(0);
      if (range.collapsed) return null;
      if (!article.contains(range.startContainer) || !article.contains(range.endContainer)) return null;
      var text = sel.toString();
      if (!text || !text.trim()) return null;
      return { range: range.cloneRange(), text: text };
    }

    var maybeShow = function () {
      if (popoverOpen) return;
      var ctx = demoSelectionCtx();
      if (!ctx) return;
      var r = null;
      try { r = ctx.range.getBoundingClientRect(); } catch (e) { r = null; }
      if (!r || (r.width === 0 && r.height === 0)) return;
      toolbar.present(ctx);
    };
    var onSelEnd = HL.util.debounce(maybeShow, 180);

    article.addEventListener('mouseup', function (e) {
      if (e.button !== 0) return;
      if (e.target && e.target.closest && e.target.closest('mark.hlx-marker')) return;
      setTimeout(onSelEnd, 30);
    }, true);

    document.addEventListener('selectionchange', HL.util.debounce(function () {
      var sel = window.getSelection();
      if (!sel || sel.isCollapsed) {
        if (!popoverOpen) toolbar.dismiss();
      } else if (sel.anchorNode && article.contains(sel.anchorNode)) {
        onSelEnd();
      }
    }, 220));

    article.addEventListener('click', function (e) {
      var t = e.target;
      if (!t || !t.closest) return;
      var mark = t.closest('mark.hlx-marker');
      if (!mark || !article.contains(mark)) return;
      var id = mark.getAttribute('data-hl-id');
      if (!id || !state.recs.get(id)) return;
      var sel = window.getSelection();
      if (sel && !sel.isCollapsed) return;
      e.preventDefault();
      e.stopPropagation();
      openPopover(id);
    }, true);

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        toolbar.dismiss();
        if (popover.mode === 'edit') popover.render('view'); else popover.dismiss();
      }
    }, true);

    /* ---------- کنترل‌ها ---------- */

    function unwrapAll() {
      HL.dom.allMarks().forEach(function (m) {
        if (!article.contains(m)) return;
        var p = m.parentNode;
        while (m.firstChild) p.insertBefore(m.firstChild, m);
        m.remove();
        if (p.normalize) { try { p.normalize(); } catch (err) { /* noop */ } }
      });
    }

    var reloadBtn = document.getElementById('hl-demo-reload');
    if (reloadBtn) reloadBtn.addEventListener('click', function () {
      unwrapAll();
      load();
      var ok = applyAll();
      renderStatus('بازخوانی انجام شد ✓ (' + ok + ' هایلایت بازیابی شد)');
    });

    var clearBtn = document.getElementById('hl-demo-clear');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      unwrapAll();
      state.recs = new Map();
      try { localStorage.removeItem(LS_KEY); } catch (e) { /* noop */ }
      renderStatus('داده‌های دمو پاک شد');
      HL.ui.Toast.show('دمو پاک شد — دوباره متن انتخاب کنید.');
    });

    /* ---------- Seed اولیه (نمایشی) ---------- */

    function seedIfEmpty() {
      if (state.recs.size) return false;
      createFromQuote('مغز ما وارد حالت گفت‌وگو با نویسنده می‌شود', 'yellow', 'ایده‌ی کلیدی: خواندن یعنی گفت‌وگو، نه دریافتِ منفعل.');
      createFromQuote('تا چهل درصد بیشتر از جزئیات مقاله در ذهنش می‌ماند', 'green', '');
      createFromQuote('بدون حساب کاربری، بدون سرور و بدون هیچ اشتراکی', 'pink', 'این دقیقاً همان چیزی است که از یک ابزار شخصی می‌خواهیم.');
      return true;
    }

    /* ---------- خودآزمایی (?hlx-selftest=1) ---------- */

    function selfTest() {
      try {
        // ۱) پاک‌سازی کامل
        unwrapAll();
        state.recs = new Map();
        try { localStorage.removeItem(LS_KEY); } catch (e) { /* noop */ }

        // ۲) ایجاد هایلایت + یادداشت از روی نقل‌قول (همان مسیر ذخیره‌ی واقعی)
        var r1 = createFromQuote('مهم‌ترین جملات را نشانه‌گذاری می‌کند', 'teal', 'یادداشت خودآزمایی');
        var r2 = createFromQuote('همان وابستگی‌ای است که باید شکسته شود', 'purple', '');
        var marksLive = HL.dom.allMarks().filter(inArticle).length;

        // ۳) شبیه‌سازی reload: DOM پاک و فقط از storage بازیابی
        unwrapAll();
        load();
        var restored = applyAll();
        var marksAfter = HL.dom.allMarks().filter(inArticle).length;
        var noteOk = false;
        state.recs.forEach(function (r) { if (r.id === r1.id && r.note === 'یادداشت خودآزمایی') noteOk = true; });

        // ۴) نشانگر خط زیرین: فقط هایلایتِ دارای یادداشت data-hl-noted دارد
        var m1 = HL.dom.marksOf(r1.id).filter(inArticle);
        var m2 = HL.dom.marksOf(r2.id).filter(inArticle);
        var notedOk = !!(
          m1.length && m1.every(function (m) { return m.getAttribute('data-hl-noted') === '1'; }) &&
          m2.length && m2.every(function (m) { return !m.hasAttribute('data-hl-noted'); })
        );

        var pass = !!(r1 && r2 && marksLive >= 2 && restored === state.recs.size && marksAfter === marksLive && noteOk && notedOk);
        var msg = pass
          ? '✅ خودآزمایی موفق — ' + marksAfter + ' هایلایت و ' + noteCount() + ' یادداشت پس از «رفرش» بازیابی شد'
          : '❌ خودآزمایی ناموفق (' + marksLive + '/' + marksAfter + '/' + restored + '/' + noteOk + '/' + notedOk + ')';
        renderStatus(msg);
        statusEl.setAttribute('data-selftest', pass ? 'ok' : 'fail');
        if (window.console) console.log('[hlx-selftest]', msg);
      } catch (e) {
        renderStatus('❌ خودآزمایی با خطا: ' + (e && e.message));
        statusEl.setAttribute('data-selftest', 'fail');
      }
    }

    /* ---------- API برای تست/دستیابی ---------- */

    window.__hlDemo = {
      select: function (quote) { // انتخاب برنامه‌ای متن برای تست
        var ti = freshIndex();
        var located = HL.text.findRange(ti, { text: quote });
        if (!located) return false;
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(located.range);
        return demoSelectionCtx();
      },
      apply: function (color) {
        var ctx = demoSelectionCtx();
        if (!ctx) return null;
        return createFromRange(ctx.range, ctx.text, color || 'yellow', '');
      },
      note: function (id, text) {
        var rec = state.recs.get(id);
        if (!rec) return false;
        rec.note = text;
        rec.updatedAt = Date.now();
        HL.dom.setNoted(id, hasNote(rec));
        persist();
        return true;
      },
      reload: function () { unwrapAll(); load(); return applyAll(); },
      clear: function () { unwrapAll(); state.recs = new Map(); try { localStorage.removeItem(LS_KEY); } catch (e) {} renderStatus('پاک شد'); },
      state: function () { return { highlights: state.recs.size, notes: noteCount() }; }
    };

    /* ---------- شروع ---------- */

    load();
    var seeded = seedIfEmpty();
    applyAll();
    renderStatus(seeded ? 'سه هایلایت نمونه ساخته شد — این‌ها را امتحان کنید!' : undefined);

    var params = new URLSearchParams(location.search);
    if (params.get('hlx-selftest') === '1') setTimeout(selfTest, 400);
  }

  // بارگذاری کتابخانه‌های مشترک و شروع
  (function start() {
    var chain = Promise.resolve();
    LIBS.forEach(function (src) {
      chain = chain.then(function () { return loadScript(src); });
    });
    chain.then(boot).catch(function (e) {
      if (window.console) console.warn('[hlx-demo] init failed', e);
    });
  })();
})();
