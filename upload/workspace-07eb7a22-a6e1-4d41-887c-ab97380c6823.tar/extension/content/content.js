/**
 * وب هایلایتر — اسکریپت محتوا (هماهنگ‌کننده‌ی اصلی روی هر صفحه)
 * وظایف:
 *  - ساخت هایلایت از متن انتخاب‌شده (نوار ابزار شناور / راست‌کلیک / میان‌بر)
 *  - بازیابی خودکار هایلایت‌ها هنگام بازدید مجدد از صفحه (۳ لایه: XPath → متن → fuzzy)
 *  - پاپ‌اور یادداشت با کلیک روی هایلایت
 *  - همگام‌سازی زنده با storage (غیرفعال‌کردن سایت، حذف از داشبورد و…)
 *  - پرش مستقیم به هایلایت با هش #hlx-goto-<id>
 *  - گزارش تعداد به service worker برای badge
 */
(function () {
  'use strict';
  if (window.__hlxContentInit) return;
  window.__hlxContentInit = true;

  var HL = globalThis.HL;
  var page = HL.util.normalizeUrl(location.href);
  if (!page) return; // آدرس قابل نرمال‌سازی نیست (مثل about:blank)

  var state = {
    settings: null,
    disabled: false,
    started: false,
    recs: new Map(),      // id → record (فقط هایلایت‌های همین URL)
    orphaned: new Set(),  // هایلایت‌هایی که هنوز پیدا نشده‌اند
    ti: null,             // ایندکس متن سند (ممکن است کهنه شود)
    retryTimer: null,
    retries: 0,
    saveFailed: false
  };

  /* ---------- ایندکس متن ---------- */

  function freshIndex() {
    state.ti = HL.text.build(document.body);
    return state.ti;
  }

  /* آیا این رکورد یادداشت غیرخالی دارد؟ (نشانگر خط زیرین) */
  function hasNote(rec) {
    return !!(rec && rec.note && String(rec.note).trim());
  }

  /* ---------- خودترمیمی انکُرها (ذخیره‌ی به‌روزرسانی‌ها به‌صورت دسته‌ای) ---------- */

  var healQueue = new Map();
  var flushHeal = HL.util.debounce(function () {
    var arr = Array.from(healQueue.values());
    healQueue.clear();
    if (arr.length) HL.store.saveMany(arr).catch(function () {});
  }, 900);
  function queueHealSave(rec) {
    healQueue.set(rec.id, rec);
    flushHeal();
  }

  /* ---------- اعمال یک رکورد روی DOM ---------- */

  function applyRecord(rec) {
    if (HL.dom.marksOf(rec.id).length) return true; // قبلاً اعمال شده

    // مسیر سریع: XPath
    var range = HL.dom.resolveAnchor(rec.anchor, rec.text);
    var located = null;

    // مسیر متنی (fallback) — ایندکس باید تازه باشد چون wrap قبلی node ها را split کرده
    if (!range) {
      if (!state.ti) freshIndex();
      located = HL.text.findRange(state.ti, rec);
      range = located && located.range;
    }
    if (!range) return false;

    var marks = HL.dom.markRange(range, rec.id, rec.color);
    if (!marks.length) return false;
    HL.dom.setNoted(rec.id, hasNote(rec)); // خط زیرین = نشانگر یادداشت
    state.ti = null; // ساختار متن تغییر کرد؛ ایندکس باید بازسازی شود

    if (located) {
      // خودترمیمی: انکُر و آفست‌های دقیق جدید را ذخیره کن
      rec.anchor = HL.dom.serializeRange(range);
      rec.start = located.start;
      rec.end = located.end;
      queueHealSave(rec);
    }
    return true;
  }

  function applyAllRecords() {
    var arr = Array.from(state.recs.values()).sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
    freshIndex();
    state.orphaned.clear();
    for (var i = 0; i < arr.length; i++) {
      if (!applyRecord(arr[i])) state.orphaned.add(arr[i]);
    }
    scheduleOrphanRetry();
  }

  function scheduleOrphanRetry() {
    clearTimeout(state.retryTimer);
    if (!state.orphaned.size || state.disabled) return;
    if (state.retries >= 12) return;
    state.retryTimer = setTimeout(retryOrphans, state.retries === 0 ? 1200 : 3500);
  }

  function retryOrphans() {
    if (!state.orphaned.size || state.disabled) return;
    state.retries++;
    freshIndex();
    var arr = Array.from(state.orphaned);
    for (var i = 0; i < arr.length; i++) {
      if (applyRecord(arr[i])) state.orphaned.delete(arr[i]);
    }
    scheduleOrphanRetry();
  }

  /* ---------- شمارش و گزارش به SW ---------- */

  function reportCount() {
    try {
      var p = chrome.runtime.sendMessage({ type: HL.MSG.COUNT_REPORT, count: state.recs.size });
      if (p && p.catch) p.catch(function () {});
    } catch (e) { /* SW خواب است یا در دسترس نیست */ }
  }

  /* ---------- کپی ---------- */

  function legacyCopy(t) {
    var ta = document.createElement('textarea');
    ta.value = t;
    ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); HL.ui.Toast.show('کپی شد ✓'); } catch (e) { /* noop */ }
    ta.remove();
  }
  function copyText(t) {
    if (!t) return;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(function () {
        HL.ui.Toast.show('کپی شد ✓');
      }).catch(function () { legacyCopy(t); });
    } else legacyCopy(t);
  }

  /* ---------- ساخت هایلایت ---------- */

  function toast(m) { HL.ui.Toast.show(m); }

  function selectionCtx() {
    var sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    var range = sel.getRangeAt(0);
    if (range.collapsed) return null;
    var text = sel.toString();
    if (!text || !text.trim() || text.length > 30000) return null;

    var sc = range.startContainer, ec = range.endContainer;
    if (!document.body.contains(sc) || !document.body.contains(ec)) return null;

    var inBad = function (n) {
      var el = (n.nodeType === 1) ? n : n.parentElement;
      if (!el || !el.closest) return false;
      return !!(el.closest('[data-hlx-ui]') || el.closest('[contenteditable="true"]'));
    };
    if (inBad(sc) || inBad(ec)) return null;
    return { range: range.cloneRange(), text: text };
  }

  function createHighlight(ctx, color, withNote) {
    if (!ctx || !ctx.range || ctx.range.collapsed) return null;

    var ti = freshIndex();
    var offs = ti.offsetsOfRange(ctx.range);
    if (!offs) { toast('این قسمت از صفحه قابل هایلایت نیست.'); return null; }

    var id = HL.util.newId();
    var now = Date.now();
    var anchor = HL.dom.serializeRange(ctx.range);
    var marks = HL.dom.markRange(ctx.range, id, color);
    if (!marks.length) { toast('این قسمت از صفحه قابل هایلایت نیست.'); return null; }
    state.ti = null;

    var rec = {
      id: id,
      host: page.host,
      site: page.site,
      url: page.url,
      urlNorm: page.norm,
      title: (document.title || '').slice(0, 300),
      text: ctx.text,
      prefix: ti.text.slice(Math.max(0, offs.start - 32), offs.start),
      suffix: ti.text.slice(offs.end, offs.end + 32),
      start: offs.start,
      end: offs.end,
      anchor: anchor,
      color: color,
      note: '',
      createdAt: now,
      updatedAt: now
    };

    state.recs.set(id, rec);
    HL.store.save(rec).then(reportCount).catch(function () {
      if (!state.saveFailed) { state.saveFailed = true; toast('ذخیره‌سازی با خطا مواجه شد.'); }
    });

    if (withNote) openPopover(id, { editNow: true, mark: marks[0] });
    return rec;
  }

  /* ---------- نوار ابزار انتخاب متن ---------- */

  var popoverOpen = false;
  var popover = new HL.ui.NotePopover({
    onColorChange: function (id, color) {
      var rec = state.recs.get(id);
      if (!rec) return;
      rec.color = color;
      rec.updatedAt = Date.now();
      HL.dom.setColor(id, color);
      HL.store.save(rec).catch(function () {});
    },
    onSaveNote: function (id, note) {
      var rec = state.recs.get(id);
      if (!rec) return;
      rec.note = note;
      rec.updatedAt = Date.now();
      HL.dom.setNoted(id, hasNote(rec)); // افزودن/برداشتن خط زیرین
      HL.store.save(rec).then(reportCount).catch(function () {});
    },
    onDelete: function (id) {
      var rec = state.recs.get(id);
      if (!rec) return;
      HL.dom.unwrap(id);
      state.recs.delete(id);
      state.orphaned.delete(id);
      HL.store.remove(id, page.host).then(reportCount).catch(function () {});
      toast('هایلایت حذف شد.');
    },
    onCopy: function (id) {
      var rec = state.recs.get(id);
      if (rec) copyText(rec.text + (rec.note ? '\n\n📝 یادداشت: ' + rec.note : ''));
    }
  });
  popover.h.onClose = function () { popoverOpen = false; };

  var toolbar = new HL.ui.FloatingToolbar({
    onColor: function (color, ctx) {
      toolbar.dismiss();
      createHighlight(ctx, color, false);
    },
    onNote: function (ctx) {
      toolbar.dismiss();
      createHighlight(ctx, (state.settings && state.settings.defaultColor) || 'yellow', true);
    },
    onCopy: function (ctx) { copyText(ctx && ctx.text); }
  });

  function maybeShowToolbar() {
    if (state.disabled || !state.settings || !state.settings.showToolbar) return;
    if (popoverOpen) return;
    var ctx = selectionCtx();
    if (!ctx) return;
    var r = null;
    try { r = ctx.range.getBoundingClientRect(); } catch (e) { r = null; }
    if (!r || (r.width === 0 && r.height === 0)) return;
    toolbar.present(ctx);
  }

  var onSelEnd = HL.util.debounce(maybeShowToolbar, 180);

  document.addEventListener('mouseup', function (e) {
    if (e.button !== 0) return;
    if (e.target && e.target.closest && e.target.closest('mark.hlx-marker')) return; // کلیک روی هایلایت
    setTimeout(onSelEnd, 30);
  }, true);

  document.addEventListener('selectionchange', HL.util.debounce(function () {
    var sel = window.getSelection();
    if (!sel || sel.isCollapsed) {
      if (!popoverOpen) toolbar.dismiss();
    } else {
      onSelEnd();
    }
  }, 220));

  window.addEventListener('scroll', function () {
    if (toolbar.visible) toolbar.position();
  }, { passive: true, capture: true });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      toolbar.dismiss();
      if (popover.mode === 'edit') popover.render('view'); else popover.dismiss();
    }
  }, true);

  /* ---------- پاپ‌اور با کلیک روی هایلایت ---------- */

  function openPopover(id, opts) {
    var rec = state.recs.get(id);
    if (!rec) return;
    var mark = HL.dom.marksOf(id)[0];
    if (!mark && !(opts && opts.mark)) return;
    toolbar.dismiss();
    popover.present({
      id: id,
      mark: mark || (opts && opts.mark),
      color: rec.color,
      note: rec.note || '',
      quote: rec.text,
      createdAt: rec.createdAt,
      editNow: !!(opts && opts.editNow)
    });
    popoverOpen = true;
  }

  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    var mark = t.closest('mark.hlx-marker');
    if (!mark) return;
    var id = mark.getAttribute('data-hl-id');
    if (!id || !state.recs.get(id)) return;
    var sel = window.getSelection();
    if (sel && !sel.isCollapsed) return; // کاربر در حال انتخاب متن است
    e.preventDefault();
    e.stopPropagation();
    openPopover(id);
  }, true);

  /* ---------- پرش به هایلایت با هش ---------- */

  function gotoHighlight(id, cleanHash) {
    var attempt = 0;
    var tryScroll = function () {
      var marks = HL.dom.marksOf(id);
      if (marks.length) {
        var m = marks[0];
        try { m.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) { /* noop */ }
        HL.dom.flash(id);
        if (state.recs.has(id)) setTimeout(function () { openPopover(id); }, 700);
        if (cleanHash) {
          try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* noop */ }
        }
      } else if (attempt++ < 20) {
        setTimeout(tryScroll, 500);
      }
    };
    tryScroll();
  }

  function checkHash() {
    var h = location.hash || '';
    var prefix = '#' + HL.GOTO_HASH_PREFIX;
    if (h.indexOf(prefix) === 0) {
      var id = h.slice(prefix.length);
      if (id) gotoHighlight(id, true);
    }
  }
  window.addEventListener('hashchange', checkHash);

  /* ---------- پیام‌های runtime ---------- */

  try {
    chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
      if (!msg || !msg.type) return false;
      if (msg.type === HL.MSG.HIGHLIGHT_SELECTION) {
        var ctx = state.disabled ? null : selectionCtx();
        if (ctx) createHighlight(ctx, (state.settings && state.settings.defaultColor) || 'yellow', false);
        sendResponse({ ok: !!ctx });
      } else if (msg.type === HL.MSG.GET_COUNT) {
        sendResponse({ count: state.recs.size });
      } else if (msg.type === HL.MSG.GOTO) {
        if (msg.id) gotoHighlight(msg.id, false);
        sendResponse({ ok: true });
      }
      return false;
    });
  } catch (e) { /* chrome APIs ممکن است در بعضی زمینه‌ها نباشند */ }

  /* ---------- همگام‌سازی زنده با storage ---------- */

  HL.store.onSettingsChanged(function (s) {
    var wasDisabled = state.disabled;
    state.settings = s;
    var nowDisabled = !!((s.disabledHosts || []).indexOf(page.host) !== -1);
    if (nowDisabled && !wasDisabled) {
      // غیرفعال‌سازی: هایلایت‌ها را از دید پنهان کن (داده حذف نمی‌شود)
      state.disabled = true;
      toolbar.dismiss();
      popover.dismiss();
      state.recs.forEach(function (rec) { HL.dom.unwrap(rec.id); });
      state.orphaned.clear();
      reportCount();
    } else if (!nowDisabled && wasDisabled) {
      state.disabled = false;
      applyAllRecords();
      reportCount();
    }
  });

  HL.store.onRecordsChanged(function () { syncFromStorage(); });

  var syncing = false;
  async function syncFromStorage() {
    if (!state.started || state.disabled || syncing) return;
    syncing = true;
    try {
      var fresh = await HL.store.getForUrl(page.norm, page.host);
      // حذف‌شده‌ها (مثلاً از داشبورد)
      state.recs.forEach(function (rec, id) {
        if (!fresh.has(id)) {
          HL.dom.unwrap(id);
          state.recs.delete(id);
          state.orphaned.delete(id);
        }
      });
      // اضافه/به‌روزشده‌ها
      var arr = Array.from(fresh.values()).sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
      for (var i = 0; i < arr.length; i++) {
        var rec = arr[i];
        var old = state.recs.get(rec.id);
        if (!old) {
          state.recs.set(rec.id, rec);
          if (!applyRecord(rec)) state.orphaned.add(rec);
        } else {
          state.recs.set(rec.id, rec);
          if (old.color !== rec.color) HL.dom.setColor(rec.id, rec.color);
          if (hasNote(old) !== hasNote(rec)) HL.dom.setNoted(rec.id, hasNote(rec)); // مثلاً ایمپورت بک‌آپ از تب دیگر
          if ((old.note || '') !== (rec.note || '') && popoverOpen && popover.currentId() === rec.id) {
            popover.updateNote(rec.note);
          }
        }
      }
      reportCount();
    } finally {
      syncing = false;
    }
  }

  /* ---------- MutationObserver برای صفحات داینامیک ---------- */

  function observeDom() {
    if (typeof MutationObserver === 'undefined') return;
    var mo = new MutationObserver(HL.util.debounce(function () {
      if (state.orphaned.size && !state.disabled) {
        state.retries = Math.min(state.retries, 5); // با هر تغییر DOM چند تلاش دوباره
        scheduleOrphanRetry();
      }
    }, 800));
    try {
      mo.observe(document.documentElement, { childList: true, subtree: true });
    } catch (e) { /* noop */ }
  }

  /* ---------- بوت ---------- */

  async function boot() {
    if (!document.body) {
      setTimeout(boot, 300);
      return;
    }
    state.settings = await HL.store.getSettings();
    state.disabled = !!((state.settings.disabledHosts || []).indexOf(page.host) !== -1);
    state.started = true;

    if (!state.disabled) {
      state.recs = await HL.store.getForUrl(page.norm, page.host);
      applyAllRecords();
      observeDom();
      checkHash();
    }
    reportCount();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
