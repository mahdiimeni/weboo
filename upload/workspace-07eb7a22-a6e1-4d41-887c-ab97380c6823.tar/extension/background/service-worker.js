/**
 * وب هایلایتر — Service Worker (MV3, module)
 *
 * مسئولیت‌ها:
 *  - منوی راست‌کلیک «هایلایت انتخاب»
 *  - میان‌بر Alt+Shift+H (commands)
 *  - badge شمارنده روی آیکون (بر اساس تنظیم showBadge)
 *
 * نکته: shared/*.js فایل‌هایی بدون export هستند که globalThis.HL را پر می‌کنند؛
 * side-effect import آن‌ها در ماژول SW مجاز و لازم است.
 * هیچ state سنگینی نگه داشته نمی‌شود (SW ممکن است بین رویدادها خواب برود) —
 * تنها یک cache سبک برای تنظیمات داریم که با رویدادهای storage تازه می‌شود.
 */
import '../shared/constants.js';
import '../shared/utils.js';
import '../shared/store.js';

(function () {
  'use strict';
  const HL = globalThis.HL;
  if (!HL || !HL.MSG || !HL.store) return;

  const MENU_ID = 'hlx-highlight-selection';
  const BADGE_COLOR = '#b45309';

  /* ---------- cache سبک تنظیمات ---------- */

  let settingsCache = null;
  let settingsLoading = null;

  function getSettingsCached() {
    if (settingsCache) return Promise.resolve(settingsCache);
    if (settingsLoading) return settingsLoading;
    settingsLoading = HL.store.getSettings().then(function (s) {
      settingsCache = s;
      settingsLoading = null;
      return s;
    }).catch(function () {
      settingsLoading = null;
      return Object.assign({}, HL.DEFAULT_SETTINGS);
    });
    return settingsLoading;
  }
  function invalidateSettingsCache() { settingsCache = null; }

  /* تازه‌سازی cache با تغییر storage (SW با هر بیدارشدن دوباره ثبت می‌شود) */
  try {
    HL.store.onSettingsChanged(function () { invalidateSettingsCache(); });
    HL.store.onRecordsChanged(function () { invalidateSettingsCache(); });
  } catch (e) { /* noop */ }

  /* ---------- پوشش‌های دفاعی chrome.* ---------- */

  function settle(promiseLike) {
    /* خاموش‌کردن promise های chrome که ممکن است reject شوند */
    if (promiseLike && typeof promiseLike.catch === 'function') {
      promiseLike.catch(function () { /* صفحه بدون content script یا SW خواب */ });
    }
  }

  function sendToTab(tabId, msg) {
    return new Promise(function (resolve) {
      let settledFlag = false;
      function done(v) {
        if (settledFlag) return;
        settledFlag = true;
        resolve(v);
      }
      try {
        const p = chrome.tabs.sendMessage(tabId, msg, function (resp) {
          void chrome.runtime.lastError; /* جلوگیری از unchecked runtime.lastError */
          done(resp);
        });
        settle(p && p.then ? p.then(done, function () { done(undefined); }) : null);
      } catch (e) {
        done(undefined);
      }
    });
  }

  function setBadge(tabId, text) {
    try {
      if (!chrome.action || !chrome.action.setBadgeText) return;
      const r1 = chrome.action.setBadgeText({ text: text, tabId: tabId });
      settle(r1);
      const r2 = chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR, tabId: tabId });
      settle(r2);
    } catch (e) { /* noop */ }
  }

  function updateBadge(tabId, count) {
    getSettingsCached().then(function (s) {
      const show = !!(s && s.showBadge);
      setBadge(tabId, (show && Number(count) > 0) ? String(count) : '');
    }).catch(function () { /* noop */ });
  }

  /* پرسیدن تعداد از content script صفحه؛ یک تلاش دوباره اگر هنوز آماده نبود */
  function requestCount(tabId, isRetry) {
    if (tabId == null) return;
    sendToTab(tabId, { type: HL.MSG.GET_COUNT }).then(function (resp) {
      if (resp && typeof resp.count === 'number') {
        updateBadge(tabId, resp.count);
      } else if (!isRetry) {
        setTimeout(function () { requestCount(tabId, true); }, 1200);
      }
    }).catch(function () { /* صفحه بدون content script */ });
  }

  /* ---------- منوی راست‌کلیک ---------- */

  function ensureContextMenus() {
    try {
      const cb = function () { void chrome.runtime.lastError; /* id تکراری → بی‌صدا */ };
      const p = chrome.contextMenus.create({
        id: MENU_ID,
        title: '✨ هایلایت «%s»',
        contexts: ['selection']
      }, cb);
      settle(p);
    } catch (e) { /* noop */ }
  }

  try {
    chrome.runtime.onInstalled.addListener(function () {
      ensureContextMenus();
    });
  } catch (e) { /* noop */ }

  try {
    chrome.runtime.onStartup.addListener(function () {
      ensureContextMenus();
    });
  } catch (e) { /* noop */ }

  try {
    chrome.contextMenus.onClicked.addListener(function (info, tab) {
      if (!info || info.menuItemId !== MENU_ID) return;
      if (!tab || tab.id == null) return;
      /* content script فقط در فریم اصلی است؛ selection فریم اصلی به آن می‌رسد */
      sendToTab(tab.id, { type: HL.MSG.HIGHLIGHT_SELECTION });
    });
  } catch (e) { /* noop */ }

  /* ---------- میان‌بر کیبورد (commands) ---------- */

  try {
    chrome.commands.onCommand.addListener(function (command) {
      if (command !== 'highlight-selection') return;
      try {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
          void chrome.runtime.lastError;
          const t = tabs && tabs[0];
          if (t && t.id != null) {
            sendToTab(t.id, { type: HL.MSG.HIGHLIGHT_SELECTION });
          }
        });
      } catch (e) { /* noop */ }
    });
  } catch (e) { /* noop */ }

  /* ---------- پیام‌های runtime (COUNT_REPORT از content) ---------- */

  try {
    chrome.runtime.onMessage.addListener(function (msg, sender) {
      try {
        if (!msg || msg.type !== HL.MSG.COUNT_REPORT) return false;
        if (!sender || !sender.tab || sender.tab.id == null) return false;
        updateBadge(sender.tab.id, Number(msg.count) || 0);
      } catch (e) { /* noop */ }
      return false; /* هرگز پاسخ نمی‌دهیم (کانال پیام بسته می‌شود) */
    });
  } catch (e) { /* noop */ }

  /* ---------- رویدادهای تب ---------- */

  try {
    chrome.tabs.onUpdated.addListener(function (tabId, changeInfo) {
      if (changeInfo && changeInfo.status === 'complete') requestCount(tabId, false);
    });
  } catch (e) { /* noop */ }

  try {
    chrome.tabs.onActivated.addListener(function (activeInfo) {
      if (activeInfo && activeInfo.tabId != null) requestCount(activeInfo.tabId, false);
    });
  } catch (e) { /* noop */ }
})();
