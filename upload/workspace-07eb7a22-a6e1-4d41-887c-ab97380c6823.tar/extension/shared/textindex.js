/**
 * وب هایلایتر — موتور انکُرینگ متنی
 * متن صفحه را به یک ایندکس کاراکتری تبدیل می‌کند تا بتوان:
 *   ۱) آفست یک Range را محاسبه کرد (هنگام ذخیره)
 *   ۲) از روی متن ذخیره‌شده، Range معادل را بازیابی کرد (هنگام reload صفحه)
 * این موتور مستقل از ساختار DOM است؛ حتی اگر صفحه بازنویسی شود،
 * تا وقتی متن موجود باشد هایلایت برمی‌گردد.
 */
(function () {
  'use strict';
  const HL = (globalThis.HL = globalThis.HL || {});

  /** تگ‌هایی که متنشان جزو «متن سند» حساب نمی‌شود */
  var SKIP_TAGS = {
    SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, TEXTAREA: 1, TITLE: 1,
    IFRAME: 1, CANVAS: 1, SVG: 1, OBJECT: 1, EMBED: 1, SELECT: 1, OPTION: 1,
    VIDEO: 1, AUDIO: 1
  };

  /**
   * فیلتر TreeWalker برای گره‌های متنی قابل هایلایت.
   * گره‌های داخل رابط کاربری خود افزونه (data-hlx-ui) و نواحی contenteditable رد می‌شوند.
   * مقادیر: 1=ACCEPT، 2=REJECT (NodeFilter برای سازگاری عددی hard-code شده)
   */
  function acceptTextNode(node) {
    var p = node.parentElement;
    while (p) {
      if (SKIP_TAGS[p.tagName]) return 2;
      if (p.hasAttribute && p.hasAttribute('data-hlx-ui')) return 2;
      if (p.isContentEditable) return 2;
      p = p.parentElement;
    }
    if (!node.data || node.data.length === 0) return 2;
    return 1;
  }

  /**
   * ساخت ایندکس متن سند: متن پیوسته + نقشه‌ی chunk ها (گره متنی + شروعش)
   */
  function buildTextIndex(root) {
    var chunks = [];
    var text = '';
    if (!root) return { root: root, text: '', chunks: [], length: 0, locate: function () { return null; }, offsetsOfRange: function () { return null; }, offsetOf: function () { return -1; } };

    var walker = document.createTreeWalker(root, 4 /* SHOW_TEXT */, { acceptNode: acceptTextNode });
    var n;
    while ((n = walker.nextNode())) {
      chunks.push({ node: n, start: text.length });
      text += n.data;
    }

    function locate(index) {
      if (!chunks.length || index < 0 || index >= text.length) return null;
      var lo = 0, hi = chunks.length - 1;
      while (lo < hi) {
        var mid = (lo + hi + 1) >> 1;
        if (chunks[mid].start <= index) lo = mid; else hi = mid - 1;
      }
      var c = chunks[lo];
      return { node: c.node, offset: index - c.start };
    }

    function offsetOf(node, offset) {
      for (var i = 0; i < chunks.length; i++) {
        if (chunks[i].node === node) return chunks[i].start + offset;
      }
      return -1;
    }

    function offsetsOfRange(range) {
      var s = offsetOf(range.startContainer, range.startOffset);
      var e = offsetOf(range.endContainer, range.endOffset);
      if (s < 0 || e < 0 || e < s) return null;
      return { start: s, end: e };
    }

    return {
      root: root, text: text, chunks: chunks, length: text.length,
      locate: locate, offsetOf: offsetOf, offsetsOfRange: offsetsOfRange
    };
  }

  /** فشرده‌سازی فاصله‌ها برای مقایسه‌ی متحمل به تغییر whitespace */
  function squash(s) {
    return String(s == null ? '' : s).replace(/[\s\u00a0\u200b]+/g, ' ').trim();
  }

  /**
   * ساخت متن نرمال‌شده + نگاشت هر کاراکتر نرمال به اندیس اصلی
   * (فاصله‌های پشت‌سرهم یکی می‌شوند، ابتدا/انتهای متن trim می‌شود)
   */
  function normInfo(s) {
    var norm = '';
    var map = [];
    var prevWs = true; // فاصله‌ی ابتدایی حذف می‌شود
    for (var i = 0; i < s.length; i++) {
      var code = s.charCodeAt(i);
      var ws = (code === 32 || code === 9 || code === 10 || code === 13 || code === 12 || code === 160 || code === 8203);
      if (ws) {
        if (!prevWs) { norm += ' '; map.push(i); prevWs = true; }
      } else {
        norm += s.charAt(i);
        map.push(i);
        prevWs = false;
      }
    }
    while (norm.length && norm.charAt(norm.length - 1) === ' ') {
      norm = norm.slice(0, -1);
      map.pop();
    }
    return { norm: norm, map: map };
  }

  function endsWithNorm(a, b) { return squash(a).endsWith(squash(b)); }
  function startsWithNorm(a, b) { return squash(a).startsWith(squash(b)); }

  /**
   * پیدا کردن Range معادل برای یک رکورد هایلایت روی این ایندکس.
   * استراتژی: ۱) آفست ذخیره‌شده ۲) جست‌وجوی دقیق ۳) جست‌وجوی نرمال‌شده
   * + امتیازدهی با prefix/suffix و نزدیکی به آفست قبلی برای رفع ابهام.
   * خروجی: { range, start, end, method, score } یا null
   */
  function findRange(ti, rec) {
    if (!ti || !ti.text) return null;
    var quote = String(rec && rec.text || '');
    if (!quote.trim()) return null;

    var best = null, bestScore = -Infinity;

    function consider(start, end, method, bonus) {
      var sc = bonus || 0;
      if (rec.prefix) sc += endsWithNorm(ti.text.slice(Math.max(0, start - 64), start), rec.prefix) ? 2 : 0;
      if (rec.suffix) sc += startsWithNorm(ti.text.slice(end, end + 64), rec.suffix) ? 2 : 0;
      if (typeof rec.start === 'number') sc -= Math.min(Math.abs(start - rec.start) / 500, 1.5);
      if (sc > bestScore) { bestScore = sc; best = { start: start, end: end, method: method }; }
    }

    // ۱) مسیر سریع: آفست ذخیره‌شده هنوز دقیق است
    if (typeof rec.start === 'number' && rec.start >= 0 && rec.start + quote.length <= ti.text.length && ti.text.substr(rec.start, quote.length) === quote) {
      consider(rec.start, rec.start + quote.length, 'offsets', 1);
    }

    // ۲) جست‌وجوی دقیق متن
    var idx = ti.text.indexOf(quote);
    var guard = 0;
    while (idx !== -1 && guard++ < 200) {
      consider(idx, idx + quote.length, 'exact', 0);
      idx = ti.text.indexOf(quote, idx + 1);
    }

    // ۳) جست‌وجوی نرمال‌شده (تغییر فاصله‌ها/whitespace در نسخه‌ی جدید صفحه)
    if (!best || bestScore < 4) {
      var N = normInfo(ti.text);
      var q = normInfo(quote);
      if (q.norm) {
        var nPre = squash(rec.prefix), nSuf = squash(rec.suffix);
        var j = N.norm.indexOf(q.norm);
        var g = 0;
        while (j !== -1 && g++ < 200) {
          if (j === 0 || N.norm.charAt(j - 1) === ' ') { // مرز کلمه — تطبیق کامل token
            var os = N.map[j];
            var oe = N.map[j + q.norm.length - 1] + 1;
            var sc = 0;
            if (nPre) sc += endsWithNorm(ti.text.slice(Math.max(0, os - 64), os), nPre) ? 2 : 0;
            if (nSuf) sc += startsWithNorm(ti.text.slice(oe, oe + 64), nSuf) ? 2 : 0;
            if (typeof rec.start === 'number') sc -= Math.min(Math.abs(os - rec.start) / 500, 1.5);
            if (sc > bestScore) { bestScore = sc; best = { start: os, end: oe, method: 'norm' }; }
          }
          j = N.norm.indexOf(q.norm, j + 1);
        }
      }
    }

    if (!best) return null;

    var a = ti.locate(best.start);
    var b = ti.locate(best.end - 1);
    if (!a || !b) return null;
    try {
      var range = document.createRange();
      range.setStart(a.node, a.offset);
      range.setEnd(b.node, b.offset + 1);
      return { range: range, start: best.start, end: best.end, method: best.method, score: bestScore };
    } catch (e) {
      return null;
    }
  }

  HL.text = {
    build: buildTextIndex,
    findRange: findRange,
    normInfo: normInfo,
    squash: squash,
    acceptTextNode: acceptTextNode
  };
})();
