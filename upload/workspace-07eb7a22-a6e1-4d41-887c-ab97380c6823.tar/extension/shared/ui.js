/**
 * وب هایلایتر — رابط کاربری شناور (Shadow DOM)
 * - FloatingToolbar: نوار ابزار بالای متنِ انتخاب‌شده (۵ رنگ + یادداشت + کپی)
 * - NotePopover: پاپ‌اور یادداشت روی هر هایلایت (مشاهده/ویرایش/حذف/تغییر رنگ)
 * - Toast: پیام کوتاه پایین صفحه
 * همه‌چیز داخل shadow root رندر می‌شود تا استایل صفحات اثر نگذارد.
 * این فایل مستقل از chrome.* است و در دموی وب‌سایت هم استفاده می‌شود.
 *
 *Invariant visibility: هر دو کامپوننت هنگام ساخت مخفی‌اند (display:none)؛
 * نمایش فقط از طریق present() و مخفی‌شدن فقط از طریق dismiss() —
 * عنصری بدون متن انتخاب‌شده هرگز نباید رندر شود (جلوگیری از «شبح» گوشه‌ی صفحه).
 */
(function () {
  'use strict';
  const HL = (globalThis.HL = globalThis.HL || {});

  var FONT = "Vazirmatn, 'Segoe UI', Tahoma, sans-serif";

  function makeHost() {
    var host = document.createElement('div');
    host.setAttribute('data-hlx-ui', '1');
    var st = host.style;
    st.position = 'fixed';
    st.top = '0';
    st.left = '0';
    st.width = '0';
    st.height = '0';
    st.zIndex = '2147483646';
    st.pointerEvents = 'none';
    document.documentElement.appendChild(host);
    var root = host.attachShadow({ mode: 'open' });
    var style = document.createElement('style');
    style.textContent = BASE_CSS;
    root.appendChild(style);
    return { host: host, root: root };
  }

  var BASE_CSS = [
    ':host, * { box-sizing: border-box; }',
    'button { font: inherit; cursor: pointer; border: 0; background: none; color: inherit; padding: 0; }',
    '.fa { direction: rtl; font-family: ' + FONT + '; }'
  ].join('\n');

  /* ---------- آیکون‌های SVG (استایل lucide) ---------- */
  function svg(path, size) {
    return '<svg width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + '</svg>';
  }
  var ICON = {
    pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    close: '<path d="M18 6 6 18M6 6l12 12"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    external: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6"/><path d="M10 14 21 3"/>'
  };

  /* ---------- Toast ---------- */
  var Toast = {
    _host: null,
    _el: null,
    _t: null,
    show: function (msg) {
      if (!this._host) {
        var h = makeHost();
        this._host = h.host;
        this._root = h.root;
        var el = document.createElement('div');
        el.className = 'fa hlx-toast';
        el.style.cssText = 'position:fixed;bottom:28px;left:50%;transform:translateX(-50%) translateY(8px);background:#111827;color:#f9fafb;padding:9px 18px;border-radius:999px;font-size:13px;font-family:' + FONT + ';direction:rtl;box-shadow:0 10px 30px rgba(0,0,0,.3);opacity:0;transition:all .22s ease;pointer-events:none;z-index:2147483647;white-space:nowrap;';
        this._root.appendChild(el);
        this._el = el;
      }
      var self = this;
      this._el.textContent = String(msg || '');
      this._el.style.opacity = '1';
      this._el.style.transform = 'translateX(-50%) translateY(0)';
      clearTimeout(this._t);
      this._t = setTimeout(function () {
        self._el.style.opacity = '0';
        self._el.style.transform = 'translateX(-50%) translateY(8px)';
      }, 1900);
    }
  };

  /* ---------- FloatingToolbar ---------- */
  var TOOLBAR_CSS = [
    '.hlx-tb { position: fixed; direction: rtl; display: flex; align-items: center; gap: 2px;',
    '  background: rgba(17,24,39,.97); color: #f9fafb; border: 1px solid rgba(255,255,255,.09);',
    '  border-radius: 999px; padding: 6px 8px; box-shadow: 0 10px 34px rgba(0,0,0,.38);',
    '  font-family: ' + FONT + '; pointer-events: auto; animation: hlx-pop .14s ease-out; }',
    '@keyframes hlx-pop { from { opacity: 0; transform: translateY(5px) scale(.95); } to { opacity: 1; } }',
    '.hlx-tb .c { width: 25px; height: 25px; border-radius: 999px; border: 2px solid rgba(255,255,255,.25);',
    '  transition: transform .12s ease, border-color .12s ease; flex: 0 0 auto; }',
    '.hlx-tb .c:hover { transform: scale(1.2); border-color: #fff; }',
    '.hlx-tb .sep { width: 1px; height: 20px; background: rgba(255,255,255,.16); margin: 0 5px; flex: 0 0 auto; }',
    '.hlx-tb .b { width: 30px; height: 30px; border-radius: 9px; color: #e5e7eb; display: flex; align-items: center; justify-content: center; flex: 0 0 auto; }',
    '.hlx-tb .b:hover { background: rgba(255,255,255,.12); color: #fff; }',
    '.hlx-tb .b.note { color: #fbbf24; }',
    '.hlx-tb .b.note:hover { background: rgba(251,191,36,.15); }'
  ].join('\n');

  function FloatingToolbar(opts) {
    var self = this;
    this.onColor = opts.onColor || function () {};
    this.onNote = opts.onNote || function () {};
    this.onCopy = opts.onCopy || function () {};
    this.ctx = null;
    this.visible = false;

    var h = makeHost();
    this.host = h.host;
    this.root = h.root;

    var st = document.createElement('style');
    st.textContent = TOOLBAR_CSS;
    this.root.appendChild(st);

    var el = document.createElement('div');
    el.className = 'fa hlx-tb';
    el.setAttribute('role', 'toolbar');
    el.setAttribute('aria-label', 'ابزار هایلایت');
    var html = '';
    (HL.COLOR_KEYS || []).forEach(function (k) {
      var c = HL.COLORS[k];
      html += '<button class="c" data-color="' + k + '" title="هایلایت ' + c.label + '" aria-label="هایلایت ' + c.label + '" style="background:' + c.dot + '"></button>';
    });
    html += '<span class="sep"></span>';
    html += '<button class="b note" data-act="note" title="هایلایت + یادداشت" aria-label="هایلایت با یادداشت">' + svg(ICON.pen, 17) + '</button>';
    html += '<button class="b" data-act="copy" title="کپی متن" aria-label="کپی متن انتخاب‌شده">' + svg(ICON.copy, 15) + '</button>';
    el.innerHTML = html;
    this.root.appendChild(el);
    this.el = el;
    el.style.display = 'none'; // invariant: شروع مخفی — فقط present() نمایش می‌دهد

    // mousedown با preventDefault تا انتخاب متن از بین نرود
    el.addEventListener('mousedown', function (e) { e.preventDefault(); }, true);
    el.addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('button') : null;
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation();
      if (btn.getAttribute('data-color')) self.onColor(btn.getAttribute('data-color'), self.ctx);
      else if (btn.getAttribute('data-act') === 'note') self.onNote(self.ctx);
      else if (btn.getAttribute('data-act') === 'copy') self.onCopy(self.ctx);
    });

    var reposition = function () { if (self.visible) self.position(); };
    window.addEventListener('scroll', reposition, { passive: true, capture: true });
    window.addEventListener('resize', reposition);
  }

  FloatingToolbar.prototype.present = function (ctx) {
    this.ctx = ctx;
    this.visible = true;
    this.el.style.display = 'flex';
    this.position();
  };

  FloatingToolbar.prototype.position = function () {
    if (!this.visible || !this.ctx) return;
    var r = null;
    try { r = this.ctx.range.getBoundingClientRect(); } catch (e) { r = null; }
    if (!r || (r.width === 0 && r.height === 0)) { this.dismiss(); return; }
    var w = this.el.offsetWidth, h = this.el.offsetHeight;
    var top = r.top - h - 10;
    if (top < 8) top = Math.min(r.bottom + 10, window.innerHeight - h - 8);
    var left = r.left + r.width / 2 - w / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));
    this.el.style.top = top + 'px';
    this.el.style.left = left + 'px';
  };

  FloatingToolbar.prototype.dismiss = function () {
    this.visible = false;
    this.ctx = null;
    this.el.style.display = 'none';
  };

  /* ---------- NotePopover ---------- */
  var POPOVER_CSS = [
    '.hlx-po { position: fixed; direction: rtl; width: 328px; max-width: calc(100vw - 20px);',
    '  background: #ffffff; color: #1f2937; border: 1px solid #e5e7eb; border-radius: 14px;',
    '  box-shadow: 0 14px 44px rgba(0,0,0,.2); font-family: ' + FONT + '; font-size: 13px;',
    '  pointer-events: auto; animation: hlx-po-pop .16s ease-out; z-index: 2147483647; }',
    '@keyframes hlx-po-pop { from { opacity: 0; transform: translateY(6px) scale(.97); } to { opacity: 1; } }',
    '.hlx-po .head { display: flex; align-items: center; gap: 6px; padding: 10px 12px 6px; }',
    '.hlx-po .c { width: 21px; height: 21px; border-radius: 999px; border: 2px solid #e5e7eb; flex: 0 0 auto; transition: transform .12s; }',
    '.hlx-po .c:hover { transform: scale(1.15); }',
    '.hlx-po .c.active { border-color: #111827; box-shadow: 0 0 0 2px #fff, 0 0 0 4px #d97706; }',
    '.hlx-po .grow { flex: 1; }',
    '.hlx-po .x { width: 26px; height: 26px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #6b7280; }',
    '.hlx-po .x:hover { background: #f3f4f6; color: #111827; }',
    '.hlx-po .q { margin: 2px 12px 10px; padding: 8px 11px; background: #fffbeb; border-right: 3px solid #f59e0b;',
    '  border-radius: 9px; color: #78350f; line-height: 2; font-size: 12.5px; max-height: 92px; overflow: auto;',
    '  white-space: pre-wrap; word-break: break-word; }',
    '.hlx-po .note-box { margin: 0 12px 10px; padding: 10px 12px; border: 1.5px dashed #d1d5db; border-radius: 11px; color: #9ca3af; display: flex; flex-direction: column; gap: 8px; align-items: flex-start; }',
    '.hlx-po .note-box.has { border: 1.5px solid #bbf7d0; background: #f0fdf4; color: #14532d; }',
    '.hlx-po .note-text { white-space: pre-wrap; word-break: break-word; line-height: 2; color: #111827; width: 100%; max-height: 180px; overflow: auto; }',
    '.hlx-po .note-text:empty::before { content: "—"; opacity: .4; }',
    '.hlx-po .add-note { color: #b45309; font-weight: 600; font-size: 12.5px; display: inline-flex; align-items: center; gap: 6px; }',
    '.hlx-po .add-note:hover { text-decoration: underline; }',
    '.hlx-po textarea { width: 100%; min-height: 86px; resize: vertical; border: 1.5px solid #d1d5db; border-radius: 10px;',
    '  padding: 8px 11px; font: inherit; line-height: 2; background: #fff; color: #111827; direction: rtl; }',
    '.hlx-po textarea:focus { outline: none; border-color: #f59e0b; box-shadow: 0 0 0 3px rgba(245,158,11,.18); }',
    '.hlx-po .row { display: flex; gap: 8px; align-items: center; justify-content: flex-end; }',
    '.hlx-po .btn-p { background: #d97706; color: #fff; border-radius: 9px; padding: 7px 16px; font-weight: 700; font-size: 12.5px; }',
    '.hlx-po .btn-p:hover { background: #b45309; }',
    '.hlx-po .btn-g { background: #f3f4f6; color: #374151; border-radius: 9px; padding: 7px 16px; font-weight: 600; font-size: 12.5px; }',
    '.hlx-po .btn-g:hover { background: #e5e7eb; }',
    '.hlx-po .foot { display: flex; align-items: center; justify-content: space-between; padding: 8px 12px 10px; border-top: 1px solid #f3f4f6; }',
    '.hlx-po .date { color: #9ca3af; font-size: 11.5px; }',
    '.hlx-po .act { display: flex; gap: 2px; }',
    '.hlx-po .ib { width: 30px; height: 30px; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #6b7280; }',
    '.hlx-po .ib:hover { background: #f3f4f6; color: #111827; }',
    '.hlx-po .ib.del:hover { background: #fef2f2; color: #dc2626; }',
    '.hlx-po .ib.del.confirm { background: #dc2626; color: #fff; width: auto; padding: 0 10px; font-weight: 700; font-size: 11.5px; }',
    '.hlx-po .ok { color: #059669; font-size: 12px; font-weight: 700; opacity: 0; transition: opacity .25s; }',
    '.hlx-po .ok.show { opacity: 1; }',
    '@media (prefers-color-scheme: dark) {',
    '  .hlx-po { background: #1f2937; border-color: #374151; color: #f3f4f6; }',
    '  .hlx-po .q { background: rgba(245,158,11,.12); color: #fcd34d; border-right-color: #f59e0b; }',
    '  .hlx-po .note-box { border-color: #4b5563; color: #9ca3af; }',
    '  .hlx-po .note-box.has { border-color: #065f46; background: rgba(6,95,70,.25); color: #a7f3d0; }',
    '  .hlx-po .note-text { color: #f9fafb; }',
    '  .hlx-po textarea { background: #111827; border-color: #4b5563; color: #f9fafb; }',
    '  .hlx-po .btn-g { background: #374151; color: #e5e7eb; }',
    '  .hlx-po .x:hover, .hlx-po .ib:hover { background: #374151; color: #f9fafb; }',
    '  .hlx-po .foot { border-top-color: #374151; }',
    '  .hlx-po .c.active { border-color: #f9fafb; box-shadow: 0 0 0 2px #1f2937, 0 0 0 4px #f59e0b; }',
    '}'
  ].join('\n');

  function NotePopover(handlers) {
    var self = this;
    this.h = {
      onColorChange: handlers.onColorChange || function () {},
      onSaveNote: handlers.onSaveNote || function () {},
      onDelete: handlers.onDelete || function () {},
      onCopy: handlers.onCopy || function () {},
      onClose: handlers.onClose || function () {}
    };
    this.data = null;
    this.mode = 'view'; // view | edit
    this.visible = false;

    var h = makeHost();
    this.host = h.host;
    this.root = h.root;

    var st = document.createElement('style');
    st.textContent = POPOVER_CSS;
    this.root.appendChild(st);

    var el = document.createElement('div');
    el.className = 'fa hlx-po';
    el.setAttribute('role', 'dialog');
    el.setAttribute('dir', 'rtl');
    this.root.appendChild(el);
    this.el = el;
    el.style.display = 'none'; // invariant: شروع مخفی — فقط present() نمایش می‌دهد

    // بستن با کلیک بیرون
    this._outside = function (e) {
      if (!self.visible) return;
      var path = (e.composedPath && e.composedPath()) || [];
      if (path.indexOf(self.host) === -1) self.dismiss();
    };
    window.addEventListener('mousedown', this._outside, true);

    this._key = function (e) {
      if (e.key === 'Escape' && self.visible) {
        if (self.mode === 'edit') { self.render('view'); } else { self.dismiss(); }
      }
    };
    document.addEventListener('keydown', this._key, true);

    this._reposition = function () { if (self.visible) self.position(); };
    window.addEventListener('scroll', this._reposition, { passive: true, capture: true });
    window.addEventListener('resize', this._reposition);
  }

  /**
   * opts: { id, mark?, rect?, color, note, quote, createdAt, editNow }
   */
  NotePopover.prototype.present = function (opts) {
    this.data = opts;
    this.mode = (opts.editNow || (opts.note && opts.editNow)) ? 'edit' : 'view';
    this.visible = true;
    this.render(this.mode);
    this.position();
    if (this.mode === 'edit') this.focusTextarea();
  };

  NotePopover.prototype.currentId = function () {
    return this.data ? this.data.id : null;
  };

  NotePopover.prototype.updateNote = function (note) {
    if (!this.data) return;
    this.data.note = note;
    if (this.visible && this.mode === 'view') this.render('view');
  };

  NotePopover.prototype.render = function (mode) {
    var self = this;
    this.mode = mode || 'view';
    var d = this.data;
    if (!d) return;
    var esc = HL.util.escapeHtml;
    var html = '';

    // سربرگ: رنگ‌ها + بستن
    html += '<div class="head">';
    (HL.COLOR_KEYS || []).forEach(function (k) {
      var c = HL.COLORS[k];
      html += '<button class="c' + (k === d.color ? ' active' : '') + '" data-color="' + k + '" title="' + esc(c.label) + '" aria-label="رنگ ' + esc(c.label) + '" style="background:' + c.dot + '"></button>';
    });
    html += '<span class="grow"></span>';
    html += '<button class="x" data-act="close" title="بستن" aria-label="بستن">' + svg(ICON.close, 15) + '</button>';
    html += '</div>';

    // متن هایلایت‌شده
    html += '<div class="q">' + esc(HL.util.excerpt(d.quote, 260)) + '</div>';

    if (this.mode === 'view') {
      var hasNote = !!(d.note && String(d.note).trim());
      html += '<div class="note-box' + (hasNote ? ' has' : '') + '">';
      if (hasNote) {
        html += '<div class="note-text">' + esc(d.note) + '</div>';
        html += '<button class="add-note" data-act="edit">' + svg(ICON.pen, 13) + ' ویرایش یادداشت</button>';
      } else {
        html += '<span>برای این هایلایت یادداشتی ثبت نشده است.</span>';
        html += '<button class="add-note" data-act="edit">' + svg(ICON.pen, 13) + ' افزودن یادداشت</button>';
      }
      html += '</div>';
    } else {
      html += '<div style="margin:0 12px 10px">';
      html += '<textarea placeholder="یادداشت شما برای این هایلایت…" data-role="note-input">' + esc(d.note || '') + '</textarea>';
      html += '<div class="row" style="margin-top:10px">';
      html += '<span class="ok" data-role="ok">ذخیره شد ✓</span>';
      html += '<button class="btn-g" data-act="cancel">لغو</button>';
      html += '<button class="btn-p" data-act="save">ذخیره یادداشت</button>';
      html += '</div></div>';
    }

    // پاورقی: تاریخ + کپی + حذف
    html += '<div class="foot">';
    html += '<span class="date">' + esc(HL.util.fmtDateTime(d.createdAt)) + '</span>';
    html += '<span class="act">';
    html += '<button class="ib" data-act="copy" title="کپی متن و یادداشت" aria-label="کپی">' + svg(ICON.copy, 15) + '</button>';
    html += '<button class="ib del" data-act="del" title="حذف هایلایت" aria-label="حذف">' + svg(ICON.trash, 15) + '</button>';
    html += '</span></div>';

    this.el.innerHTML = html;

    // رویدادها (delegation)
    this.el.onclick = function (e) {
      var btn = e.target.closest ? e.target.closest('button') : null;
      if (!btn) return;
      var act = btn.getAttribute('data-act');
      var color = btn.getAttribute('data-color');
      e.preventDefault();
      e.stopPropagation();

      if (color) {
        self.data.color = color;
        self.h.onColorChange(self.data.id, color);
        var dots = self.el.querySelectorAll('.c');
        for (var i = 0; i < dots.length; i++) dots[i].classList.remove('active');
        btn.classList.add('active');
        return;
      }
      if (act === 'close') { self.dismiss(); }
      else if (act === 'edit') { self.render('edit'); self.focusTextarea(); }
      else if (act === 'save') {
        var ta = self.el.querySelector('[data-role="note-input"]');
        var val = ta ? ta.value : '';
        self.data.note = val;
        self.h.onSaveNote(self.data.id, val);
        self.render('view');
        self.flashOk();
      }
      else if (act === 'cancel') { self.render('view'); }
      else if (act === 'copy') { self.h.onCopy(self.data.id); }
      else if (act === 'del') {
        if (btn.classList.contains('confirm')) {
          self.h.onDelete(self.data.id);
          self.dismiss();
        } else {
          btn.classList.add('confirm');
          btn.textContent = 'حذف؟';
          setTimeout(function () {
            if (btn.isConnected) { btn.classList.remove('confirm'); btn.innerHTML = svg(ICON.trash, 15); }
          }, 2600);
        }
      }
    };
  };

  NotePopover.prototype.flashOk = function () {
    var ok = this.el.querySelector('[data-role="ok"]');
    if (!ok) return;
    ok.classList.add('show');
    setTimeout(function () { ok.classList.remove('show'); }, 1600);
  };

  NotePopover.prototype.focusTextarea = function () {
    var self = this;
    setTimeout(function () {
      var ta = self.el.querySelector('[data-role="note-input"]');
      if (ta) { ta.focus(); ta.setSelectionRange(ta.value.length, ta.value.length); }
    }, 30);
  };

  NotePopover.prototype.position = function () {
    if (!this.visible || !this.data) return;
    var rect = null;
    if (this.data.mark && this.data.mark.isConnected) {
      try { rect = this.data.mark.getBoundingClientRect(); } catch (e) { rect = null; }
    }
    if (!rect && this.data.mark && !this.data.mark.isConnected) { this.dismiss(); return; }
    if (!rect) rect = this.data.rect;
    if (!rect) { this.dismiss(); return; }

    var w = this.el.offsetWidth, h = this.el.offsetHeight;
    var top = rect.bottom + 10;
    if (top + h > window.innerHeight - 8) top = Math.max(8, rect.top - h - 10);
    var left = rect.left + rect.width / 2 - w / 2;
    left = Math.max(10, Math.min(left, window.innerWidth - w - 10));
    this.el.style.top = top + 'px';
    this.el.style.left = left + 'px';
  };

  NotePopover.prototype.dismiss = function () {
    if (!this.visible) return;
    this.visible = false;
    this.data = null;
    this.el.style.display = 'none';
    this.el.innerHTML = '';
    this.h.onClose();
  };

  // هنگام present مجدد display را برگردان
  var origPresent = NotePopover.prototype.present;
  NotePopover.prototype.present = function (opts) {
    this.el.style.display = 'block';
    origPresent.call(this, opts);
  };

  HL.ui = {
    FloatingToolbar: FloatingToolbar,
    NotePopover: NotePopover,
    Toast: Toast,
    makeHost: makeHost,
    ICON: ICON,
    svg: svg
  };
})();
