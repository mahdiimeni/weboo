/**
 * وب هایلایتر — ابزارهای DOM
 * - نشانه‌گذاری (wrap) بازه‌ی یک Range با المان‌های <mark>
 * - انکُر سریع XPath (serialize/resolve)
 * - باز کردن (unwrap) هایلایت، تغییر رنگ، نشانگر یادداشت، افکت flash
 * المان هایلایت: <mark class="hlx-marker" data-hl-id="..." data-hl-color="..." data-hl-noted="1"?>
 * data-hl-noted فقط برای هایلایت‌های دارای یادداشت تنظیم می‌شود (خط زیرین نشانگر).
 */
(function () {
  'use strict';
  const HL = (globalThis.HL = globalThis.HL || {});

  /** XPath نسبی به body برای یک گره (عنصر یا متن) */
  function xpathOf(node) {
    if (!node) return null;
    var parts = [];
    var cur = node;
    var guard = 0;
    while (cur && cur !== document.body && cur.nodeType !== 9 && guard++ < 300) {
      var parent = cur.parentNode;
      if (!parent) break;
      if (cur.nodeType === 3) { // متن
        var idx = 0, sib = parent.firstChild;
        while (sib && sib !== cur) { if (sib.nodeType === 3) idx++; sib = sib.nextSibling; }
        parts.unshift('text()[' + (idx + 1) + ']');
      } else if (cur.nodeType === 1) { // عنصر
        var eidx = 0, esib = parent.firstChild;
        while (esib && esib !== cur) { if (esib.nodeType === 1 && esib.tagName === cur.tagName) eidx++; esib = esib.nextSibling; }
        parts.unshift(cur.tagName.toLowerCase() + '[' + (eidx + 1) + ']');
      } else break;
      cur = parent;
    }
    return parts.join('/');
  }

  function evalXPath(path) {
    if (!path || !document.body) return null;
    try {
      var r = document.evaluate('./' + path, document.body, null, 9 /* FIRST_ORDERED_NODE_TYPE */, null);
      return r.singleNodeValue || null;
    } catch (e) {
      return null;
    }
  }

  function serializeRange(range) {
    try {
      return {
        start: xpathOf(range.startContainer),
        startOffset: range.startOffset,
        end: xpathOf(range.endContainer),
        endOffset: range.endOffset
      };
    } catch (e) {
      return null;
    }
  }

  function lenOf(node) {
    return node.nodeType === 3 ? node.data.length : node.childNodes.length;
  }

  /**
   * بازیابی سریع Range از روی انکُر XPath.
   * expectText: ۲۴ کاراکتر اول متن دامنه با متن موردانتظار مقایسه می‌شود؛
   * اگر صفحه تغییر کرده باشد null برمی‌گردد تا مسیر متنی (fallback) امتحان شود.
   */
  function resolveAnchor(anchor, expectText) {
    if (!anchor || !anchor.start || !anchor.end) return null;
    var sc = evalXPath(anchor.start);
    var ec = evalXPath(anchor.end);
    if (!sc || !ec) return null;
    try {
      var r = document.createRange();
      r.setStart(sc, Math.min(anchor.startOffset, lenOf(sc)));
      r.setEnd(ec, Math.min(anchor.endOffset, lenOf(ec)));
      if (r.collapsed) return null;
      if (expectText) {
        var a = HL.text.squash(r.toString()).slice(0, 24);
        var b = HL.text.squash(expectText).slice(0, 24);
        if (!a || !b || a !== b) return null;
      }
      return r;
    } catch (e) {
      return null;
    }
  }

  /** گره‌های متنی که با Range برخورد دارند (به‌ترتیب سند) */
  function intersectingTextNodes(range) {
    var out = [];
    if (!range || range.collapsed) return out;
    var root = range.commonAncestorContainer;
    if (root.nodeType === 3) root = root.parentNode;
    if (!root) return out;
    var walker = document.createTreeWalker(root, 4 /* SHOW_TEXT */, { acceptNode: HL.text.acceptTextNode });
    var n;
    while ((n = walker.nextNode())) {
      var hit = true;
      try { hit = range.intersectsNode(n); } catch (e) { hit = false; }
      if (hit) out.push(n);
    }
    return out;
  }

  /**
   * درپوش‌گذاری (wrap) تمام متن داخل Range با المان‌های mark.
   * برای گره‌های ناقص ابتدا متن با splitText جدا می‌شود.
   * خروجی: آرایه‌ی mark های ساخته‌شده (خالی یعنی قابل هایلایت نبود).
   */
  function markRange(range, id, colorKey) {
    var marks = [];
    if (!range || range.collapsed) return marks;
    var nodes = intersectingTextNodes(range);
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var s = (node === range.startContainer) ? range.startOffset : 0;
      var e = (node === range.endContainer) ? range.endOffset : node.data.length;
      if (e <= s) continue;

      var target = node;
      try {
        if (e < node.data.length) target.splitText(e);
        if (s > 0) target = target.splitText(s);
      } catch (err) { continue; }
      if (!target || !target.data || !target.parentNode) continue;

      var mark = document.createElement('mark');
      mark.className = 'hlx-marker';
      mark.setAttribute('data-hl-id', id);
      mark.setAttribute('data-hl-color', colorKey);

      var parent = target.parentNode;
      parent.insertBefore(mark, target);
      mark.appendChild(target);
      marks.push(mark);
    }
    return marks;
  }

  function marksOf(id) {
    try {
      var sel = 'mark.hlx-marker[data-hl-id="' + HL.util.cssEscape(id) + '"]';
      return Array.prototype.slice.call(document.querySelectorAll(sel));
    } catch (e) {
      return [];
    }
  }

  function allMarks() {
    return Array.prototype.slice.call(document.querySelectorAll('mark.hlx-marker'));
  }

  /** باز کردن هایلایت: mark ها حذف و متن‌ها به جای اصلی برمی‌گردند */
  function unwrap(id) {
    var ms = marksOf(id);
    for (var i = 0; i < ms.length; i++) {
      var m = ms[i];
      var p = m.parentNode;
      if (!p) continue;
      while (m.firstChild) p.insertBefore(m.firstChild, m);
      m.remove();
      if (p.normalize) { try { p.normalize(); } catch (e) { /* noop */ } }
    }
    return ms.length;
  }

  function setColor(id, colorKey) {
    marksOf(id).forEach(function (m) { m.setAttribute('data-hl-color', colorKey); });
  }

  /**
   * نشانگر یادداشت: خط زیرینِ هایلایت فقط وقتی نمایش داده می‌شود که یادداشت
   * غیرخالی داشته باشد. با خالی‌شدن/حذف یادداشت، اتریبیوت برداشته می‌شود.
   */
  function setNoted(id, hasNote) {
    marksOf(id).forEach(function (m) {
      if (hasNote) m.setAttribute('data-hl-noted', '1');
      else m.removeAttribute('data-hl-noted');
    });
  }

  /** افکت چشمک برای پرش به هایلایت */
  function flash(id) {
    var ms = marksOf(id);
    ms.forEach(function (m) {
      m.classList.remove('hlx-flash');
      void m.offsetWidth;
      m.classList.add('hlx-flash');
    });
    setTimeout(function () {
      ms.forEach(function (m) { m.classList.remove('hlx-flash'); });
    }, 2000);
  }

  HL.dom = {
    xpathOf: xpathOf,
    evalXPath: evalXPath,
    serializeRange: serializeRange,
    resolveAnchor: resolveAnchor,
    intersectingTextNodes: intersectingTextNodes,
    markRange: markRange,
    marksOf: marksOf,
    allMarks: allMarks,
    unwrap: unwrap,
    setColor: setColor,
    setNoted: setNoted,
    flash: flash
  };
})();
