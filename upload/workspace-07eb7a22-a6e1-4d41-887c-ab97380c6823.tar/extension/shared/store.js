/**
 * وب هایلایتر — لایه‌ی ذخیره‌سازی روی chrome.storage.local
 * پارتیشن‌بندی per-host برای خواندن سریع داده‌های همان سایت:
 *   hlx:settings  → تنظیمات کاربر
 *   hlx:d:<host>  → { <id>: Record }
 * Export/Import: بک‌آپ JSON با فرمت نسخه‌دار.
 * نکته: writeها read-modify-write هستند؛ برای v1 و استفاده‌ی تک‌کاربره کافی است.
 */
(function () {
  'use strict';
  var HL = (globalThis.HL = globalThis.HL || {});
  var AREA = (globalThis.chrome && globalThis.chrome.storage && globalThis.chrome.storage.local)
    ? globalThis.chrome.storage.local : null;

  var K_SETTINGS = 'hlx:settings';
  function dataKey(host) { return 'hlx:d:' + host; }

  function get(key, def) {
    return new Promise(function (res) {
      if (!AREA) return res(def);
      AREA.get(key, function (o) {
        res(o && key in o ? o[key] : def);
      });
    });
  }

  function set(obj) {
    return new Promise(function (res, rej) {
      if (!AREA) return rej(new Error('chrome.storage.local در دسترس نیست'));
      AREA.set(obj, function () {
        if (globalThis.chrome && chrome.runtime && chrome.runtime.lastError) {
          rej(new Error(chrome.runtime.lastError.message));
        } else res();
      });
    });
  }

  function getAll() {
    return new Promise(function (res) {
      if (!AREA) return res({});
      AREA.get(null, function (o) { res(o || {}); });
    });
  }

  /* ---------- تنظیمات ---------- */

  async function getSettings() {
    var s = await get(K_SETTINGS, {});
    return Object.assign({}, HL.DEFAULT_SETTINGS, s || {});
  }

  async function setSettings(patch) {
    var cur = await getSettings();
    var next = Object.assign({}, cur, patch || {});
    await set(makeObj(K_SETTINGS, next));
    return next;
  }

  /* ---------- رکوردها ---------- */

  async function getHostMap(host) {
    var m = await get(dataKey(host), {});
    return m || {};
  }

  async function getForUrl(urlNorm, host) {
    var m = await getHostMap(host);
    var out = new Map();
    Object.keys(m).forEach(function (id) {
      var r = m[id];
      if (r && r.urlNorm === urlNorm) out.set(id, r);
    });
    return out;
  }

  async function getAllRecords() {
    var all = await getAll();
    var out = new Map();
    Object.keys(all).forEach(function (k) {
      if (k.indexOf('hlx:d:') !== 0) return;
      var m = all[k] || {};
      Object.keys(m).forEach(function (id) {
        var r = m[id];
        if (r && r.id) out.set(id, r);
      });
    });
    return out;
  }

  async function hostsWithData() {
    var all = await getAll();
    return Object.keys(all).filter(function (k) { return k.indexOf('hlx:d:') === 0; }).map(function (k) { return k.slice(6); });
  }

  async function save(rec) { return saveMany([rec]); }

  async function saveMany(recs) {
    if (!recs || !recs.length) return;
    var byHost = {};
    recs.forEach(function (r) {
      if (!r || !r.id || !r.host) return;
      byHost[r.host] = byHost[r.host] || {};
      byHost[r.host][r.id] = r;
    });
    var obj = {};
    var hosts = Object.keys(byHost);
    for (var i = 0; i < hosts.length; i++) {
      var h = hosts[i];
      var m = await getHostMap(h);
      Object.assign(m, byHost[h]);
      obj[dataKey(h)] = m;
    }
    await set(obj);
  }

  async function remove(id, hostHint) {
    var hosts = hostHint ? [hostHint] : await hostsWithData();
    var obj = {};
    var found = false;
    for (var i = 0; i < hosts.length; i++) {
      var m = await getHostMap(hosts[i]);
      if (m[id]) { delete m[id]; obj[dataKey(hosts[i])] = m; found = true; }
    }
    if (found) await set(obj);
    return found;
  }

  async function removeMany(ids, hostHint) {
    var idSet = {};
    (ids || []).forEach(function (i) { idSet[i] = 1; });
    var hosts = hostHint ? [hostHint] : await hostsWithData();
    var obj = {};
    var any = false;
    for (var i = 0; i < hosts.length; i++) {
      var m = await getHostMap(hosts[i]);
      var changed = false;
      Object.keys(m).forEach(function (id) { if (idSet[id]) { delete m[id]; changed = true; } });
      if (changed) { obj[dataKey(hosts[i])] = m; any = true; }
    }
    if (any) await set(obj);
  }

  async function removeForUrl(urlNorm, host) {
    var m = await getHostMap(host);
    var out = {};
    var changed = false;
    Object.keys(m).forEach(function (id) {
      var r = m[id];
      if (r && r.urlNorm === urlNorm) { changed = true; return; }
      out[id] = r;
    });
    if (changed) await set(makeObj(dataKey(host), out));
    return changed;
  }

  function makeObj(k, v) { var o = {}; o[k] = v; return o; }

  async function clearAll() {
    var all = await getAll();
    var keys = Object.keys(all).filter(function (k) { return k.indexOf('hlx:') === 0; });
    return new Promise(function (res) {
      if (!keys.length || !AREA) return res();
      AREA.remove(keys, function () { res(); });
    });
  }

  /* ---------- بک‌آپ ---------- */

  async function exportData() {
    var settings = await getSettings();
    var highlights = {};
    var records = await getAllRecords();
    records.forEach(function (r, id) { highlights[id] = r; });
    return {
      app: HL.APP_ID,
      name: HL.APP_NAME,
      format: HL.BACKUP_FORMAT,
      version: HL.VERSION,
      exportedAt: Date.now(),
      settings: settings,
      highlights: highlights,
      meta: { count: Object.keys(highlights).length }
    };
  }

  var RECORD_FIELDS = ['id', 'host', 'site', 'url', 'urlNorm', 'title', 'text', 'prefix', 'suffix', 'start', 'end', 'anchor', 'color', 'note', 'createdAt', 'updatedAt'];

  function sanitizeRecord(r, id) {
    var out = {};
    RECORD_FIELDS.forEach(function (f) { if (r[f] !== undefined) out[f] = r[f]; });
    out.id = r.id || id;
    out.host = String(r.host || '');
    out.site = String(r.site || '');
    out.url = String(r.url || '');
    out.urlNorm = String(r.urlNorm || r.url || '');
    out.title = String(r.title || '');
    out.text = String(r.text || '');
    out.prefix = String(r.prefix || '');
    out.suffix = String(r.suffix || '');
    out.color = (HL.COLORS && HL.COLORS[r.color]) ? r.color : 'yellow';
    out.note = String(r.note || '');
    out.createdAt = Number(r.createdAt) || Date.now();
    out.updatedAt = Number(r.updatedAt) || out.createdAt;
    return out;
  }

  /**
   * واردکردن بک‌آپ.
   * mode='merge': رکوردهای جدید اضافه، تکراری‌ها بر اساس updatedAt (جدیدتر برنده)
   * mode='replace': همه‌چیز پاک و جایگزین می‌شود (تنظیمات هم بازنویسی می‌شوند)
   */
  async function importData(backup, mode) {
    var report = { added: 0, updated: 0, skipped: 0, removed: 0 };
    if (!backup || backup.app !== HL.APP_ID || !backup.highlights || typeof backup.highlights !== 'object') {
      throw new Error('فایل پشتیبان معتبر «وب هایلایتر» نیست.');
    }
    var current = await getAllRecords();
    if (mode === 'replace') {
      await clearAll();
      report.removed = current.size;
      if (backup.settings) {
        await set(makeObj(K_SETTINGS, Object.assign({}, HL.DEFAULT_SETTINGS, backup.settings)));
      }
    }
    var incoming = [];
    Object.keys(backup.highlights).forEach(function (id) {
      var r = backup.highlights[id];
      if (!r || !r.text || !r.urlNorm || !r.host) { report.skipped++; return; }
      var clean = sanitizeRecord(r, id);
      if (mode === 'merge' && current.has(id)) {
        var old = current.get(id);
        if ((clean.updatedAt || 0) > (old.updatedAt || 0)) { incoming.push(clean); report.updated++; }
        else report.skipped++;
      } else {
        incoming.push(clean);
        report.added++;
      }
    });
    await saveMany(incoming);
    return report;
  }

  /* ---------- شنود تغییرات ---------- */

  function onSettingsChanged(cb) {
    if (!globalThis.chrome || !chrome.storage || !chrome.storage.onChanged) return;
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === 'local' && changes[K_SETTINGS]) {
        cb(Object.assign({}, HL.DEFAULT_SETTINGS, changes[K_SETTINGS].newValue || {}));
      }
    });
  }

  function onRecordsChanged(cb) {
    if (!globalThis.chrome || !chrome.storage || !chrome.storage.onChanged) return;
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== 'local') return;
      var keys = Object.keys(changes).filter(function (k) { return k.indexOf('hlx:d:') === 0; });
      if (keys.length) cb();
    });
  }

  function getBytesInUse() {
    return new Promise(function (res) {
      if (!AREA || !AREA.getBytesInUse) return res(0);
      try { AREA.getBytesInUse(null, function (b) { res(b || 0); }); } catch (e) { res(0); }
    });
  }

  HL.store = {
    getSettings: getSettings,
    setSettings: setSettings,
    getHostMap: getHostMap,
    getForUrl: getForUrl,
    getAllRecords: getAllRecords,
    hostsWithData: hostsWithData,
    save: save,
    saveMany: saveMany,
    remove: remove,
    removeMany: removeMany,
    removeForUrl: removeForUrl,
    clearAll: clearAll,
    exportData: exportData,
    importData: importData,
    onSettingsChanged: onSettingsChanged,
    onRecordsChanged: onRecordsChanged,
    getBytesInUse: getBytesInUse
  };
})();
