/**
 * وب هایلایتر — ثابت‌ها و قراردادهای مشترک
 * این فایل باید هم به‌عنوان classic script (در content script و صفحات افزونه)
 * و هم به‌عنوان side-effect import در service worker (module) کار کند؛
 * بنابراین هیچ import/exportی ندارد و همه‌چیز را روی globalThis.HL می‌گذارد.
 */
(function () {
  'use strict';
  const HL = (globalThis.HL = globalThis.HL || {});

  HL.APP_NAME = 'وب هایلایتر';
  HL.APP_ID = 'web-highlighter';
  HL.VERSION = '1.0.2';
  HL.BACKUP_FORMAT = 1;

  /** انواع پیام‌های runtime */
  HL.MSG = {
    COUNT_REPORT: 'hlx:count-report',     // content → SW: به‌روزرسانی badge
    GET_COUNT: 'hlx:get-count',           // SW/popup → content: گرفتن تعداد
    GOTO: 'hlx:goto',                     // popup → content: اسکرول به هایلایت
    HIGHLIGHT_SELECTION: 'hlx:highlight-selection' // SW → content: هایلایت انتخاب فعلی
  };

  /** پیشوند هش برای پرش مستقیم به یک هایلایت (#hlx-goto-<id>) */
  HL.GOTO_HASH_PREFIX = 'hlx-goto-';

  /** رنگ‌های هایلایت — مقادیر css باید با content/mark-style.css هماهنگ بماند */
  HL.COLORS = {
    yellow: { label: 'زرد',       dot: '#f5b800' },
    green:  { label: 'سبز',       dot: '#58b85c' },
    teal:   { label: 'فیروزه‌ای', dot: '#35b3ae' },
    pink:   { label: 'صورتی',     dot: '#e5679b' },
    purple: { label: 'بنفش',      dot: '#a478e8' }
  };
  HL.COLOR_KEYS = Object.keys(HL.COLORS);

  /** تنظیمات پیش‌فرض */
  HL.DEFAULT_SETTINGS = {
    defaultColor: 'yellow',
    showToolbar: true,
    showBadge: true,
    disabledHosts: []
  };
})();
