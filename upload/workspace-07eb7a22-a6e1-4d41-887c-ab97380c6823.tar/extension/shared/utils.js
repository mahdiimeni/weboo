/**
 * وب هایلایتر — توابع عمومی (بدون وابستگی اجباری به DOM؛ در SW هم قابل import است)
 */
(function () {
  'use strict';
  const HL = (globalThis.HL = globalThis.HL || {});

  const TRACKING_PARAMS = ['fbclid', 'gclid', 'msclkid', 'igshid', 'mc_cid', 'mc_eid', 'yclid', 'vk_click_id', '_ga', '_gl', 'ref', 'source'];

  /**
   * نرمال‌سازی آدرس: حذف hash، حذف پارامترهای ردیابی، مرتب‌سازی پارامترها، حذف / انتهایی
   * خروجی: { url, norm, site, host } یا null
   */
  function normalizeUrl(href) {
    try {
      const u = new URL(String(href));
      u.hash = '';
      u.hostname = u.hostname.toLowerCase();
      if ((u.protocol === 'https:' && u.port === '443') || (u.protocol === 'http:' && u.port === '80')) u.port = '';

      const drop = [];
      u.searchParams.forEach(function (v, k) {
        const lk = k.toLowerCase();
        if (lk.indexOf('utm_') === 0 || TRACKING_PARAMS.indexOf(lk) !== -1) drop.push(k);
      });
      drop.forEach(function (k) { u.searchParams.delete(k); });

      let path = u.pathname;
      if (path.length > 1 && path.charAt(path.length - 1) === '/') path = path.replace(/\/+$/, '');

      const url = u.protocol + '//' + u.host + path + (u.search || '');

      const entries = [];
      u.searchParams.forEach(function (v, k) { entries.push([k, v]); });
      entries.sort(function (a, b) { return a[0] < b[0] ? -1 : 1; });
      const p2 = new URLSearchParams();
      entries.forEach(function (e) { p2.set(e[0], e[1]); });
      const qs = p2.toString();
      const norm = u.protocol + '//' + u.host + path + (qs ? '?' + qs : '');

      return { url: url, norm: norm, site: u.protocol + '//' + u.host, host: u.hostname };
    } catch (e) {
      return null;
    }
  }

  function newId() {
    return 'hlx_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
  }

  function debounce(fn, ms) {
    let t = null;
    return function () {
      const args = arguments;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(null, args); }, ms);
    };
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function fmtDate(ts) {
    try {
      return new Date(ts).toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
    } catch (e) { return ''; }
  }

  function fmtDateTime(ts) {
    try {
      return new Date(ts).toLocaleString('fa-IR', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch (e) { return ''; }
  }

  function excerpt(s, n) {
    s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
    return s.length > n ? s.slice(0, n) + '…' : s;
  }

  function cssEscape(s) {
    try {
      return (globalThis.CSS && globalThis.CSS.escape) ? globalThis.CSS.escape(String(s)) : String(s).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    } catch (e) {
      return String(s);
    }
  }

  /** دانلود متن به‌صورت فایل (فقط در صفحات دارای document) */
  function downloadText(filename, text, mime) {
    if (typeof document === 'undefined') return;
    const blob = new Blob([text], { type: (mime || 'application/json') + ';charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1500);
  }

  function backupFileName() {
    const d = new Date();
    const p = function (n) { return String(n).padStart(2, '0'); };
    return 'web-highlighter-backup-' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes()) + '.json';
  }

  HL.util = {
    normalizeUrl: normalizeUrl,
    newId: newId,
    debounce: debounce,
    escapeHtml: escapeHtml,
    fmtDate: fmtDate,
    fmtDateTime: fmtDateTime,
    excerpt: excerpt,
    cssEscape: cssEscape,
    downloadText: downloadText,
    backupFileName: backupFileName
  };
})();
