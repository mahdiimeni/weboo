/**
 * وب هایلایتر — منطق داشبورد (options page)
 * وابستگی‌ها (به‌ترتیب اسکریپت‌ها): shared/constants.js، shared/utils.js، shared/store.js
 * رندر متن‌ها فقط با textContent/createTextNode (ضد XSS از محتوای صفحات وب)؛
 * innerHTML فقط برای رشته‌های ثابِ آیکون‌های خودمان استفاده می‌شود.
 */
(function () {
  'use strict';
  if (!window.HL || !HL.util || !HL.store || !HL.MSG) return;

  /* ---------- ابزارک‌ها ---------- */

  function $(id) { return document.getElementById(id); }
  function el(tag, cls) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    return n;
  }
  function txtNode(s) { return document.createTextNode(String(s == null ? '' : s)); }
  function faNum(n) {
    try { return Number(n || 0).toLocaleString('fa-IR'); }
    catch (e) { return String(n || 0); }
  }
  function dotColorOf(key) {
    const c = HL.COLORS[key];
    return (c && c.dot) || '#f5b800';
  }
  function excerpt(s, n) { return HL.util.excerpt(s, n); }

  /* آیکون‌های ثابت خودمان — تنها جایی که innerHTML به‌کار می‌رود */
  const ICONS = {
    x: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
    chev: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>',
    view: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',
    copy: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
    trash: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
    quote: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1Z"/><path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1Z"/></svg>'
  };

  function iconBtn(icon, title, cls) {
    const b = el('button', 'icon-btn' + (cls ? ' ' + cls : ''));
    b.type = 'button';
    b.title = title;
    b.setAttribute('aria-label', title);
    b.innerHTML = ICONS[icon]; /* ثابت خودمان */
    return b;
  }

  /* تایید دومرحله‌ای: کلیک اول → «مطمئنی؟»، کلیک دوم → اجرا */
  function armButton(btn, confirmText, action) {
    const origHTML = btn.innerHTML;
    let armed = false;
    let timer = null;
    const reset = function () {
      armed = false;
      clearTimeout(timer);
      btn.classList.remove('armed');
      btn.innerHTML = origHTML; /* ثابت ذخیره‌شده‌ی خودمان */
      btn.removeAttribute('aria-pressed');
    };
    btn.addEventListener('click', function (ev) {
      ev.stopPropagation();
      if (!armed) {
        armed = true;
        btn.classList.add('armed');
        btn.setAttribute('aria-pressed', 'true');
        btn.textContent = confirmText;
        timer = setTimeout(reset, 3200);
        return;
      }
      clearTimeout(timer);
      reset();
      action();
    });
  }

  /* ---------- وضعیت ---------- */

  let records = [];                                     /* Record[] */
  let settings = Object.assign({}, HL.DEFAULT_SETTINGS);
  const filters = { q: '', colors: new Set(), notesOnly: false, sort: 'newest' };
  const collapsedGroups = new Set();                    /* urlNorm های جمع‌شده */
  let visibleLimit = 50;
  let pendingBackup = null;

  const els = {
    ver: $('ver'),
    sizeBadge: $('size-badge'),
    btnExport: $('btn-export'),
    btnImport: $('btn-import'),
    btnSettings: $('btn-settings'),
    stTotal: $('st-total'),
    stNotes: $('st-notes'),
    stPages: $('st-pages'),
    stSites: $('st-sites'),
    q: $('q'),
    colorChips: $('color-chips'),
    fNotes: $('f-notes'),
    fSort: $('f-sort'),
    groups: $('groups'),
    loadMore: $('load-more'),
    empty: $('empty'),
    emptyTitle: $('empty-title'),
    emptySub: $('empty-sub'),
    overlay: $('overlay'),
    drawer: $('drawer'),
    drawerClose: $('drawer-close'),
    colorDots: $('color-dots'),
    setToolbar: $('set-toolbar'),
    setBadge: $('set-badge'),
    hostChips: $('host-chips'),
    hostInput: $('host-input'),
    hostAdd: $('host-add'),
    dangerBtn: $('danger-btn'),
    dangerConfirm: $('danger-confirm'),
    dangerInput: $('danger-input'),
    dangerGo: $('danger-go'),
    dangerCancel: $('danger-cancel'),
    modal: $('modal'),
    modalSummary: $('modal-summary'),
    impCancel: $('imp-cancel'),
    impGo: $('imp-go'),
    toasts: $('toasts'),
    fileInput: $('file-input')
  };

  /* ---------- توست ---------- */

  function toast(msg, type) {
    const t = el('div', 'toast ' + (type || 'success'));
    t.textContent = msg;
    t.setAttribute('role', 'status');
    els.toasts.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () {
      t.classList.remove('show');
      setTimeout(function () { t.remove(); }, 300);
    }, 3200);
  }

  /* ---------- بارگذاری و رندر کلی ---------- */

  async function reload(hard) {
    try {
      const m = await HL.store.getAllRecords();
      records = Array.from(m.values());
    } catch (e) {
      records = [];
      toast('خواندن داده‌ها ناموفق بود', 'error');
    }
    if (hard) {
      try { settings = await HL.store.getSettings(); }
      catch (e) { settings = Object.assign({}, HL.DEFAULT_SETTINGS); }
      renderSettingsPanel();
    }
    renderStats();
    renderSize();
    renderList();
  }

  function renderStats() {
    let notes = 0;
    const pages = new Set();
    const sites = new Set();
    records.forEach(function (r) {
      if (r.note) notes++;
      if (r.urlNorm) pages.add(r.urlNorm);
      if (r.host) sites.add(r.host);
    });
    els.stTotal.textContent = faNum(records.length);
    els.stNotes.textContent = faNum(notes);
    els.stPages.textContent = faNum(pages.size);
    els.stSites.textContent = faNum(sites.size);
  }

  function renderSize() {
    HL.store.getBytesInUse().then(function (b) {
      els.sizeBadge.textContent = fmtBytes(b);
    }).catch(function () { els.sizeBadge.textContent = '—'; });
  }

  function fmtBytes(b) {
    b = Number(b) || 0;
    try {
      if (b < 1024) return b.toLocaleString('fa-IR') + ' بایت';
      if (b < 1048576) return (b / 1024).toLocaleString('fa-IR', { maximumFractionDigits: 1 }) + ' کیلوبایت';
      return (b / 1048576).toLocaleString('fa-IR', { maximumFractionDigits: 2 }) + ' مگابایت';
    } catch (e) { return String(b); }
  }

  /* ---------- فیلتر و گروه‌بندی ---------- */

  function applyFilters(list) {
    const q = filters.q;
    const colors = filters.colors;
    return list.filter(function (r) {
      if (filters.notesOnly && !r.note) return false;
      if (colors.size && !colors.has(r.color)) return false;
      if (q) {
        const hay = ((r.text || '') + '\n' + (r.note || '') + '\n' + (r.title || '') +
          '\n' + (r.host || '') + '\n' + (r.url || '')).toLowerCase();
        if (hay.indexOf(q) === -1) return false;
      }
      return true;
    });
  }

  function groupRecords(list) {
    const map = new Map();
    list.forEach(function (r) {
      const key = r.urlNorm || r.url || r.id;
      if (!map.has(key)) {
        map.set(key, {
          key: key,
          host: r.host || '',
          title: r.title || '',
          url: r.url || '',
          items: [],
          notes: 0,
          latest: 0,
          earliest: Infinity
        });
      }
      const g = map.get(key);
      g.items.push(r);
      if (r.note) g.notes++;
      g.latest = Math.max(g.latest, r.updatedAt || r.createdAt || 0);
      g.earliest = Math.min(g.earliest, r.createdAt || r.updatedAt || Infinity);
      if (!g.title && r.title) g.title = r.title;
      if (!g.url && r.url) g.url = r.url;
      if (!g.host && r.host) g.host = r.host;
    });
    const groups = Array.from(map.values());
    groups.forEach(function (g) {
      if (filters.sort === 'oldest') {
        g.items.sort(function (a, b) { return (a.createdAt || 0) - (b.createdAt || 0); });
      } else if (filters.sort === 'page') {
        g.items.sort(function (a, b) {
          return ((a.start || 0) - (b.start || 0)) || ((a.createdAt || 0) - (b.createdAt || 0));
        });
      } else {
        g.items.sort(function (a, b) {
          return ((b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
        });
      }
    });
    if (filters.sort === 'oldest') {
      groups.sort(function (a, b) { return a.earliest - b.earliest; });
    } else if (filters.sort === 'page') {
      groups.sort(function (a, b) {
        return (a.title || a.host).localeCompare(b.title || b.host, 'fa') || a.key.localeCompare(b.key);
      });
    } else {
      groups.sort(function (a, b) { return b.latest - a.latest; });
    }
    return groups;
  }

  /* ---------- رندر لیست ---------- */

  function renderList() {
    const filtered = applyFilters(records);
    els.groups.textContent = '';

    if (!filtered.length) {
      els.empty.hidden = false;
      els.loadMore.hidden = true;
      if (!records.length) {
        els.emptyTitle.textContent = 'هنوز هایلایتی ثبت نشده — اولین متن را انتخاب کن!';
        els.emptySub.textContent = 'روی هر صفحه‌ی وب، متن را انتخاب کن و از نوار شناور افزونه استفاده کن.';
      } else {
        els.emptyTitle.textContent = 'نتیجه‌ای پیدا نشد.';
        els.emptySub.textContent = 'عبارت جست‌وجو یا فیلترهای رنگ را تغییر بده.';
      }
      return;
    }
    els.empty.hidden = true;

    let shown = 0;
    let overflow = 0;
    const groups = groupRecords(filtered);
    for (let i = 0; i < groups.length; i++) {
      const g = groups[i];
      if (shown >= visibleLimit) { overflow = filtered.length - shown; break; }
      const room = visibleLimit - shown;
      if (g.items.length > room) {
        const cut = Object.assign({}, g, { items: g.items.slice(0, room) });
        els.groups.appendChild(buildGroup(cut, g.items.length - room));
        shown += room;
        overflow = filtered.length - shown;
        break;
      }
      els.groups.appendChild(buildGroup(g, 0));
      shown += g.items.length;
    }

    if (overflow > 0) {
      els.loadMore.hidden = false;
      els.loadMore.textContent = 'بارگذاری بیشتر (' + faNum(overflow) + ' مورد باقی‌مانده)';
    } else {
      els.loadMore.hidden = true;
    }
  }

  function buildGroup(g, remaining) {
    const card = el('div', 'group' + (collapsedGroups.has(g.key) ? ' collapsed' : ''));
    card.dataset.key = g.key;

    /* هدر گروه */
    const head = el('div', 'group-head');
    head.setAttribute('role', 'button');
    head.tabIndex = 0;
    head.setAttribute('aria-expanded', String(!collapsedGroups.has(g.key)));

    const fl = el('span', 'fl');
    fl.textContent = faviconLetter(g.host);
    fl.title = g.host || 'فایل محلی';

    const gt = el('span', 'group-txt');
    const title = el('strong', 'group-title');
    title.textContent = excerpt(g.title || g.host || g.url, 60) || 'بدون عنوان';
    const url = el('span', 'group-url');
    url.textContent = excerpt(displayUrl(g.url), 70);
    gt.appendChild(title);
    gt.appendChild(url);

    const chips = el('span', 'gchips');
    const c1 = el('span', 'chip');
    c1.textContent = faNum(g.items.length + remaining) + ' هایلایت';
    chips.appendChild(c1);
    if (g.notes > 0) {
      const c2 = el('span', 'chip');
      c2.textContent = faNum(g.notes) + ' یادداشت';
      chips.appendChild(c2);
    }

    const chev = el('span', 'chev');
    chev.innerHTML = ICONS.chev;
    chev.setAttribute('aria-hidden', 'true');

    const delBtn = iconBtn('trash', 'حذف همه‌ی این صفحه', 'danger');
    armButton(delBtn, 'مطمئنی؟', function () {
      HL.store.removeForUrl(g.key, g.host).then(function () {
        toast('هایلایت‌های این صفحه حذف شد', 'success');
        reload(false);
      }).catch(function () {
        toast('حذف ناموفق بود', 'error');
      });
    });

    head.appendChild(fl);
    head.appendChild(gt);
    head.appendChild(chips);
    head.appendChild(chev);
    head.appendChild(delBtn);

    /* آیتم‌ها */
    const items = el('div', 'group-items');
    if (collapsedGroups.has(g.key)) items.hidden = true;
    g.items.forEach(function (rec) { items.appendChild(buildItem(rec)); });

    if (remaining > 0) {
      const more = el('div', 'item-more');
      more.textContent = '…' + faNum(remaining) + ' مورد دیگر از این صفحه (برای نمایش، «بارگذاری بیشتر» را بزن)';
      items.appendChild(more);
    }

    const toggle = function () {
      if (collapsedGroups.has(g.key)) {
        collapsedGroups.delete(g.key);
        card.classList.remove('collapsed');
        items.hidden = false;
        head.setAttribute('aria-expanded', 'true');
      } else {
        collapsedGroups.add(g.key);
        card.classList.add('collapsed');
        items.hidden = true;
        head.setAttribute('aria-expanded', 'false');
      }
    };
    head.addEventListener('click', function (ev) {
      if (ev.target && ev.target.closest && ev.target.closest('.icon-btn')) return; /* کلیک روی دکمه‌ی حذف → toggle نشود */
      toggle();
    });
    head.addEventListener('keydown', function (ev) {
      if (ev.key === 'Enter' || ev.key === ' ') {
        ev.preventDefault();
        toggle();
      }
    });

    card.appendChild(head);
    card.appendChild(items);
    return card;
  }

  function faviconLetter(host) {
    const h = String(host || '').replace(/^www\./, '');
    const ch = (h.charAt(0) || '').toUpperCase();
    return ch || 'و';
  }

  function displayUrl(url) {
    let u = String(url || '');
    u = u.replace(/^[a-z]+:\/\//i, '');
    return u || '—';
  }

  function buildItem(rec) {
    const item = el('article', 'item');

    const bar = el('span', 'cbar');
    bar.style.background = dotColorOf(rec.color);
    bar.setAttribute('aria-hidden', 'true');

    const text = el('p', 'item-text');
    text.textContent = excerpt(rec.text, 200);
    item.appendChild(bar);
    item.appendChild(text);

    if (rec.note) {
      const note = el('div', 'note');
      const ic = el('span', 'note-ic');
      ic.innerHTML = ICONS.quote; /* ثابت خودمان */
      const nt = el('span', 'note-text');
      nt.textContent = excerpt(rec.note, 300);
      note.appendChild(ic);
      note.appendChild(nt);
      item.appendChild(note);
    }

    const meta = el('div', 'item-meta');
    const date = el('span', 'item-date');
    date.textContent = HL.util.fmtDateTime(rec.updatedAt || rec.createdAt);
    meta.appendChild(date);

    const actions = el('div', 'item-actions');

    const viewBtn = iconBtn('view', 'مشاهده در صفحه');
    viewBtn.addEventListener('click', function () {
      if (!rec.url) { toast('آدرس این هایلایت ثبت نشده است', 'error'); return; }
      try { window.open(rec.url + '#' + HL.GOTO_HASH_PREFIX + rec.id, '_blank'); }
      catch (e) { toast('بازکردن صفحه ناموفق بود', 'error'); }
    });

    const copyBtn = iconBtn('copy', 'کپی متن');
    copyBtn.addEventListener('click', function () {
      copyText(rec.text || '');
    });

    const delBtn = iconBtn('trash', 'حذف این هایلایت', 'danger');
    armButton(delBtn, 'مطمئنی؟', function () {
      HL.store.remove(rec.id, rec.host).then(function () {
        toast('هایلایت حذف شد', 'success');
        reload(false);
      }).catch(function () {
        toast('حذف ناموفق بود', 'error');
      });
    });

    actions.appendChild(viewBtn);
    actions.appendChild(copyBtn);
    actions.appendChild(delBtn);
    meta.appendChild(actions);
    item.appendChild(meta);

    return item;
  }

  /* ---------- کپی ---------- */

  function copyText(t) {
    if (!t) { toast('چیزی برای کپی نیست', 'info'); return; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(t).then(function () {
        toast('کپی شد ✓', 'success');
      }).catch(function () { legacyCopy(t); });
    } else {
      legacyCopy(t);
    }
  }
  function legacyCopy(t) {
    try {
      const ta = document.createElement('textarea');
      ta.value = t;
      ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      toast(ok ? 'کپی شد ✓' : 'کپی ناموفق بود', ok ? 'success' : 'error');
    } catch (e) {
      toast('کپی ناموفق بود', 'error');
    }
  }

  /* ---------- نوار فیلتر ---------- */

  function buildColorChips() {
    els.colorChips.textContent = '';
    HL.COLOR_KEYS.forEach(function (k) {
      const c = HL.COLORS[k];
      const b = el('button', 'cchip');
      b.type = 'button';
      b.dataset.key = k;
      b.setAttribute('role', 'checkbox');
      b.setAttribute('aria-checked', 'false');
      const dot = el('span', 'dot');
      dot.style.background = c.dot;
      b.appendChild(dot);
      b.appendChild(txtNode(c.label));
      b.addEventListener('click', function () {
        if (filters.colors.has(k)) filters.colors.delete(k);
        else filters.colors.add(k);
        b.classList.toggle('active', filters.colors.has(k));
        b.setAttribute('aria-checked', String(filters.colors.has(k)));
        visibleLimit = 50;
        renderList();
      });
      els.colorChips.appendChild(b);
    });
  }

  function bindToolbar() {
    els.q.addEventListener('input', HL.util.debounce(function () {
      filters.q = els.q.value.trim().toLowerCase();
      visibleLimit = 50;
      renderList();
    }, 250));

    els.fNotes.addEventListener('change', function () {
      filters.notesOnly = !!els.fNotes.checked;
      visibleLimit = 50;
      renderList();
    });

    els.fSort.addEventListener('change', function () {
      filters.sort = els.fSort.value || 'newest';
      visibleLimit = 50;
      renderList();
    });

    els.loadMore.addEventListener('click', function () {
      visibleLimit += 50;
      renderList();
    });
  }

  /* ---------- خروجی / بازیابی ---------- */

  els.btnExport.addEventListener('click', async function () {
    try {
      const b = await HL.store.exportData();
      const n = (b.meta && b.meta.count) || 0;
      HL.util.downloadText(HL.util.backupFileName(), JSON.stringify(b, null, 2));
      toast('فایل بک‌آپ با ' + faNum(n) + ' هایلایت دانلود شد', 'success');
    } catch (e) {
      toast('خروجی گرفتن ناموفق بود', 'error');
    }
  });

  els.btnImport.addEventListener('click', function () {
    els.fileInput.value = '';
    try { els.fileInput.click(); } catch (e) { toast('بازکردن فایل ناموفق بود', 'error'); }
  });

  els.fileInput.addEventListener('change', function () {
    const f = els.fileInput.files && els.fileInput.files[0];
    els.fileInput.value = '';
    if (!f) return;
    const reader = new FileReader();
    reader.onerror = function () { toast('خواندن فایل ناموفق بود', 'error'); };
    reader.onload = function () {
      let data = null;
      try { data = JSON.parse(String(reader.result)); }
      catch (e) { data = null; }
      if (!data || data.app !== HL.APP_ID || !data.highlights || typeof data.highlights !== 'object') {
        toast('فایل معتبر نیست', 'error');
        return;
      }
      pendingBackup = data;
      fillModalSummary(data);
      openModal();
    };
    try { reader.readAsText(f, 'utf-8'); }
    catch (e) { toast('خواندن فایل ناموفق بود', 'error'); }
  });

  function fillModalSummary(b) {
    els.modalSummary.textContent = '';
    const count = (b.meta && b.meta.count) || Object.keys(b.highlights).length;
    addRow('نام مجموعه', b.name || HL.APP_NAME);
    addRow('تعداد هایلایت‌ها', faNum(count));
    addRow('تاریخ خروجی', b.exportedAt ? HL.util.fmtDateTime(b.exportedAt) : '—');
    addRow('نسخه', 'v' + (b.version || HL.VERSION));
    function addRow(k, v) {
      const r = el('div', 'sum-row');
      const kk = el('span', 'muted');
      kk.textContent = k;
      const vv = el('strong');
      vv.textContent = v;
      r.appendChild(kk);
      r.appendChild(vv);
      els.modalSummary.appendChild(r);
    }
  }

  function openModal() { els.modal.hidden = false; }
  function closeModal() {
    els.modal.hidden = true;
    pendingBackup = null;
  }

  els.impCancel.addEventListener('click', closeModal);

  els.impGo.addEventListener('click', async function () {
    if (!pendingBackup) return;
    const checked = document.querySelector('input[name="imp-mode"]:checked');
    const mode = checked ? checked.value : 'merge';
    els.impGo.disabled = true;
    try {
      const r = await HL.store.importData(pendingBackup, mode);
      toast(faNum(r.added) + ' مورد اضافه، ' + faNum(r.updated) + ' به‌روزرسانی، ' + faNum(r.skipped) + ' رد شد', 'success');
      closeModal();
      await reload(true);
    } catch (e) {
      toast('بازیابی ناموفق بود' + (e && e.message ? ': ' + e.message : ''), 'error');
    } finally {
      els.impGo.disabled = false;
    }
  });

  /* ---------- پنل تنظیمات (drawer) ---------- */

  function openDrawer() {
    els.drawer.classList.add('open');
    els.overlay.classList.add('show');
    els.drawer.setAttribute('aria-hidden', 'false');
    try { els.drawerClose.focus(); } catch (e) { /* noop */ }
  }
  function closeDrawer() {
    els.drawer.classList.remove('open');
    els.overlay.classList.remove('show');
    els.drawer.setAttribute('aria-hidden', 'true');
    resetDanger();
  }

  els.btnSettings.addEventListener('click', openDrawer);
  els.drawerClose.addEventListener('click', closeDrawer);
  els.overlay.addEventListener('click', closeDrawer);

  function buildColorDots() {
    els.colorDots.textContent = '';
    HL.COLOR_KEYS.forEach(function (k) {
      const c = HL.COLORS[k];
      const b = el('button', 'cdot');
      b.type = 'button';
      b.dataset.key = k;
      b.setAttribute('role', 'radio');
      b.title = 'رنگ پیش‌فرض: ' + c.label;
      b.setAttribute('aria-label', c.label);
      const dot = el('span', 'dot');
      dot.style.background = c.dot;
      b.appendChild(dot);
      b.addEventListener('click', function () {
        setSetting({ defaultColor: k });
      });
      els.colorDots.appendChild(b);
    });
  }

  function renderSettingsPanel() {
    /* رنگ‌ها */
    const dots = els.colorDots.children;
    for (let i = 0; i < dots.length; i++) {
      const active = dots[i].dataset.key === settings.defaultColor;
      dots[i].classList.toggle('active', active);
      dots[i].setAttribute('aria-checked', String(active));
    }
    /* رفتار */
    if (els.setToolbar) els.setToolbar.checked = !!settings.showToolbar;
    if (els.setBadge) els.setBadge.checked = !!settings.showBadge;
    /* سایت‌های غیرفعال */
    renderHostChips();
  }

  function renderHostChips() {
    els.hostChips.textContent = '';
    const list = settings.disabledHosts || [];
    if (!list.length) {
      const p = el('p', 'muted small');
      p.textContent = 'هنوز سایتی غیرفعال نشده است.';
      els.hostChips.appendChild(p);
      return;
    }
    list.forEach(function (h) {
      const chip = el('span', 'hchip');
      chip.appendChild(txtNode(h));
      const x = el('button', 'hchip-x');
      x.type = 'button';
      x.title = 'حذف ' + h;
      x.setAttribute('aria-label', 'حذف ' + h);
      x.innerHTML = ICONS.x; /* ثابت خودمان */
      x.addEventListener('click', function () {
        setSetting({ disabledHosts: list.filter(function (v) { return v !== h; }) });
      });
      chip.appendChild(x);
      els.hostChips.appendChild(chip);
    });
  }

  async function setSetting(patch) {
    const prev = settings;
    settings = Object.assign({}, settings, patch);
    renderSettingsPanel();
    try {
      await HL.store.setSettings(patch);
      return true;
    } catch (e) {
      settings = prev;
      renderSettingsPanel();
      toast('ذخیره تنظیمات ناموفق بود', 'error');
      return false;
    }
  }

  els.setToolbar.addEventListener('change', function () {
    setSetting({ showToolbar: !!els.setToolbar.checked });
  });
  els.setBadge.addEventListener('change', function () {
    setSetting({ showBadge: !!els.setBadge.checked });
  });

  /* افزودن/حذف سایت غیرفعال */

  function sanitizeHost(raw) {
    let h = String(raw || '').trim().toLowerCase();
    if (!h) return null;
    h = h.replace(/^[a-z][a-z0-9+.-]*:\/\//, '');           /* حذف scheme */
    h = h.split('/')[0].split('?')[0].split('#')[0].split(':')[0];
    h = h.replace(/\s+/g, '');
    if (!h) return null;
    if (h === 'localhost') return 'localhost';
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) return h;          /* IP */
    if (/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/.test(h)) return h;
    return null;
  }

  async function addHost() {
    const h = sanitizeHost(els.hostInput.value);
    if (!h) { toast('دامنه‌ی معتبر وارد کن (مثل example.com)', 'error'); return; }
    const list = (settings.disabledHosts || []).slice();
    if (list.indexOf(h) !== -1) { toast('این دامنه قبلاً اضافه شده است', 'info'); return; }
    list.push(h);
    els.hostInput.value = '';
    const ok = await setSetting({ disabledHosts: list });
    if (ok) toast('سایت ' + h + ' غیرفعال شد', 'success');
  }

  els.hostAdd.addEventListener('click', addHost);
  els.hostInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); addHost(); }
  });

  /* ---------- منطقه‌ی خطر (تایید سه‌مرحله‌ای) ---------- */

  const DANGER_ORIG = els.dangerBtn.textContent;
  let dangerArmed = false;
  let dangerTimer = null;

  function resetDanger() {
    dangerArmed = false;
    clearTimeout(dangerTimer);
    els.dangerBtn.classList.remove('armed');
    els.dangerBtn.textContent = DANGER_ORIG;
    els.dangerBtn.disabled = false;
    els.dangerConfirm.hidden = true;
    els.dangerInput.value = '';
    els.dangerGo.disabled = true;
  }

  els.dangerBtn.addEventListener('click', function () {
    if (!dangerArmed) {
      dangerArmed = true;
      els.dangerBtn.textContent = 'مطمئنی؟';
      els.dangerBtn.classList.add('armed');
      els.dangerConfirm.hidden = false;
      try { els.dangerInput.focus(); } catch (e) { /* noop */ }
      dangerTimer = setTimeout(resetDanger, 15000);
      return;
    }
    /* مرحله‌ی بعد: ورودی متن (اگر دوباره کلیک شد، روی ورودی تأکید) */
    try { els.dangerInput.focus(); } catch (e) { /* noop */ }
  });

  els.dangerInput.addEventListener('input', function () {
    els.dangerGo.disabled = els.dangerInput.value.trim() !== 'حذف';
  });

  els.dangerInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !els.dangerGo.disabled) {
      e.preventDefault();
      els.dangerGo.click();
    }
  });

  els.dangerGo.addEventListener('click', async function () {
    if (els.dangerInput.value.trim() !== 'حذف') return;
    els.dangerGo.disabled = true;
    try {
      await HL.store.clearAll();
      /* تنظیمات کاربر باید حفظ شود (clearAll همه‌ی کلیدهای hlx را پاک می‌کند) */
      await HL.store.setSettings(settings);
      toast('همه‌ی هایلایت‌ها و یادداشت‌ها حذف شد', 'success');
      resetDanger();
      await reload(true);
    } catch (e) {
      toast('حذف ناموفق بود', 'error');
      els.dangerGo.disabled = false;
    }
  });

  els.dangerCancel.addEventListener('click', resetDanger);

  /* ---------- کلید Escape ---------- */

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!els.modal.hidden) { closeModal(); return; }
    if (els.drawer.classList.contains('open')) { closeDrawer(); return; }
    if (dangerArmed) resetDanger();
  });

  /* ---------- راه‌اندازی ---------- */

  function init() {
    try { els.ver.textContent = 'v' + chrome.runtime.getManifest().version; }
    catch (e) { els.ver.textContent = 'v' + (HL.VERSION || ''); }

    buildColorChips();
    buildColorDots();
    bindToolbar();

    /* همگام‌سازی زنده: تغییر داده در تب دیگر → بازخوانی با debounce 400ms */
    HL.store.onRecordsChanged(HL.util.debounce(function () { reload(false); }, 400));
    HL.store.onSettingsChanged(function (s) {
      settings = s || Object.assign({}, HL.DEFAULT_SETTINGS);
      renderSettingsPanel();
    });

    reload(true);
  }

  init();
})();
