/**
 * وب هایلایتر — منطق پاپ‌آپ
 * وابستگی‌ها (به‌ترتیب اسکریپت‌ها): shared/constants.js، shared/utils.js، shared/store.js
 * رندر متن‌ها فقط با textContent/createTextNode (ضد XSS از محتوای صفحات وب).
 */
(function () {
  'use strict';
  if (!window.HL || !HL.util || !HL.store || !HL.MSG) return;

  /* ---------- ابزارک‌ها ---------- */

  function $(id) { return document.getElementById(id); }
  function el(tag, cls) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    return n;
  }
  function faNum(n) {
    try { return Number(n || 0).toLocaleString('fa-IR'); }
    catch (e) { return String(n || 0); }
  }
  function dotColorOf(key) {
    const c = HL.COLORS[key];
    return (c && c.dot) || (HL.COLORS.yellow && HL.COLORS.yellow.dot) || '#f5b800';
  }

  /* آیکون StickyNote — رشته‌ی ثابت خودمان (innerHTML فقط برای ثابت‌ها) */
  const ICON_NOTE = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.5 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h9l7-7V5a2 2 0 0 0-2-2Z"/><path d="M14 21v-4a2 2 0 0 1 2-2h4"/></svg>';

  /* ---------- پوشش‌های دفاعی chrome.* ---------- */

  function queryTabs(q) {
    return new Promise(function (resolve) {
      try {
        chrome.tabs.query(q, function (t) {
          void chrome.runtime.lastError;
          resolve(t || []);
        });
      } catch (e) { resolve([]); }
    });
  }
  function sendToTab(tabId, msg) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.tabs.sendMessage(tabId, msg, function (resp) {
          const err = (chrome.runtime && chrome.runtime.lastError) || null;
          if (err) reject(new Error(err.message || 'ارسال پیام ناموفق بود'));
          else resolve(resp);
        });
      } catch (e) { reject(e); }
    });
  }
  function createTab(url) {
    return new Promise(function (resolve) {
      try {
        chrome.tabs.create({ url: url }, function (t) {
          void chrome.runtime.lastError;
          resolve(t || null);
        });
      } catch (e) { resolve(null); }
    });
  }
  function openUrl(url) {
    if (!url) return;
    try {
      const w = window.open(url, '_blank');
      if (w) return;
    } catch (e) { /* fallback پایین */ }
    createTab(url);
  }
  function openDashboard() {
    let url = 'dashboard/dashboard.html';
    try { url = chrome.runtime.getURL('dashboard/dashboard.html'); } catch (e) { /* نگه‌داشتن مقدار پیش‌فرض */ }
    createTab(url).then(function () { window.close(); });
  }

  /* ---------- ارجاع‌های DOM ---------- */

  const els = {
    ver: $('ver'),
    btnSettings: $('btn-settings'),
    secUnsupported: $('sec-unsupported'),
    btnDashUnsupp: $('btn-dash-unsupp'),
    secGeneric: $('sec-generic'),
    gTotal: $('g-total'),
    secPage: $('sec-page'),
    fl: $('fl'),
    pageTitle: $('page-title'),
    pageHost: $('page-host'),
    chipHl: $('chip-hl'),
    chipNote: $('chip-note'),
    secToggle: $('sec-toggle'),
    toggleHost: $('toggle-host'),
    toggle: $('site-toggle'),
    toggleMsg: $('toggle-msg'),
    secList: $('sec-list'),
    listCount: $('list-count'),
    hlList: $('hl-list'),
    secEmpty: $('sec-empty'),
    foot: $('foot'),
    btnDashboard: $('btn-dashboard'),
    btnExport: $('btn-export'),
    toast: $('toast')
  };

  const state = { tab: null, nu: null, settings: null, recs: new Map(), on: true };
  let toastTimer = null;
  let msgTimer = null;

  /* ---------- توست داخلی ---------- */

  function toast(msg, type) {
    if (!els.toast) return;
    els.toast.textContent = msg;
    els.toast.className = 'toast show ' + (type || 'success');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { els.toast.className = 'toast'; }, 2600);
  }

  function showApplied() {
    if (!els.toggleMsg) return;
    els.toggleMsg.hidden = false;
    clearTimeout(msgTimer);
    msgTimer = setTimeout(function () { els.toggleMsg.hidden = true; }, 2400);
  }

  /* ---------- حالت‌های رندر ---------- */

  function renderUnsupported() {
    els.secUnsupported.hidden = false;
    els.secGeneric.hidden = true;
    els.secPage.hidden = true;
    els.secToggle.hidden = true;
    els.secList.hidden = true;
    els.secEmpty.hidden = true;
    els.foot.hidden = true; /* دکمه‌ی داشبورد داخل خود کارت است */
  }

  async function renderGeneric() {
    els.secGeneric.hidden = false;
    els.secUnsupported.hidden = true;
    els.secPage.hidden = true;
    els.secToggle.hidden = true;
    els.secList.hidden = true;
    els.secEmpty.hidden = true;
    els.foot.hidden = false;

    let n = 0;
    try { n = (await HL.store.getAllRecords()).size; }
    catch (e) { n = 0; }
    els.gTotal.textContent = faNum(n);
  }

  async function renderPage() {
    els.secPage.hidden = false;
    els.secToggle.hidden = false;
    els.secGeneric.hidden = true;
    els.secUnsupported.hidden = true;
    els.foot.hidden = false;

    const host = state.nu.host || '';
    const hostLabel = host || 'فایل محلی';

    els.pageTitle.textContent = HL.util.excerpt(state.tab.title || hostLabel, 60) || hostLabel;
    els.pageHost.textContent = hostLabel;
    els.fl.textContent = faviconLetter(host);

    try { state.settings = await HL.store.getSettings(); }
    catch (e) { state.settings = Object.assign({}, HL.DEFAULT_SETTINGS); }

    const hosts = (state.settings && state.settings.disabledHosts) || [];
    setSwitch(hosts.indexOf(host) === -1);
    els.toggleHost.textContent = hostLabel;

    try { state.recs = await HL.store.getForUrl(state.nu.norm, host); }
    catch (e) { state.recs = new Map(); }
    if (!state.recs) state.recs = new Map();

    let notes = 0;
    state.recs.forEach(function (r) { if (r && r.note) notes++; });
    els.chipHl.textContent = faNum(state.recs.size) + ' هایلایت';
    els.chipNote.textContent = faNum(notes) + ' یادداشت';

    renderPageRecs();
  }

  function faviconLetter(host) {
    const h = String(host || '').replace(/^www\./, '');
    const ch = (h.charAt(0) || '').toUpperCase();
    return ch || 'و';
  }

  function renderPageRecs() {
    els.hlList.textContent = '';
    if (!state.recs.size) {
      els.secList.hidden = true;
      els.secEmpty.hidden = false;
      return;
    }
    els.secEmpty.hidden = true;
    els.secList.hidden = false;

    const arr = Array.from(state.recs.values())
      .sort(function (a, b) { return (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0); })
      .slice(0, 8);

    els.listCount.textContent = arr.length < state.recs.size
      ? faNum(arr.length) + ' از ' + faNum(state.recs.size)
      : faNum(state.recs.size) + ' مورد';

    arr.forEach(function (rec) { els.hlList.appendChild(buildItem(rec)); });
  }

  function buildItem(rec) {
    const li = el('li', 'hl-item');
    li.setAttribute('role', 'button');
    li.tabIndex = 0;
    li.title = 'پرش به این هایلایت';

    const dot = el('span', 'dot');
    dot.style.background = dotColorOf(rec.color);

    const txt = el('span', 'txt');
    const line = el('p', 'hl-text');
    line.textContent = HL.util.excerpt(rec.text, 80);

    const meta = el('span', 'hl-meta');
    const date = el('span', 'date');
    date.textContent = HL.util.fmtDateTime(rec.updatedAt || rec.createdAt);
    meta.appendChild(date);
    if (rec.note) {
      const ic = el('span', 'note-ic');
      ic.innerHTML = ICON_NOTE; /* ثابت خودمان */
      ic.title = 'دارد یادداشت';
      meta.appendChild(ic);
    }

    txt.appendChild(line);
    txt.appendChild(meta);
    li.appendChild(dot);
    li.appendChild(txt);

    const go = function () { gotoRec(rec); };
    li.addEventListener('click', go);
    li.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); }
    });
    return li;
  }

  function gotoRec(rec) {
    const hashUrl = String(rec.url || '') + '#' + HL.GOTO_HASH_PREFIX + rec.id;
    const tabId = state.tab ? state.tab.id : null;
    if (tabId == null) { openUrl(hashUrl); window.close(); return; }
    sendToTab(tabId, { type: HL.MSG.GOTO, id: rec.id })
      .then(function () { window.close(); })
      .catch(function () {
        /* صفحه بدون content script → بازکردن آدرس با هش */
        openUrl(hashUrl);
        window.close();
      });
  }

  /* ---------- سوئیچ سایت ---------- */

  function setSwitch(on) {
    state.on = !!on;
    els.toggle.setAttribute('aria-checked', String(state.on));
  }

  els.toggle.addEventListener('click', async function () {
    const host = state.nu && state.nu.host;
    if (!host) return;
    const next = !state.on;
    const list = ((state.settings && state.settings.disabledHosts) || []).slice();
    const idx = list.indexOf(host);
    if (next) { if (idx !== -1) list.splice(idx, 1); }
    else { if (idx === -1) list.push(host); }
    try {
      state.settings = await HL.store.setSettings({ disabledHosts: list });
      setSwitch(next);
      showApplied();
    } catch (e) {
      toast('ذخیره تنظیمات ناموفق بود', 'error');
    }
  });

  /* ---------- خروجی پشتیبان ---------- */

  async function doExport() {
    try {
      const b = await HL.store.exportData();
      HL.util.downloadText(HL.util.backupFileName(), JSON.stringify(b, null, 2));
      toast('فایل بک‌آپ دانلود شد');
    } catch (e) {
      toast('خروجی گرفتن ناموفق بود', 'error');
    }
  }

  /* ---------- راه‌اندازی ---------- */

  function isSupported(nu) {
    const site = String(nu.site || '');
    return site.indexOf('http') === 0 || site.indexOf('file') === 0;
  }

  async function init() {
    try { els.ver.textContent = 'v' + chrome.runtime.getManifest().version; }
    catch (e) { els.ver.textContent = 'v' + (HL.VERSION || ''); }

    els.btnSettings.addEventListener('click', openDashboard);
    els.btnDashboard.addEventListener('click', openDashboard);
    els.btnDashUnsupp.addEventListener('click', openDashboard);
    els.btnExport.addEventListener('click', doExport);

    const tabs = await queryTabs({ active: true, currentWindow: true });
    state.tab = (tabs && tabs[0]) || null;
    const url = state.tab ? state.tab.url : null;

    if (!url) { await renderGeneric(); return; }

    const nu = HL.util.normalizeUrl(url);
    if (!nu || !isSupported(nu)) { renderUnsupported(); return; }

    state.nu = nu;
    await renderPage();
  }

  init();
})();
